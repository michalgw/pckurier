function FastSqrt(num : word ) : word;
assembler;
asm
  mov ax, 1     { AX = 1 }
  mov cx, [num] { CX = ARGUMENT }
@L1:
  mov bx, ax    { BX = AX }
  mov ax, cx
  xor dx, dx    { DX:AX = ARGUMENT }
  div bx        { AX = ARGUMENT/BX }
  add ax, bx    { AX = AX+BX }
  shr ax, 1     { AX = AX/2 }
  mov dx, ax    { DX = AX }
  sub dx, bx    { DX = DX-BX }
  cmp dx, 1     { KONIEC? (DX=1) }
  ja  @L1       { JESZCZE NIE }
end;
