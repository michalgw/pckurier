/*-----------------------------------------------------
	Modul wyswietlania zegara clock.c
   Implementacja dla kompilatorow firmy Borland
-----------------------------------------------------*/

#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <math.h>
#include "scrserv.h"
#include "clock.h"

#define TRUE (0==0)
#define FALSE (!TRUE)

typedef unsigned short word;

/* Prototyp funkcji obslugi przerwania */
void interrupt my_timer();

/* Starsze slowo timera odmierza godziny. Modyfikator */
/* volatile zapobiega ewentualnym  optymalizacjom,np. */
/* zaladowaniu wskazywanej komorki do rejestru        */
volatile word far * hours = MK_FP( 0, 0x046e );

/* Mlodsze slowo timera odmierza "tykniecia" zegara */
volatile word far * ticks = MK_FP( 0, 0x046c );

/* Wskaznik oryginalnej funkcji obslugi przerwania */
void interrupt ( *old_timer )();

/* Flaga aktywnosci zegara */
int  installed = FALSE;

/* Ekranowy wiersz, kolumna i atrybut zagara */
int col = 1;
int row = 1;
unsigned char attr = 112;


/* Instalacja zagara */
void install_clock( void )
{
  if( ! installed )
  {
    /* Schowaj poprzednia funkcje obslugi przerwania */
    old_timer  = getvect( 0x1c );

     /* Instaluj moja procedure obslugi przerwania */
    setvect( 0x1c, my_timer );

    /* Ustaw flage aktywnosci zegara */
    installed = TRUE;
  }
}

/* Deinstalacja zegara */
void uninstall_clock( void )
{
  if( installed )
  {
    /* Przywroc oryginalna procedure obslugi */
    setvect( 0x1c, old_timer );

    /* Czysc flage aktywnosci */
    installed = FALSE;
  }
}

/* Funkcja obslugi przerwania 1Ch. Pragma zapobiega */
/* generowaniu ostrzezenia o wywolaniu  oryginalnej */
/* funkcji przerwania bez prototypu, co jest prawda */
/* bowiem wywolujemy ja za  posrednictwej wskaznika */
#pragma warn -pro
void interrupt my_timer()
{
  /* Licznik "tykniec" zegara */
  static int counter = 0;

  int min, sec;

  /* Blokada przerwan CLI */
  disable();

  /* Jezeli odmierzona zostala sekunda */
  if( ( counter %= 18 ) == 0 )
  {
    /* Wyswietlam na ekranie godziny, najpierw cyfre  */
    /* dziesiatek potem cyfre jednostek               */

    write_char( col, row, attr, ( *hours / 10 ) + '0' );
    write_char( col+1,row,attr, ( *hours % 10 ) + '0' );

    /* Separator */
    write_char( col + 2, row , attr, ':' );

    /* Liczbe  "tykniec" dzielimy  przez 18 - teraz  */
    /* mamy  poprawna  aktualna  liczbe  sekund.     */
    /* Dalej dzielimy  przez 60 i dostajemy  minuty. */
    /* Aby uniknac zbyt  duzych  zaokraglen stosuje  */
    /* dzielenie zmiennoprzecinkowe  i zaokraglenie  */
    /* w gore funkcja ceil.                          */

    sec = ( int )( ceil( *ticks / 18.20444444 ) );
    min =  sec / 60;

    /* Wyswietlam na ekranie liczbe minut, najpierw */
    /* cyfre dziesiatek potem cyfre jednostek       */

    write_char( col+3,row,attr, ( min  / 10 ) + '0' );
    write_char( col+4,row,attr, ( min  % 10 ) + '0' );

    /* Separator */
    write_char( col + 5, row, attr, ':');

    /* Reszta z dzielenia  przez  60  wyznacza ilosc */
    /* sekund aktualnie odmierzanej minuty           */
    sec %= 60;

    /* Wyswietlam na ekranie liczbe sekund, najpierw */
    /* cyfre dziesiatek  potem cyfre jednostek       */

    write_char( col+6,row,attr, ( sec / 10 ) + '0' );
    write_char( col+7,row,attr, ( sec % 10 ) + '0');
  }

  /* Nastepne "tykniecie" timera */
  counter++;

  /* Wywolanie oryginalnej funkcji obslugi Int 1ch */
  old_timer();

  /* Odblokowanie przerwan STI */
  enable();
}

