/*----------------------------------------------------

 zegar.c

 Program  demonstaracyjny  prezentujacy   mozliwosci
 wykorzystania modulu  clock.c.  Nalezy kompilowac z
 wylaczona opcja testowania przepelnienia stosu oraz
 bez optymalizacji rejestrowej.

 Uwaga! Nie deinstalowalny program rezydentny.

 Projekt:

   scrserv.c
   clock.c
   zegar.c

----------------------------------------------------*/

#include <stdio.h>
#include <dos.h>
#include "scrserv.h"
#include "clock.h"

/* Ustawiam minimalny rozmiar sterty i stosu aby */
/* ograniczyc   zajetosc  pamieci    operacyjnej */

extern unsigned _heaplen = 1024;
extern unsigned _stklen  = 512;

void main( void )
{

  puts("\nDemo-zegar w programie rezydentnym");
  puts("\nZagar zainstalowany");

  /* Inicjalizacja zapisu do pamieci ekranu */
  write_init();

  /* Instalacja zegara */
  install_clock();

  /* Pozostan w pamieci (TSR),  pozostaw sobie tyle */
  /* pamieci  ile wynosi  ponizsza formula zalecana */
  /* przez Borlanda. Uwaga!!! czasami trzeba dobrac */
  /* rozmiar pozostawianej pamieci eksperymentalnie */

  keep( 0, ( _SS + ( _SP / 16 ) - _psp ) );
}

