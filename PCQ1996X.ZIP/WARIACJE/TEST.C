/*----------------------------------------------------

 test.c

 Program  demonstaracyjny  prezentujacy   mozliwosci
 wykorzystania modulu  clock.c. Nalezy  kompilowac z
 wylaczona opcja testowania przepelnienia stosu oraz
 bez optymalizacji rejestrowej.

 Projekt:

   clock.c
   scrserv.c
   test.c

 Implementacja dla kompilatorow firmy Borland

----------------------------------------------------*/

#include <conio.h>
#include <dos.h>
#include "scrserv.h"
#include "clock.h"

#define ESC 27


void main( void )
{
  int key;

  clrscr();

  cputs("\n\rDemo-zegar w programie zwyklym");
  cputs("\n\rESC konczy wykonanie programu\n\r");

  /* Inicjalizacja zapisu do pamieci ekranu */
  write_init();

  /* Instalacja zegara */
  install_clock();

  /* Cokolwiek zatrzymujacego program */
  while( ( key  =  getch() ) != ESC )
    putch( key );

  /* Deinstalacja zegara */
  uninstall_clock();
}