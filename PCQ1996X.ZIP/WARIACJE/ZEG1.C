/*---------------------------------------------------
    Implementacja zegara - sposob pierwszy.
            Namiastaka zegara.
---------------------------------------------------*/

#include <conio.h>
#include <dos.h>
#include <alloc.h>

#define ESC 27

/* Prototyp funkcji procesu drugiegoplanu */
void background_process( void );

/* Funkcja aktywnego przepytywania klawiatury */
int activ_getch( void )
{
  while( ! kbhit() )
    background_process();
  return getch();
}

/* Funkcja procesu drugiegoplanu */
void background_process( void )
{
  /* Rekord danych o czasie */
  struct time t;

  /* Zapamietaj wspolrzedne kursora */
  int cur_x = wherex();
  int cur_y = wherey();


  /* Biezaca ilosc wolnej sterty */
  gotoxy( 1, 1 );
  cprintf( "Mem: %lu", (unsigned long)coreleft() );


  /* Pobiez czas systemowy */
  gettime( &t );

  /* Wyswietl czas systemowy */
  gotoxy( 72, 1 );
  cprintf( "%02d:%02d:%02d", t.ti_hour, t.ti_min,t.ti_sec );

  /* Odtworz stara pozycje kursora */
  gotoxy( cur_x, cur_y );
}

/*----------------------------------------------------

  Niestety, podczas wyswietlania zegara przy uzyciu
  funkcji  bibliotecznych  nastepuje  brzydki efekt
  przeskoku kursora  podczas wyswietlania.  Aby  go
  uniknac wygaszamy kursor. Jezeli  jednak  jest on
  potrzebny  (linie edycyjne itp),  do wyswietlania
  zegara  najlepiej  uzyc bezposredniego  zapisu do
  pamieci ekranu, patrz spis literatury artykulu.

----------------------------------------------------*/
void main( void )
{
  int key;

  clrscr();

  gotoxy( 1, 2 );

  _setcursortype( _NOCURSOR );

  cputs( "Pisz cokolwiek:");
  while( ( key = activ_getch() ) != ESC )
    putch( key );

 _setcursortype( _NORMALCURSOR );
}