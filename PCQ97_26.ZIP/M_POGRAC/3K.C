
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>

#ifdef __MSDOS__
 #define FILENAME "3k.exe"
#else
 #define FILENAME "3k.cgi"
#endif
#define HI 256
#define LO 16
#define BACK "back.gif"
#define BLACK "black.gif"
#define WHITE "white.gif"
#define BGC "#40E060"
#define HOMEPAGE "ak.htm"

char *Code(unsigned int);
unsigned int Decode(char *);
void DrawBack(char *);
void DrawFront(unsigned int , unsigned int );
void Head(char *);
void Tail(void);
void Printf(char *, ...);

char CodeString[20];

/*********************************************************
*                                                        *
* funkcja Code: zamienia wybrany nr karty na ci�g liczb  *
* wej�cie unsigned int input: nr karty                   *
* wyj�cie char *: wska�nik na zmienn� CodeString         *
*                 zawieraj�c� wyj�ciowy ci�g cyfr        *
*                                                        *
**********************************************************/
char *Code(unsigned int input)
{
 unsigned int key,i;
 char tmp[20];

 key=1+rand()%HI;
 sprintf(tmp,"%d",(key/LO+input*key%LO+input)*HI+key);
 for(i=0;tmp[i]!=0;i++)
 {
  CodeString[2*i]=tmp[i];
  CodeString[2*i+1]= '1'+rand()%9;
 }
 CodeString[2*i+2]=0;
 return CodeString;
}

/*********************************************************
*                                                        *
* funkcja Decode: zamienia ci�g liczb na wybrany nr karty*
* wej�cie char *input: wska�nik na �a�cuch zawieraj�cy   *
*                      ci�g cyfr                         *
* wyj�cie unsigned int: wybrany nr karty                 *
*                                                        *
**********************************************************/
unsigned int Decode(char *input)
{
 unsigned int key,in,i;

 for(i=0;input[i]!=0;i++)
  CodeString[i]=input[2*i];
 in=atoi(CodeString);
 key=in%HI;
 for(i=1;i!=4;i++)
  if(in==((key/LO+i*key%LO+i)*HI+key))
   break;
 return i;
}

/*********************************************************
*                                                        *
* funkcja DrawBack: wypisuje 1 stron�                    *
* wej�cie char *input: zaszyfrowany nr karty             *
*                                                        *
**********************************************************/
void DrawBack(char *input)
{
 Printf("Zawsze nacisnij RELOAD<br>");
 Printf("<hr size=2 width=100%><br>");
 Printf("Wybierz jedna z kart:<br>");
 Printf("<hr size=2 width=100%><br>");
 Printf("<a href=\"%s?1%s\">\
<img src=\"%s\"></a>",FILENAME,input,BACK);
 Printf("&nbsp;&nbsp;");
 Printf("<a href=\"%s?2%s\">\
<img src=\"%s\"></a>",FILENAME,input,BACK);
 Printf("&nbsp;&nbsp;");
 Printf("<a href=\"%s?3%s\">\
<img src=\"%s\"></a>",FILENAME,input,BACK);
 Printf("<br>");
 Printf("<hr size=2 width=100%><br>");
}

/*********************************************************
*                                                        *
* funkcja DrawFront: wypisuje 2 stron�                   *
* wej�cie unsigned int pos: nr wylosowanej karty         *
*         unsigned int win: czy wybrana karta            *
*                                                        *
**********************************************************/
void DrawFront(unsigned int pos, unsigned int win)
{
 char what[3][15]={WHITE,WHITE,WHITE};

 strcpy(what[pos-1],BLACK);
 if(win)
  Printf("Wygrales<br><hr size=2 width=100%><br>");
 else
  Printf("Przegrales<br><hr size=2 width=100%><br>");
 Printf("<img src=\"%s\">",what[0]);
 Printf("&nbsp;&nbsp;");
 Printf("<img src=\"%s\">",what[1]);
 Printf("&nbsp;&nbsp;");
 Printf("<img src=\"%s\">",what[2]);
 Printf("<hr size=2 width=100%><br>");
 Printf("Grasz jeszcze?");
 Printf("(<a href=\"%s\">tak</a> /",FILENAME);
 Printf("<a href=\"%s\">nie</a>)<br>",HOMEPAGE);
 Printf("<hr size=2 width=100%><br>");
}

/*********************************************************
*                                                        *
* funkcja Head: wypisuje czo��wk� HTML                   *
* wej�cie char *: tytu� strony HTML                      *
*                                                        *
**********************************************************/
void Head(char *title)
{
 Printf("<HTML>");
 Printf("<HEAD>");
 Printf("<TITLE>%s</TITLE>", title);
 Printf("</HEAD>");
 Printf("<BODY>");
}

/*********************************************************
*                                                        *
* funkcja Tail: wypisuje ko�c�wk� strony HTML            *
*                                                        *
**********************************************************/
void Tail(void)
{
 Printf("</BODY>");
 Printf("</HTML>");
}

/*********************************************************
*                                                        *
* funkcja Printf: wykorzystuje printf dodaj�c znak ko�ca *
*                 linii i resetuje bufor na ko�cu        *  
* wej�cie jak w printf                                   *
*                                                        *
**********************************************************/
void Printf(char *fmt, ...)
{
 va_list argp;

 va_start(argp, fmt);
 vfprintf(stdout, fmt, argp);
 va_end(argp);
 fprintf(stdout, "\n");
 fflush(stdout);
}

/*********************************************************
*                                                        *
* program g��wny                                         *
*                                                        *
**********************************************************/
void main(void)
{
 char *QueryString;
 int card;
 time_t t;

/* inicjuje genreator */
 srand((unsigned) time(&t));

/* pobiera parametr */
 QueryString=getenv("QUERY_STRING");

/* okre�la typ dokumentu */
 printf("Content-Type: text/html\n\n");

/* pocz�tek strony HTML */
 Head("3K");
 Printf("<body bgcolor=\"%s\">",BGC);
 Printf("<font size=+4>");
 Printf("<center>");

/* je�li brak parametru - 1 strona */
/* je�li jest  parametr - 2 strona */
 if(strlen(QueryString))
 {
  card=Decode(QueryString+1);
  DrawFront(card,((QueryString[0]-'0')==card));
 }
 else
  DrawBack(Code(1+rand()%3));

/* koniec strony HTML */
 Printf("</center>");
 Printf("</font>");
 Tail();
}
