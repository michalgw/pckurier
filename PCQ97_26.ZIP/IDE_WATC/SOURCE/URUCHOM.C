/* Program zarz�dzaj�cy uruchamianiem spod IDE Borland`a */
/* program�w pisanych w Watcom C                         */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <fcntl.h>

void main (int argc,char *argv[],char *env[])
{
 int Plik;
 char Lancuch[100];

 if (argc<2)
 { printf ("brak parametru !\n"); exit (EXIT_FAILURE); }

 /* skoryguj scie�k� do Twojego ide.bat, ma by� taka sama
    jak do bc.exe */
 Plik=creat ("C:\\BORLANDC\\BIN\\IDE.BAT",S_IWUSR|O_TEXT);

 strcpy (Lancuch,"@uruchom -clear\n:jeszcze_raz\n");
 strcat (Lancuch,"@bc.exe %1 %2 %3 %4\n\0");
 write (Plik,Lancuch,strlen (Lancuch));

 /* je�li nie ma opcji -clear to ... */
 if (strcmp ("-clear",argv [1]))
 {
  strcpy (Lancuch,"@");
  strcat (Lancuch,argv [1]);
  strcat (Lancuch,"\n");
  write (Plik,Lancuch,strlen (Lancuch));
  strcpy (Lancuch,"@goto jeszcze_raz\n");
  write (Plik,Lancuch,strlen (Lancuch));
 }

 close (Plik);
}