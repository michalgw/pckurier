
#include <stdio.h>
#include "sb_det.h"

void main() {
    if ((detect_sb_port())==0) {
        printf("\n\nSoundBlaster not found.\n\n");
        exit(0);
    }
    printf("\n\nSound Blaster ");
    if((detect_sb_ver() >> 8)==3) printf("Pro ");
    printf("%u.%u ", detect_sb_ver() >> 8 \
                   , detect_sb_ver() & 0xff);
    printf("has been detected ");
    printf("at port %xh", detect_sb_port());
    printf(", IRQ %u", detect_sb_irq());
    printf(", DMA %u\n\n",detect_sb_dma());
}
