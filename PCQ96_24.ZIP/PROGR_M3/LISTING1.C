//Program w j�zyku C - model small
#include {stdio.h}
extern void oblicz(unsigned int, unsigned int);
int wysokosc=1000;

void wypisz(unsigned long int x)
{
  printf("Obj�to�� = %lu jednostek.\n",x);
}

int main(void)
{
  oblicz(300,200);//szeroko��=300, d�ugo��=200
  return 0;
}

;modu� asemblerowy
public _oblicz        ;deklaracja zewn�trznej procedury

param   STRUC         ;struktura stosu do proc. _oblicz
        dw      ?     ;BP
        dw      ?     ;IP
szer    dw      ?
dlug    dw      ?
param   ENDS

_DATA   SEGMENT word public 'DATA'
extrn   _wysokosc:word  ;deklaracja w innym module
_DATA   ENDS

extrn   _wypisz:NEAR  ;ta procedura jest implementowana
                      ;w innym module

_TEXT   SEGMENT word public 'CODE'
        assume  cs:_TEXT,ds:_DATA

        _oblicz PROC    NEAR
                push    bp
                mov     bp,sp

                mov     ax,word PTR [bp].dlug
                mul     word PTR [bp].szer
;za�o�enie, �e d�ug*szer mie�ci si� w 2 bajtach
                mul     word PTR _wysokosc
;teraz obj�to�� w DX:AX
                push    dx   ;wys�anie parametr�w na stos
                push    ax
                call    _wypisz
                pop     ax   ;pobranie parametr�w ze stosu
                pop     dx

                pop     bp
                ret
        _oblicz ENDP

_TEXT   ENDS
 END

