#include {conio.h}

int main(void)
{
  char tryb, kolor=0;
  asm {
        mov     ax,0f00h
        int     10h
        mov     tryb, al
        mov     ax,13h
        int     10h

        push    ds
        push    si
        mov     ax,0A000h
        mov     ds,ax
        mov     cx,200
        xor     si,si
      }
  ptl1:
  asm {
        push    cx
        mov     cx,320
        mov     byte PTR kolor,0
      }
  ptl2:
  asm {
        mov     al, kolor
        mov     [si], al
        inc     si
        inc     byte PTR kolor
        loop    ptl2
        pop     cx
        loop    ptl1
        pop     si
        pop     ds
  }
  getch();
  asm {
        mov     al,tryb
        xor     ah,ah
        int     10h
  }
  return 0;
}
