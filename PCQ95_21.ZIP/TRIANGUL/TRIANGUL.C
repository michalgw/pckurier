#include <conio.h>
#include <graphics.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define  OUTSIDE  1 /* punkt na zewn�trz */
#define  INSIDE   2 /* punkt wewn�trz */
#define  VERTEX   3 /* punkt jest wierzcho�kiem */
#define  EDGE     4 /* punkt le�y na brzegu wielok�ta */
#define  NOCROSS  1 /* odcinki nie przecinaj� si� */
#define  CROSS    2 /* odcinki przecinaj� si� */
#define  PARALLEL 3 /* odcinki r�wnoleg�e */
#define  IDENT    4 /* odcinki le�� na tej samej prostej */
#define  PREC     1

typedef short TRIANGLE[3];
typedef struct pointtype POINT;

/*Sprawdzenie, czy odcinki P1P2 i PAPB nie przecinaj� si�*/
int CrossSeg (POINT *prP1, POINT *prP2,
              POINT *prPA, POINT *prPB)
  {
  int iM, i21Y, iBAY, i21X, iBAX , iX, iY, nX = 0;

  i21Y=prP2->y - prP1->y;
  iBAY=prPB->y - prPA->y;
  i21X=prP2->x - prP1->x;
  iBAX=prPB->x - prPA->x;
  iM =i21Y*iBAX - iBAY*i21X;
  if (iM == 0)     /* odcinki r�wnoleg�e */
    {
    if (i21X == 0)
      {
      if (prPA->x == prP1->x && iBAX == 0)
        return IDENT; /*odcinki le�� na tej samej prostej*/
      }
    else
      {
      if (((i21Y/i21X) * (prPA->x - prP1->x) -
           (prPA->y - prP1->y)) == 0)
        return IDENT;
      else
        return PARALLEL; /* r�wnoleg�e w sensie �cis�ym */
      }
    }
  if (i21X == 0)
    {
    iX=prP1->x;
    nX=1;
    }
  if (iBAX == 0)
    {
    iX=prPA->x;
    nX=2;
    }
  if (nX == 0)
    /* licz� wsp��rz�dn� x punktu przeci�cia */
    iX=(i21X*(prPB->x*prPA->y - prPA->x*prPB->y) +
        iBAX*(prP1->x*prP2->y - prP2->x*prP1->y)) /iM;
  if ((prP1->x >= iX && iX >= prP2->x) ||
      (prP1->x <= iX && iX <= prP2->x))
    if ((prPA->x >= iX && iX >= prPB->x) ||
        (prPA->x <= iX && iX <= prPB->x))
      {
      if (nX == 1)
        iY=(iBAY*(iX - prPA->x))/iBAX + prPA->y;
      else
        iY=(i21Y*(iX - prP1->x))/i21X + prP1->y;
      if ((prP1->y >= iY && iY >= prP2->y) ||
          (prP1->y <= iY && iY <= prP2->y))
        if ((prPA->y >= iY && iY >= prPB->y) ||
            (prPA->y <= iY && iY <= prPB->y))
  /* sprawdzenie, czy punkt przeci�cia nie ma takich samych
     wsp��rz�dnych jak jeden z wierzcho�k�w odcinka AB */
          if ((iX != prPA->x || iY != prPA->y) &&
              (iX != prPB->x || iY != prPB->y))
            return CROSS;
      }
  return NOCROSS;
  }

/*Sprawdzenie metod� przeci�� p��prostej, czy punkt le�y
 wewn�trz konturu. iPrec - precyzja, z jak� maj� by� 
 dokonywane por�wnywania dla punkt�w na brzegach wielok�ta*/
int InPoly (POINT *prVert, short nNoVert, POINT *prPnt,
            int iPrec)
  {
  short i, j, nCrossCnt, i1;
  int iXP, iYP, iX0, iX1, iY0, iY1, iXA, iYA;

  nCrossCnt=0;
  iXP=prPnt->x;
  iYP=prPnt->y;
  for (i=0; i<nNoVert; i++)
    {
    /* indeksy kolejnych wierzcho�k�w w tablicy */
    i1=(i+1) % nNoVert;
    iX0=prVert[i].x;
    iX1=prVert[i1].x;
    iY0=prVert[i].y;
    iY1=prVert[i1].y;
    fabs(iY0-iYP);
    /* czy punkt pokrywa si� z wierzcho�kiem struktury */
    if (fabs(iX0-iXP)<iPrec && fabs(iY0-iYP)<iPrec)
      return VERTEX;
    if (fabs(iX1-iXP)<iPrec && fabs(iY1-iYP)<iPrec)
      return VERTEX;
    if (iY0==iY1)
      {  /* czy punkt le�y na boku */
      if ((fabs(iY0-iYP)<iPrec) &&
          ((iX0<iXP && iXP<iX1) || (iX1<iXP && iXP<iX0)))
        return EDGE;
      }
    else
      {
      if ((iY0<iYP && iYP<iY1) || (iY1<iYP && iYP<iY0))
        {
        iXA = iX0+((iYP-iY0)*(iX1-iX0)/(iY1-iY0));
        if (fabs(iXA-iXP)<iPrec)
          return EDGE;
        if (iXA>iXP)
          nCrossCnt++;
        }
      else
        if (iY1==iYP && iX1>iXP)
          {             /* koniec odcinka na p��prostej,
                           pocz�tek poza prost� */
          for (j=1; j<nNoVert; j++)
            {
            iYA = prVert[(i1+j) % nNoVert].y;
            if (iYA != iYP)
              break;
            }
          if (j==nNoVert)
            return OUTSIDE;
          if ((iYA<iYP && iYP<iY0) || (iYA>iYP && iYP>iY0))
            nCrossCnt ++;
          }
      }
    }
  if(nCrossCnt % 2)
    return INSIDE; /* nieparzysta liczba przeci��
                      - punkt le�y wewn�trz */
  else
    return OUTSIDE; /* parzysta - na zewn�trz */
  }

/*---------------------------------------------------------
Podzia� dowolnego wielok�ta (r�wnie� wkl�s�ego) na tr�jk�ty.
prVert     - tablica punkt�w wierzcho�kowych wielok�ta;
nNoVert    - liczba wierzcho�k�w wielok�ta;
p2anTriang - tablica punkt�w okre�laj�cych numery
       wierzcho�k�w tr�jk�t�w powsta�ych na skutek podzia�u;
pnTriangles - liczba powsta�ych tr�jk�t�w;
---------------------------------------------------------*/
void Poly2Triangles (POINT *prVert, short nNoVert,
          TRIANGLE **p2anTriang, short *pnTriangles)
  {
  short i, j, i1, i2, nRet;
  POINT rPnt = {0};
  struct {
         POINT *prVert;
         short *pnVertNum;
         } rVert;
  *p2anTriang = calloc (nNoVert - 2, 3 * sizeof (short));
  /* tworzenie tablicy struktur opisuj�cych wierzcho�ki */
  rVert.prVert = calloc (nNoVert, sizeof (POINT));
  rVert.pnVertNum = calloc (nNoVert, sizeof (short));
  for (i = 0; i < nNoVert; i++)
    {
    rVert.prVert[i] = prVert[i];
    rVert.pnVertNum[i] = i;
    }
  /* buduj� tr�jk�ty z trzech kolejnych wierzcho�k�w
     nast�puj�cych po sobie */
  while (nNoVert > 3)
    {
    for (i=0; i<nNoVert; i++)
      {
      i2=(i+2) % nNoVert;
      /* sprawdzam, czy odcinek nie przecina �adnego z
         bok�w wielok�ta o nNoVert wierzcho�kach */
      for (j=0; j<nNoVert; j++)
        {
        nRet=CrossSeg(rVert.prVert+i, rVert.prVert+i2,
            rVert.prVert+j, rVert.prVert+((j+1)%nNoVert));
        if (nRet == CROSS)
          break;
        }
      if (nRet == CROSS)
        continue;
   /* je�li odcinek nie przecina innych, to sprawdzenie,
      czy odcinek le�y wewn�trz wielok�ta przez sprawdzenie,
      czy punkt �rodkowy tego odcinka le�y wewn�trz */
      rPnt.x=(rVert.prVert[i].x + rVert.prVert[i2].x)/2;
      rPnt.y=(rVert.prVert[i].y + rVert.prVert[i2].y)/2;
      nRet=InPoly(rVert.prVert, nNoVert, &rPnt, PREC);
      if (nRet != OUTSIDE)
   /* je�eli wewn�trz lub na brzegu, to zapisuj� tr�jk�t:
      i,(i+1)%nNoVert,(i+2)%nNoVert i zmniejszam liczb�
      wierzcho�k�w wielok�ta o 1 (przesuwam wierzcho�ki
      w tablicy) */
       {
       i1=(i+1) % nNoVert;
       (*p2anTriang)[*pnTriangles][0]=rVert.pnVertNum[i];
       (*p2anTriang)[*pnTriangles][1]=rVert.pnVertNum[i1];
       (*p2anTriang)[*pnTriangles][2]=rVert.pnVertNum[i2];
       (*pnTriangles) ++;
       nNoVert --;
       for (j=i1; j<nNoVert; j++)
         {
         rVert.prVert[j]=rVert.prVert[j+1];
         rVert.pnVertNum[j]=rVert.pnVertNum[j+1];
         }
       if (nNoVert == 3)
         break;
       }
      } //for (i < liczby wierzcho�k�w);
    } //while (liczba wierzcholk�w > 3);
  (*p2anTriang)[*pnTriangles][0]=rVert.pnVertNum[0];
  (*p2anTriang)[*pnTriangles][1]=rVert.pnVertNum[1];
  (*p2anTriang)[*pnTriangles][2]=rVert.pnVertNum[2];
  (*pnTriangles)++;
  free(rVert.prVert);
  free(rVert.pnVertNum);
  } /* Poly2Triangles (); */

void Init (void)
  {
  int iMode, iDrv = DETECT;
  initgraph (&iDrv, &iMode, "");
  if (graphresult() != grOk) exit (1);
  }

void main (void)
  {
  short nTriangles = 0, i;
  TRIANGLE *panTriang = NULL;
  POINT arTriang[3];
  POINT prVert [] = { {150,105}, {195,120}, {180,60},
    {195,15}, {255,15}, {315,30}, {375,15}, {435,15},
    {375,60}, {375,120}, {450,165}, {510,240}, {435,240},
    {390,210}, {330,210}, {345,225}, {390,225}, {345,255},
    {345,225}, {330,210}, {315,255}, {375,270}, {435,240},
    {510,240}, {495,300}, {435,345}, {420,390}, {390,390},
    {345,330}, {300,375}, {225,375}, {225,315}, {135,300},
    {60,300}, {30,330}, {15,270}, {90,240}, {75,195},
    {30,180}, {30,135}, {75,120}, {135,150}, {135,135},
    {90,105}, {120,60}, {120,110} };
  Init();
  setfillstyle(SOLID_FILL, CYAN);
  setlinestyle(SOLID_LINE, 0, NORM_WIDTH);
  setcolor(WHITE);
  moveto(prVert[0].x, prVert[0].y);
  for (i=1; i<sizeof(prVert) / sizeof(POINT); i++)
    lineto(prVert[i].x, prVert[i].y);
  lineto (prVert[0].x, prVert[0].y);
  Poly2Triangles(prVert, sizeof(prVert)/sizeof(POINT),
       &panTriang, &nTriangles); /* podzia� wielok�ta */
  for (i=0; i<nTriangles; i++)
    { /*rysowanie tr�jk�t�w powsta�ych na skutek podzia�u*/
    arTriang[0]=prVert[panTriang[i][0]];
    arTriang[1]=prVert[panTriang[i][1]];
    arTriang[2]=prVert[panTriang[i][2]];
    drawpoly(3, (int *)arTriang);
    fillpoly(3, (int *)arTriang);
    getch ();
    }
  free(panTriang);
  }
