int i,j,z;
//  tablica pal powinna zawiera� warto�ci tablicy defpal
//  z programu w assemblerze, jej struktura to int pal [256][2]
// wpisuj kolejne warto�ci z tablicy defpal do pal


void fadeoff(void)
{
i=63;
while (i!=0)
{
i=i-1;
outport(968,0);
for (j=0;j<256;j++) for (z=0;z<3;z++)
if (pal[j][z] < i) outport(969,pal[j][z]);
else outport(969, i);
}
}

void fadeon(void)
{
for (i=0;i<64;i++)
{
outport(968,0);
for (j=0;j<256;j++) for (z=0;z<3;z++)
if (pal[j][z] > i) outport(969,i);
else outport(969,pal[j][z]);
}
}

