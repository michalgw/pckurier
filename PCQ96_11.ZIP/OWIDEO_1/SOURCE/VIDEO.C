#include <windows.h>
#include <mmsystem.h>
#include <commdlg.h>
#include <stdlib.h>
#include <mem.h>

BOOL bOdtwarza = FALSE, bPauza = FALSE;
char szOdtwarzanyPlik[13] = {"[Bez nazwy]"}, szBufor[100];

#pragma argsused
BOOL CALLBACK _export VCR(HWND hOkno, WORD wKomunikat, WPARAM wParam, LPARAM lParam)
  {
  switch(wKomunikat)
    {
    case WM_INITDIALOG:
      {
      RECT rcProstokat;

      GetWindowRect(hOkno, &rcProstokat);
      SetWindowPos(hOkno, HWND_TOPMOST, 0, 0, rcProstokat.right-rcProstokat.left, rcProstokat.bottom-rcProstokat.top, NULL);
      return TRUE;
      }
    case WM_CLOSE:
      SendMessage(hOkno, WM_COMMAND, 105, 0l);
      EndDialog(hOkno, FALSE);
      return TRUE;
    case WM_COMMAND:
      switch(wParam)
        {
        case 101: //power
          SendMessage(hOkno, WM_CLOSE, 0, 0l);
          break;
        case 102: //eject
          {
          OPENFILENAME ofn;
          char szFiltr[] = {"Wszystkie pliki\0*.*\0"};

          memset(&ofn, 0, sizeof(OPENFILENAME));
          ofn.lStructSize = sizeof(OPENFILENAME);
          ofn.hwndOwner = hOkno;
          ofn.lpstrFilter = szFiltr;
          ofn.nFilterIndex = 1;
          ofn.lpstrFileTitle = szOdtwarzanyPlik;
          ofn.nMaxFileTitle = sizeof(szOdtwarzanyPlik);
          ofn.Flags = OFN_HIDEREADONLY|OFN_PATHMUSTEXIST|OFN_FILEMUSTEXIST;
          if(GetOpenFileName(&ofn))
            SendMessage(hOkno, WM_COMMAND, 105, 0l);
          break;
          }
        case 103: //play
          {
          HWND hOknoMonitora;
          RECT rcProstokat;

          if(bOdtwarza)
            break;
          lstrcpy(szBufor, "open ");
          lstrcat(szBufor, szOdtwarzanyPlik);
          lstrcat(szBufor, " alias vcr");
          if(mciSendString(szBufor, NULL, 0, NULL))
            {
            MessageBox(hOkno, "Niew�a�ciwa nazwa pliku.\nTen plik nie jest plikiem z zapisem video.", szOdtwarzanyPlik, MB_ICONEXCLAMATION|MB_OK);
            break;
            }
          mciSendString("window vcr text \"Video Monitor\"", NULL, 0, NULL);
          mciSendString("status vcr window handle", szBufor, sizeof(szBufor), NULL);
          hOknoMonitora = atoi(szBufor);
          GetWindowRect(hOknoMonitora, &rcProstokat);
          MoveWindow(hOknoMonitora, (GetSystemMetrics(SM_CXSCREEN)-(rcProstokat.right-rcProstokat.left))/2, (GetSystemMetrics(SM_CYSCREEN)-(rcProstokat.bottom-rcProstokat.top))/2, rcProstokat.right-rcProstokat.left, rcProstokat.bottom-rcProstokat.top, FALSE);
          mciSendString("play vcr", NULL, 0, NULL);
          bOdtwarza = TRUE;
          bPauza = FALSE;
          break;
          }
        case 104: //pause
          if(!bPauza)
            mciSendString("pause vcr", NULL, 0, NULL);
          else
            mciSendString("play vcr", NULL, 0, NULL);
          bPauza = !bPauza;
          break;
        case 105: //stop
          mciSendString("stop vcr", NULL, 0, NULL);
          mciSendString("close vcr", NULL, 0, NULL);
          bOdtwarza = bPauza = FALSE;
          break;
        case 106: //rewind
        case 107: //ff
          lstrcpy(szBufor, "step vcr by 10");
          if(wParam == 106)
            lstrcat(szBufor, " reverse");
          mciSendString(szBufor, NULL, 0, NULL);
          if(bOdtwarza && !bPauza)
            mciSendString("play vcr", NULL, 0, NULL);
        }
      return TRUE;
    }
  return FALSE;
  }

#pragma argsused
int PASCAL WinMain(HINSTANCE hInstancja, HINSTANCE hPopInst, LPSTR lpszLinia, int nStan)
  {
  FARPROC wskfun = MakeProcInstance((FARPROC)VCR, hInstancja);
  DialogBox(hInstancja, "VCR", NULL, wskfun);
  FreeProcInstance(wskfun);
  return 0;
  }
