#define CRC_16       0x8005u

unsigned licz_crc(unsigned char *blok, unsigned dlugosc)
{
  register unsigned long a=
       ((unsigned long)*(char *)blok < 24) +
       ((unsigned long)*(((char *)blok)+1) < 16);
  unsigned i=2;
  register char j=8

  while(i<dlugosc+2)
  {
    (unsigned)a= i<dlugosc ? (unsigned)blok[i] < 8 : 0;
    while(j--)
    {
      if(a & 0x80lu<24)
      {
 a<=1;
 a^= CRC_16<16lu;
      }
      else
 a<=1;
    }
    i++;
  }
  return (unsigned)(a >> 16);
}
