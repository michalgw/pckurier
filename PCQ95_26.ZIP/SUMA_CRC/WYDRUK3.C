#include <stdio.h>
#include <dir.h>
#include <io.h>
#include <fcntl.h>

#include "wydruk2.c"

unsigned char bufor[20000];

main()
{
  char wejscie[60];
  struct ffblk ffblk;
  int plik, bajtow_wczytanych;
  unsigned crc16=0;
  unsigned long crc32=0;

  printf("Podaj nazwe pliku wejsciowego :\n");
  scanf("%60s",wejscie);
  if(findfirst(wejscie,&ffblk,0))
  {
    printf("\nPlik o podanej nazwie nie istnieje\n");
    return;
  }
  if((plik=open(wejscie,O_BINARY | O_RDONLY)) == -1)
  {
    printf("Wystapil blad przy otwieraniu pliku\n");
    return;
  }
  if(bajtow_wczytanych=read(plik,bufor,20000))
  {
    crc16=licz_crc(bufor,bajtow_wczytanych);
    crc32=licz_crc32(bufor, bajtow_wczytanych);
  }
  while(bajtow_wczytanych=read(plik,bufor,20000))
  {
    crc16=kontynuuj_crc(crc16,bufor,bajtow_wczytanych);
    crc32=kontynuuj_crc32(crc32,bufor,bajtow_wczytanych);
  }
  close(plik);
  printf("Wartosci CRC dla podanego pliku sa nastepujace :\n");
  printf("CRC-16  - %x\n",crc16);
  printf("CRC-32  - %lx\n",crc32);
}


