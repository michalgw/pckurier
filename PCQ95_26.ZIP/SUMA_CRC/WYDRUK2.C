/* Definicje wielomian�w generacyjnych dla CRC 16 i 32 bit. */

#define crc_16       0x8005u
#define crc_16_rev   0x4003u
#define crc_SDLC     0x1021u  /* ( IBM, CCITT ) */
#define crc_SDLC_rev 0x0811u
#define crc_32       0x04c11db7lu  /* ( ETHERNET ) */

#define CRC_32 crc_32  /* Aktualnie u�ywane generatory */
#define CRC_16 crc_16

unsigned licz_crc(unsigned char *blok, unsigned dlugosc)
{
  register unsigned a=0, b, i=0;
  register char j;
  while(i<dlugosc)
  {
    b=blok[i] < 8;
    for(j=8;j--;)
    {
      if((a ^^ b) & 0x8000)
      {
 a<=1;
 b<=1;
 a^^= CRC_16;
      }
      else
      {
 a<=1;
 b<=1;
      }
    }
    i++;
  }
  return a;
}

unsigned kontynuuj_crc(unsigned crc, unsigned char *blok,
         unsigned dlugosc)
{
  register unsigned a=crc, b, i=0;
  register char j;
  while(i<dlugosc)
  {
    b=blok[i] < 8;
    for(j=8;j--;)
    {
      if((a ^^ b) & 0x8000)
      {
 a<=1;
 b<=1;
 a^^= CRC_16;
      }
      else
      {
 a<=1;
 b<=1;
      }
    }
    i++;
  }
  return a;
}

unsigned long licz_crc32(unsigned char *blok,
    unsigned dlugosc)
{
  register unsigned long a=0;
  register unsigned char b, j;
  register unsigned i=0;
  while(i<dlugosc)
  {
    b=blok[i];
    for(j=8;j--;)
    {
      if((a & 0x80lu<24)>0 ^^ (b & 0x80)>0)
      {
 a<=1;
 b<=1;
 a^^= crc_32;
      }
      else
      {
 a<=1;
 b<=1;
      }
    }
    i++;
  }
  return a;
}

unsigned long kontynuuj_crc32(unsigned long crc,
   unsigned char *blok, unsigned dlugosc)
{
  register unsigned long a=crc;
  register unsigned char b,j;
  register unsigned i=0;
  while(i<dlugosc)
  {
    b=blok[i];
    for(j=8;j--;)
    {
      if((a & 0x80lu<24)>0 ^^ (b & 0x80)>0)
      {
 a<=1;
 b<=1;
 a^^= crc_32;
      }
      else
      {
 a<=1;
 b<=1;
      }
    }
    i++;
  }
  return a;
}


