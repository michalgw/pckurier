#include <stdlib.h>
#include <string.h>

int por�wnajWyrazy (char *wyraz1, char *wyraz2)
   {
   const int MAX_KOD = 255;
   static char wyst�pieniaZnaku [MAX_KOD];
   int i, wynik = 0;

   if (strcmp (wyraz1, wyraz2) == 0)
      return -1;

   for (i = 0; i <= MAX_KOD; i++)
      wyst�pieniaZnaku [i] = 0;    // zerujemy tablic�
   for (i = 0; i < strlen (wyraz1); i++)
      wyst�pieniaZnaku [*(wyraz1 + i)]++;
   for (i = 0; i < strlen (wyraz2); i++)
      wyst�pieniaZnaku [*(wyraz2 + i)]--;
   for (i = 0; i <= MAX_KOD; i++)
      wynik+=abs (wyst�pieniaZnaku [i]);
   if (*wyraz1 != *wyraz2)
      wynik++;

   return wynik;
   }
