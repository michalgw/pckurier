// model pami�ci small

#include {conio.h}

extern int initgraph(void);
extern void closegraph(int);
extern void rysuj(void);

int main()
{
  int tryb;
  tryb=initgraph();
  rysuj();
  getch();
  closegraph(tryb);
  return 0;
}

;modu� w asemblerze
public _initgraph,_closegraph,_rysuj

_TEXT   SEGMENT word public 'CODE'
        assume   cs:_TEXT

        _initgraph      PROC    NEAR
                        mov     ax,0f00h
                        int     10h    ;do AL obecny tryb
                        push    ax

                        mov     ax,13h
                        int     10h
                        pop     ax     ;w AX zwracany wynik
                        ret
        _initgraph      ENDP

        _closegraph     PROC    NEAR
        zam     STRUC
                dw      ?      ;BP
                dw      ?      ;�lad rozkazu CALL (tutaj IP)
        tr      dw      ?      ;przekazany parametr
        zam     ENDS
                        push    bp
                        mov     bp,sp

                        mov     ax,[bp].tr
                        xor     ah,ah
                        int     10h

                        pop     bp
                        ret
        _closegraph     ENDP

        _rysuj          PROC    NEAR
                        push    si
                        push    ds

                        mov     ax,0A000h   ;do DS segment 
                        mov     ds,ax       ;pami�ci ekranu
                        mov     cx,200
                        xor     si,si
                ptl1:   push    cx
                        mov     cx,320
                        xor     al,al
                ptl2:   mov     [si],al
                        inc     si
                        inc     al
                        loop    ptl2
                        pop     cx
                        loop    ptl1

                        pop     ds
                        pop     si
                        ret
        _rysuj          ENDP

_TEXT   ENDS
        END
