
/* Przyk�ad odtwarzania d�wi�ku poprzez kana� DMA */
/* Autor : Tomasz Soroczy�ski, Katowice 1994      */

#include <stdio.h>
#include <alloc.h>
#include <dos.h>
#include <mem.h>
#include "sb_bas.h"
#include "dma.h"

#define word unsigned int
#define byte unsigned char

#define SET_TIME_CONST 0x40
#define DMA_8_BIT_OUT 0x14
#define OK 0
#define ERROR -1
#define PLAY_FREQ 16000

/* Standardowe parametry karty SoundBlaster */
/* Ustawia� zale�nie od konfiguracji karty  */

#define SB_IO 0x220
#define SB_IRQ 7
#define SB_DMA 1

char far *buffer;
byte page1, page2;
word tr1_lenght, tr2_lenght, page_ofs1, page_ofs2;
int marker, int_number;

/* Procedur� nale�y wywo�ywa� po ka�dym */
/* transferze DMA do karty SB           */

void sb_reset() {

    asm {
        mov     dx,SB_IO
        add     dx,0eh
        in      al,dx
        sub     dx,2
    }

sb_reset_1:
    asm {
        in      al,dx
        or      al,al
        js      sb_reset_1
    }
}

/* Procedury obs�ugi IRQ przerwania karty SB */

void interrupt (*old_irq)();

void interrupt new_irq() {

    sb_reset();
    marker=1;
    outport(0x20, 0x20);
    old_irq();
}

/* Procedura rezerwuje, dzieli i czy�ci bufor DMA */

int get_dma_buf() {

    long int physical1, physical2;
    word buf_ofs, buf_seg;

    if((buffer=farmalloc(64000L))==NULL) return ERROR;
    buf_seg=FP_SEG(buffer);
    buf_ofs=FP_OFF(buffer);
    physical1=((long int)buf_seg < 4L) + buf_ofs;
    page1=physical1 >> 16;
    page2=page1 + 1;
    physical2=page2 < 16L;
    page_ofs1=physical1 - (page1 < 16L);
    page_ofs2=0;
    tr1_lenght=physical2 - physical1;
    tr2_lenght=64000 - tr1_lenght;
    if(tr1_lenght>=64000) {
        tr1_lenght=64000;
        tr2_lenght=0;
    }
    if(tr1_lenght > 0) tr1_lenght--;
    if(tr2_lenght > 0) tr2_lenght--;
    _fmemset(buffer, 0x80, 64000L);     /* Czy�� bufor */
    return OK;
}

/* Procedura zwalnia bufor DMA */

void free_dma_buf() {

    farfree(buffer);
}

/* Procedura ustawia nowy wektor przerwa� IRQ */

int set_new_irq(int irq_number) {

    switch (irq_number) {
        case 2 : {
            int_number=8 + 2;
            break;
        }
        case 3 : {
            int_number=8 + 3;
            break;
        }
        case 5 : {
            int_number=8 + 5;
            break;
        }
        case 7 : {
            int_number=8 + 7;
            break;
        }
        case 10 : {
            int_number=0x72;
            break;
        }
        default : return ERROR;
    }
    old_irq=getvect(int_number);
    setvect(int_number, new_irq);
    return OK;
}

/* Procedura ustawia stary wektor przerwa� IRQ */

void set_old_irq() {

    setvect(int_number, old_irq);
}

/* Procedura ustawia zmienne potrzebne */
/* do programowania kontrolera DMA     */

int select_dma(int dma_channel) {

    switch (dma_channel) {

        case 1 : {
            dma_channel=1;
            dmabaseadd=2;
            dmapagereg=0x83;
            dmalenght=3;
            break;
        }
        case 3 : {
            dma_channel=3;
            dmabaseadd=6;
            dmapagereg=0x82;
            dmalenght=7;
            break;
        }
        default : return ERROR;
    }
    dma_mode=0x58;
    reset_dma();
    return OK;
}

/* Procedura ustawia cz�stotliwo�� odtwarzania */

void set_play_freq(word freq) {

    if((freq < 4000) || (freq > 44000)) freq=12000;
    dsp_out(SET_TIME_CONST);
    dsp_out(256 - (1000000L / freq));
}

void main(int argc, char *argv[]) {

    FILE *f;

    if(argc==1) {
        printf("\n\nUsage : TESTPLAY <file.ext>\n\n");
        exit(1);
    }

    if(set_new_irq(SB_IRQ)==ERROR) {
        printf("\n\nBad IRQ !!!\n\n");
        exit(2);
    }
    if((select_dma(SB_DMA))==ERROR) {
        printf("\n\nBad DMA channel !!!\n\n");
        exit(3);
    }
    if(sb_init(SB_IO)==ERROR) {
        printf("\n\nError initialilizing SB !!!\n\n");
        exit(3);
    }
    if((f=fopen(argv[1], "rb"))==NULL) {
        printf("\n\nFile not found !!!\n\n");
        exit(4);
    }
    if(get_dma_buf()==ERROR) {
        printf("\n\nNot enought free memory !!!\n\n");
        fclose(f);
        exit(5);
    }
    fread(buffer, 64000, 1, f);
    fclose(f);
    dsp_out(ON_SPEAKER);
    set_play_freq(PLAY_FREQ);
    enable();
    outport(0x21, 0);
    outport(0xA1, 0);
    prog_dma(page1, page_ofs1, tr1_lenght);
    dsp_out(DMA_8_BIT_OUT);
    dsp_out(tr1_lenght & 0xff);
    dsp_out(tr1_lenght >> 8);
    while(marker!=1);
    marker=0;
    prog_dma(page2, page_ofs2, tr2_lenght);
    dsp_out(DMA_8_BIT_OUT);
    dsp_out(tr2_lenght & 0xff);
    dsp_out(tr2_lenght >> 8);
    while(marker!=1);
    dsp_out(OFF_SPEAKER);
    free_dma_buf();
    set_old_irq();
}
