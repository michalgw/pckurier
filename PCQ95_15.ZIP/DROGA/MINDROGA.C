/* Wyznaczanie najkr�tszej drogi w sieci */
/* W ANSI C opracowa�: Wojciech Kozera   */

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <values.h>
#define N 20        /* maksymalna liczba wierzcho�k�w */
#define INF MAXINT

char cechowanie(int, int, int, int [][N], int [], int []);
int oznacz(int, int, int *);
void druk(int, int, int *);
int czytaj(int);
     /* tablica wag reprezentuj�ca sie� */
int a[N][N] = {{   0,  15, INF, INF,   9, INF },
        { INF,   0,  35,   3, INF, INF },
        { INF,  16,   0,   6, INF,  21 },
        { INF, INF, INF,   0,   2,   7 },
        { INF,   4, INF,   2,   0, INF },
        { INF, INF,   5, INF, INF,   0 }};

int main(void)
{
  int n = 6; /* liczba wierzcho�k�w w przyk�adowej sieci */
  int s;     /* wierzcho�ek pocz�tkowy drogi (�r�d�o)    */
  int t;     /* wierzcho�ek ko�cowy drogi (odp�yw)       */
  char ok;   /* zmienna przyjmuj�ca warto�� 0, gdy nie ma */
      /* drogi z "s" do "t", lub 1 - gdy istnieje */
  int d[N];  /* po zako�czeniu algorytmu oraz gdy  ok=1, */
      /* element d[t] tej tablicy zawiera d�ugo�� */
      /* najkr�tszej drogi                        */
  int p[N];  /* tablica pozwalaj�ca wyznaczy� kolejne    */
      /* wierzcho�ki najkr�tszej drogi            */
  clrscr();
  printf("Wierzcho�ek pocz�tkowy drogi [0..%d]  s = ",--n);
  s = czytaj(n);
  printf("Wierzcho�ek ko�cowy drogi [0..%d]     t = ",n);
  t = czytaj(n);
  ok = cechowanie(n, s, t, a, d, p);
  if (!ok)
    printf("\nW sieci nie ma drogi z %d do %d !\n\a", s, t);
  else {
    printf("\nD�ugo�� najkr�tszej drogi z %d do %d "
    "wynosi %d.\n", s, t, d[t]);
    printf("Kolejne wierzcho�ki najkr�tszej drogi:\n");
    druk(s, t, p); printf("%3d\n", t);
  }
  getch();
  return 0;
}

char cechowanie(int n, int s, int t,
  int a[][N], int d[], int p[])
/* funkcja realizuj�ca algorytm Dijkstry */
{
  int c[N], min, i, k, v, x, y, z ;
  char ok;

  for (i = 0; i <= n; i++) {
    d[i] = INF; c[i] = i;
  }
  d[s] = 0; ok = 1; y = s; k = n;
  k = oznacz(s, k, c); x = s;
  while (x != t) {
    for (i = 0; i <= k ; i++) {
      x = c[i];
      if (a[y][x] < INF) {   /* realizacja zale�no�ci (1) */
 min = d[y] + a[y][x];
 if (min < d[x]) {
   d[x] = min; p[x] = y;
 }
      }
    }
  z = INF;
  for (i = 0; i <= k; i++) {
    x = c[i];
    if (d[x] < z)
      { v = x; z = d[x]; }
  }
  if (z < INF)
    { x = c[v]; y = v; k = oznacz(v, k, c); }
  else
    { ok = 0; x = t; }
  }
  return ok;
}

int oznacz(int v, int k, int c[])
/* funkcja wydzielaj�ca wierzcho�ki nieocechowane */
{
  int i;

  for (i = 0; v != c[i]; i++);
  c[i] = c[k];
  return --k;
}

void druk(int s, int t, int p[])
/* funkcja wy�wietlaj�ca kolejne numery wierzcho�k�w
   najkr�tszej drogi */
{
  if (t != s) {
    t = p[t];
    druk(s, t, p);
    printf("%3d", t);
  }
}

int czytaj(int n)
/* funkcja pozwalaj�ca wprowadzi� numer wierzcho�ka
   z zakresu [0..n] */
{
  int x;

  scanf("%d", &x);
  if (x < 0 || x > n) {
    printf("\n***  Z�a dana ! ***\n\a");
    getch(); exit(1);
  }
  return x;
}
