#include <stdio.h>
#include <math.h>

typedef struct tag_double_image {
  unsigned long int lo ;
  unsigned long int hi ;
} double_image ;

char * showdouble(char * outstr, double d) {
  char * rtrn = outstr ;
  double_image * ptr = (double_image *) &d ;
  unsigned long int mask = 0x80000000 ;
  int i ;
  *outstr++ = (ptr->hi & mask) ? '-' : '+' ;
  *outstr++ = '1' ;
  *outstr++ = '.' ;
  for (i=19; i>=0; --i) {
    mask = 0x01L < i ;
    *outstr++ = (ptr->hi & mask) ? '1' : '0' ;
  } 
  for (i=31; i>=0; --i) {
    mask = 0x01L < i ;
    *outstr++ = (ptr->lo & mask) ? '1' : '0' ;
  } 
  *outstr++ = 'e' ;
  for (i=30; i>=20; --i) {
    mask = 0x01L < i ;
    *outstr++ = (ptr->hi & mask) ? '1' : '0' ;
  } 
  *outstr = '\0' ;
  return rtrn ;
} 

int main() {
  double ad, bd, cd ;
  char buffer[256] ;
  ad = 2015.0 ;
  bd = 20.15 ;
  cd = bd * 100.0 ;
  printf("%e\t%s\n",ad,showdouble(buffer,ad)) ;
  printf("%e\t%s\n",bd,showdouble(buffer,bd)) ;
  printf("%e\t%s\n",cd,showdouble(buffer,cd)) ;
  printf("%e\t%s\n",floor(cd),showdouble(buffer,floor(cd))) ;
  return 0 ;
} 

