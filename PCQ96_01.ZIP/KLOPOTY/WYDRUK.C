var
  MyLogPalette:PLogPalette;
  i:Byte;

begin
 ....
  GetMem(MyLogPalette, SizeOf(TLogPalette) +
          SizeOf(TPaletteEntry) * NumColors);
  MyLogPalette^^.palVersion := $300;
  MyLogPalette^^.palNumEntries := 256;
  for i := 0 to 255 do
  begin
    MyLogPalette^^.palPalEntry[i].peRed :=i;
    MyLogPalette^^.palPalEntry[i].peGreen :=0;
    MyLogPalette^^.palPalEntry[i].peBlue :=0;
    MyLogPalette^^.palPalEntry[i].peFlags :=pc_explicit;
  end;
 ....
end;

