
#include <stdio.h>
#include <alloc.h>
#include <dos.h>
#include "sb_bas.h"

unsigned char far *buffer;

/* Procedura wypisuje b��d i zwraca jego numer */
/* W zmiennej ERRORLEVEL                       */

void error(int number) {

    switch (number) {
        case 1 : {
            printf("\n\nNie znaleziono pliku.\n\n");
            break;
        }
        case 2 : {
            printf("\n\nBlad odczytu pliku.\n\n");
            break;
        }
        case 3 : {
            printf("\n\nBlad inicjalizacji karty SB.\n\n");
            break;
        }
    }
    farfree(buffer);
    exit(number);
}

/* Procedura zwraca d�ugo�� pliku */

long int filesize(FILE *f) {

    long int old, size;

    old=ftell(f);
    fseek(f, 0L, SEEK_END);
    size=ftell(f);
    fseek(f, old, SEEK_SET);
    return size;
}

void main(int argc, char *argv[]) {

    FILE *f;
    unsigned int lenght, x;

    if(sb_init(0x220)==1) error(3);
    dsp_out(ON_SPEAKER);
    buffer=farmalloc(64000L);
    if((f=fopen(argv[1], "rb"))==NULL) error(1);
    lenght=filesize(f);
    if(filesize(f) > 64000L) lenght=64000;
    if((fread(buffer, lenght, 1, f))!=1) error(2);
    fclose(f);
    for(x=0;x<lenght;x++) {
        dsp_out(DAC_OUT);
        dsp_out(buffer[x]);
    }
    dsp_out(OFF_SPEAKER);
    farfree(buffer);
}



