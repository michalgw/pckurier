
#include <stdio.h>
#include <dos.h>
#include <mem.h>
#include "sb_bas.h"

unsigned char far *screen;

void main() {

    union REGS reg;
    unsigned int ofs, x;

    if(sb_init(0x220)==1) {
        printf("B��d inicjalizacji karty SB.\n\n");
        exit(1);
    }
    dsp_out(OFF_SPEAKER);
    reg.x.ax=0x13;
    int86(0x10, &reg, &reg);
    screen=MK_FP(0xA000, 0);
    do {
        _fmemset(screen, 0, 64000);
        for(x=0;x<=319;x++) {
            dsp_out(ADC_IN);
            ofs=((dsp_in() / 2) + 20) * 320;
            screen[ofs + x]=0x63;
        }
    } while(inportb(0x60)!=1);      /* Czekaj na ESC */
    reg.x.ax=0x3;
    int86(0x10, &reg, &reg);
}



