/*********************************************************
    Plik: PROTECT.C
    Autor: Sebastian Maleszewski
           Wroc�aw, 18 grudzien 1994

    Opis: Program do zapezbieczania plik�w przed
          uszkodzeniem
**********************************************************/

#include <ctype.h>
#include <fcntl.h>
#include <dir.h>
#include <string.h>
#include <stdio.h>
#include <io.h>
#include <sys\stat.h>
#include <stdlib.h>
#include <conio.h>

/******************       STA�E         ******************/

#define PROTEXT      ".SAF"   // rozszerzenie nazwy
#define TRUE         1
#define FALSE        0
#define BELL         7       // kod znaku ASCII: bell
#define SECTORSIZE   512     // Rozmiar sektora dyskowego
#define DATASIZE     SECTORSIZE - 2 // Ilo�� danych w bloku
#define PROTRECCOUNT   10      // liczba blok�w
                              // zabezpieczaj�cych

/******************         TYPY        ******************/

typedef int handle;
typedef unsigned int uint;
typedef unsigned long ulong;
typedef int bool;
typedef unsigned char byte;
typedef struct DATARECORD
               {    byte data[ DATASIZE ];
                    uint crc;
               };
/*****************        ZMIENNE        *****************/

DATARECORD  dataBuf, protRec[ PROTRECCOUNT ];
bool recDamaged[ PROTRECCOUNT ];
char inFileName[MAXPATH]="\0", outFileName[MAXPATH]="\0";
char inExt[MAXEXT] = "\0";
static char * READERR = "Blad przy odczycie pliku !";
static char * WRITEERR = "Blad przy zapisie do pliku !";
static char * WRONGINLEN =
              "Nieprawidlowa dlugosc pliku wejsciowego !";

/**********************************************************
          liczenie crc przy wykorzystaniu wielomianu
          generujacego x^16+x^15+x^2+1
**********************************************************/

uint CRC( uint crc, int c )
{ for( int i = 0; i < 8; i++ )
  { if( ( crc ^ c ) & 1 )
        crc = ( crc >> 1 ) ^ 0xA001;
		else
        crc >>= 1;
		c >>= 1;
	}
	return crc;
}

void calcCRC( DATARECORD & rec )
{
  rec.crc = 0;
  for( int i = 0; i < DATASIZE; i++ )
       rec.crc = CRC( rec.crc, rec.data[i]);
  rec.crc ^= 0xffff;
}

/**********************************************************
   makeXOR - dokonuje operacji XOR na dw�ch blokach
             pamieci. Wynik w drugim
**********************************************************/

void makeXOR( DATARECORD & src, DATARECORD & dst )
{
  for( int i = 0; i < DATASIZE; i++ )
       dst.data[i] ^= src.data[i];
}

/******** Przerwanie programu z komunikatem ********/

void exitMsg( char * txt )
{ puts( txt );
  exit(1);
}

/**********************************************************
        wy�wietlenie informacji o programie
**********************************************************/

void copyright()
{
  puts( "\nZabezpieczanie plikow. (c) Sebastian Maleszewski"
        ", Wroclaw'94\n" );
}

void programInfo()
{
  putchar( BELL );
  copyright();
  puts( "Format wywolania programu:" );
  puts( "\n\tPROTECT plikwe" );
  puts( "gdzie:\n\tplikwe - nazwa pliku wejsciowego" );
  puts( "\nJezeli plik ma rozszerzenie rozne od SAF, to zos"
        "tanie zabezpieczony\ni otrzyma rozszerzenie SAF." );
  puts( "Jezeli rozszerzeniem nazwy pliku jest SAF, "
        "to plik zostanie odbezpieczony\ni otrzyma "
        " oryginalne rozszerzenie");
  exit(1);
}

/******** Ustalenie trybu pracy programu na podstawie *****
********* rozszerzenia nazwy pliku wej�ciowego ************
********* outFileName dostaje nazw� bez rozszerzenia *****/

int getMode( char * fName )
{
  char drive[MAXDRIVE], dir[MAXDIR],
       file[MAXFILE], ext[MAXEXT];
  int flags = fnsplit( fName, drive, dir, file, ext );
  if( flags & FILENAME )
      strcpy(outFileName,file);
  else
      exitMsg( "Nie podana nazwa pliku wejsciowego !" );
  if( flags & EXTENSION )
  {   strcpy( inExt, ext );
      if( strcmp( ext, PROTEXT ) == 0 )
          return FALSE;  // odbezpieczanie pliku
  }
  strcat( outFileName, PROTEXT );
  return TRUE;
}

/******  Zerowanie roboczych bufor�w globalnych  ***/

void clrBuf( DATARECORD & r = dataBuf )
{ for( int i = 0; i < DATASIZE; i++ )
       r.data[i] = 0;
  r.crc = 0;
}

void initData()
{ clrBuf();
  for( int i = 0; i < PROTRECCOUNT; i++ )
  {
     clrBuf( protRec[i] );
     recDamaged[i] = FALSE;
  }
}

/************** otwarcie plik�w do zapisu i odczytu *****/

handle openInput()
{ handle f = open( inFileName, O_RDONLY | O_BINARY );
  if( f == -1 )
    exit(printf( "\nNie moge otworzyc pliku %s do odczytu "
                 "!\n\n", inFileName ));
  return f;
}

handle openOutput()
{
  ffblk ffblk;
  int exist = findfirst(outFileName,&ffblk,0) == 0;
  char c;
  if( exist )
     printf("Plik %s istnieje ! Nadpisywac go [T]ak/[N]ie ?\n"
            , outFileName);
  else
     printf("Plikiem wynikowy bedzie %s. Kontynuowac "
            "[T]ak/[N]ie ?\n", outFileName );
  do {
      c = toupper(getch());
  } while( c != 'T' && c != 'N' );
  if( c == 'N' )
      exitMsg( "\nPrzerywam...\n" );

  handle f = open( outFileName, O_CREAT | O_BINARY |
                   O_TRUNC | O_WRONLY, S_IWRITE | S_IREAD );
  if( f == -1 )
     exit(printf( "\nNie moge otworzyc pliku %s do zapisu"
                  " !\n\n", outFileName ));
  return f;
}

/************** Zabezpieczanie pliku  ****************/
void protectFile()
{
  copyright();
  printf("Zabezpieczam plik %s do pliku %s.\n",
         inFileName,outFileName);
  handle fin = openInput();
  handle fout = openOutput();
  long fileLen = filelength(fin);
  long totalBytes = fileLen;
  int protRecIndex = 0;
  int bytesToRead;
  int index = strlen(inExt) + 1;
  strcpy( dataBuf.data, inExt );
  *((long*)(dataBuf.data + index)) = fileLen;
  index += sizeof(long);
  bytesToRead = (fileLen > DATASIZE - index) ?
                 (DATASIZE - index) : fileLen;
  if( read(fin,dataBuf.data + index, bytesToRead)
      != bytesToRead )
      exitMsg( READERR );
  fileLen -= bytesToRead;

  for(;;)
  {
    calcCRC( dataBuf );
    makeXOR( dataBuf, protRec[protRecIndex] );
    protRecIndex++;
    protRecIndex %= PROTRECCOUNT;
    if( write(fout,&dataBuf,sizeof(dataBuf)) !=
        sizeof(dataBuf))
        exitMsg( WRITEERR );
    printf("\rZrobione %i%%",
            (100*(totalBytes-fileLen))/totalBytes );
    bytesToRead = (fileLen>DATASIZE) ? DATASIZE : fileLen;
    fileLen -= bytesToRead;
    if( bytesToRead == 0 )
        break;
    clrBuf();
    if( read(fin,dataBuf.data,bytesToRead) !=
        bytesToRead )
        exitMsg( READERR );
  }
  printf("\nDopisuje rekordy zabezpieczajace: ");
  for( int i = 0; i < PROTRECCOUNT; i++ )
  {
    calcCRC( protRec[ i ] );
    if( write(fout,&protRec[i],sizeof(DATARECORD))
        != sizeof(DATARECORD))
        exitMsg( WRITEERR );
    putchar('*');
  }
  exitMsg( "\nWszystko w porzadku. Plik zabezpieczony." );
}

/************** Odbezpieczenie pliku *****************/

int recordsDamaged = 0; // liczba zniszczonych sektor�w
long damagedRecNr[PROTRECCOUNT]; // numery zniszczonych

int canBeRepaired( long nr )
{
  return ! recDamaged[ nr % PROTRECCOUNT ];
}

int readRecord( handle fin, DATARECORD & rec )
{
  if( read( fin, &rec, sizeof(DATARECORD)) !=
      sizeof(DATARECORD))
      exitMsg( READERR );
  uint readcrc = rec.crc;
  calcCRC( rec );
  return ( rec.crc == readcrc );
}

void unprotectFile()
{
  copyright();
  printf("Sprawdzam poprawnosc pliku %s\n", inFileName);
  handle fin = openInput();
  long inFileLen = filelength(fin);
  if( inFileLen % SECTORSIZE )
    exitMsg( WRONGINLEN );
  long sectorCount = inFileLen / SECTORSIZE;
  if( sectorCount < PROTRECCOUNT )
    exitMsg( WRONGINLEN );
  long firstProtRecPos = sectorCount - PROTRECCOUNT;
  for( long sectorNr=0; sectorNr < sectorCount; sectorNr++)
  { printf("\rSprawdzam sektor nr %li z %li",
           sectorNr + 1, sectorCount );
    if( ! readRecord(fin,dataBuf) )
    {   printf( "\rUszkodzony sektor nr %i              \n"
                ,sectorNr+1 );
        if( canBeRepaired(sectorNr) )
        { if( recordsDamaged >= PROTRECCOUNT )
              exitMsg( "Za duzo uszkodzonych sektorow." );
          recDamaged[ sectorNr % PROTRECCOUNT ] = TRUE;
          damagedRecNr[ recordsDamaged++ ] = sectorNr;
        }
        else
          exitMsg( "Rekord nie moze zostac odtworzony." );
    }
    else
    {   if( sectorNr < firstProtRecPos )
           makeXOR( dataBuf, protRec[sectorNr%PROTRECCOUNT] );
        else
           makeXOR( dataBuf,
                    protRec[sectorNr-firstProtRecPos] );
    }
  }
  if( recordsDamaged == 0 )
      puts( "\rPlik nie jest uszkodzony.               " );
  else
      puts( "\rWszystkie uszkodzone sektory zostana"
              " odtworzone.   " );

  lseek(fin,0,SEEK_SET);                  // naprawa pliku
  long outFileLen;  // dlugo�� pliku oryginalnego
  sectorNr = 1;
  long totalLen;
  long damagedIndex = 0;
  int index,bytesToWrite;
  if( read(fin,&dataBuf,sizeof(dataBuf))
      != sizeof(dataBuf))
      exitMsg( READERR );

  if( recordsDamaged && damagedRecNr[0] == 0 )
  {   damagedIndex++;
      dataBuf = protRec[0];
  }
  strcat(outFileName,dataBuf.data);
  index = strlen(dataBuf.data) + 1;
  totalLen = outFileLen = *((long *)(dataBuf.data + index));
  index += sizeof(long);
  printf("\nOdtwarzam plik %s z pliku %s\n",
         outFileName,inFileName );
  handle fout = openOutput();
  bytesToWrite = (totalLen < DATASIZE - index ) ?
                  totalLen : DATASIZE - index;
  if( write(fout,dataBuf.data + index, bytesToWrite)
      != bytesToWrite )
      exitMsg( WRITEERR );
  outFileLen -= bytesToWrite;

  for(;;sectorNr++)
  {
    printf("\rZrobione %i%%", (100*(totalLen-outFileLen))/
           totalLen);
    if( read(fin,&dataBuf,sizeof(dataBuf))
        != sizeof(dataBuf))
        exitMsg( READERR );
    if( damagedIndex < recordsDamaged )
        if( damagedRecNr[damagedIndex] == sectorNr)
        {
          damagedIndex++;
          dataBuf = protRec[ sectorNr % PROTRECCOUNT ];
        }
    bytesToWrite = (outFileLen < DATASIZE ) ?
                    outFileLen : DATASIZE;
    outFileLen -= bytesToWrite;
    if( bytesToWrite == 0 )
        break;
    if( write(fout,dataBuf.data,bytesToWrite)
        != bytesToWrite )
        exitMsg( WRITEERR );
  }

  exitMsg( "\nPlik odtworzony" );
}

/************** Procedura g��wna *************/

void main( int argc, char *argv[] )
{
  if( argc != 2 )
      programInfo();
  initData();
  strupr(strcpy( inFileName, argv[1] ));
  if( getMode( inFileName ) )
      protectFile();
  else
      unprotectFile();
}

