/*-----------------97.05.25 23:27-------------------
  TEST_S.C
  Autor: Tomasz Cejner, 1997

  demonstracja ��czenia C z asemblerem
  na przyk�adzie kompilatora Watcom C

--------------------------------------------------*/
#include <conio.h>
#include <time.h>

/*
   prosz� zwr�ci� uwag� na s�owo kluczowe cdecl:
   m�wi ono kompilatorowi, �eby argumenty przekaza�
   przez stos (niezale�nie od opcji kompilatora)
   i dodaje podkre�lenie przed nazw�.
*/
extern void cdecl Init_s ();
extern void cdecl DeInit_s ();
extern void cdecl PutPixel_s (int,int,int);
extern void cdecl Box_s (int,int,int,int,int);

/*
  te same funkcje co powy�ej, wywo�ywane "przez rejestry"
*/
extern void Init_r ();
extern void DeInit_r ();
extern void PutPixel_r (int,int,int);
extern void Box_r (int,int,int,int,int);

void main ()
{
  int j;
  clock_t start,time1,time2;


  Init_s ();

  /* test pierwszy */
  for ( j=50; j<250; j++ )
  {
    PutPixel_s (j,50,j%15);
  }
  Box_s (60,60,300,150,2);

  /* test drugi */
  for ( j=50; j<250; j++ )
  {
    PutPixel_r (j,55,j%15);
  }
  Box_r (80,80,270,120,3);

  /* por�wnanie szybko�ci */
  start = clock();
  for ( j=0; j<10000000L; j++ )
  {
    PutPixel_r (10,10,15);
  }
  time1 = clock() - start;

  start = clock();
  for ( j=0; j<10000000L; j++ )
  {
    PutPixel_r (10,10,11);
  }
  time2 = clock() - start;

  PutPixel_r (10,10,0);


  getch ();
  DeInit_s ();

  printf ("Wynik testu:\n");
  printf ("Rejestry - %d\nStos - %d\n", time1,time2 );

}

