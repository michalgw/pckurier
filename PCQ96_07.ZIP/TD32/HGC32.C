
/*+------------------------------------------------------+*/
/*|                                                      |*/
/*|  Kod �r�d�owy biblioteki TDVIDEO.DLL (dla TD32.EXE)  |*/
/*|  umo�liwiaj�cej uruchamianie 32-bitowych program�w   |*/
/*|  DOS-owych (DPMI32) na komputerach wyposa�onych w    |*/
/*|  monitor monochromatyczny i kart� Hercules.          |*/
/*|                                                      |*/
/*|  Wersja 1.2 (c) 29.01.1995 Wojciech Marek Zabo�otny  |*/
/*|  E-mail  WZAB@ipe.pw.edu.pl                          |*/
/*|                                                      |*/
/*|  Niniejszy kod �r�d�owy jest oparty przede wszystkim |*/
/*|  na informacjach dotycz�cych struktury biblioteki    |*/
/*|  TDVIDEO.DLL zawartych w zbiorze pomocy (HELP)       |*/
/*|  programu TDWINI.EXE.                                |*/
/*|                                                      |*/
/*+------------------------------------------------------+*/

#include <windows.h>
#include <dos.h>
#include <stdio.h>
#include <conio.h>

/* Definicje rejestr�w karty Hercules */
#define HGC_Index         0x3b4
#define HGC_Data          0x3b5
#define HGC_Mode          0x3b8
#define HGC_LightPenSet   0x3b9
#define HGC_LightPenReset 0x3bb
#define HGC_Status        0x3ba
#define HGC_Config        0x3bf
#define HGC_LightPenExt   0x3bf

WORD selB000 = 0; /* Selektor pami�ci obrazu Herculesa */
WORD sel0040 = 0; /* Selektor segmentu danych BIOS-u */

/*========================================================*/
/* Funkcje i zmienne s�u��ce do przechowywania i odtwa-   */
/* rzania stanu BIOS-u (rozmiaru i po�o�enia kursora)     */
/*========================================================*/
unsigned char KursRzad,KursKolumna,KursStart,KursKoniec;

void PrzechowajKursorBIOSa(void)
{
  asm {
   mov ah,0x03
   mov bh,0
   int 0x10
   mov KursRzad,dh
   mov KursKolumna,dl
   mov KursStart,ch
   mov KursKoniec,cl
   }
}

void OdtworzKursorBIOSa(void)
{
  asm {
    mov ah,01
    mov ch,KursStart
    mov cl,KursKoniec
    int 0x10
    mov ah,02
    mov bh,0
    mov dh,KursRzad
    mov dl,KursKolumna
    int 0x10
    }
}

/* Niniejsza funkcja ustawia flag� BIOS-u przechowuj�c�   */
/* ostatni� warto�� wpisan� do rejestru "Display mode"    */
/* karty HGC.                                             */
/* Uwaga !!!                                              */
/* BGI32 nie ustawia poprawnie tej flagi. W przypadku     */
/* program�w 16-bitowych, u�ywaj�cych BGI mo�na na        */
/* podstawie tej flagi ustala�, czy Hercules jest w trybie */
/* graficznym, czy tekstowym. W tym wypadku musimy u�y�   */
/* bardziej wyrafinowanych metod. (Patrz funkcja          */
/* OdczytajStanHerculesa)                                 */

void UstawFlageBIOSa (unsigned char vmode)
{
asm {
  push es
  mov ax,sel0040
  mov es,ax
  mov al,vmode
  mov [byte ptr ES:0x65],al
  pop es
  }
return;
}

/*========================================================*/
/* Funkcje i zmienne s�u��ce do przechowywania i odtwa-   */
/* rzania tej cz��ci pami�ci ekranu u�ytkownika, kt�r�    */
/* mo�e zamaza� debugger                                  */
/*========================================================*/

/* Bufor przechowuj�cy zamazywan� cz��� pami�ci ekranu    */
/* u�ytkownika                                            */
unsigned char KopiaPamieciEkranu[0x1000]; /* 4kB */

void OdtworzPamiecEkranu(void)
{
/* Niniejsza funkcja odtwarza zawarto�� ekranu u�ytkowni- */
/* ka zachowan� przez funkcj� ZachowajPamiecEkranu        */
 asm {
        push es
        push ds
        push esi
        push edi
        mov ax,selB000
        mov es,ax
        xor edi,edi
        lea esi,KopiaPamieciEkranu
        cld
        mov ecx,1024   /* 4kB/4 */
        rep movsd
        pop edi
        pop esi
        pop ds
        pop es
        }
}

void ZachowajPamiecEkranu(void)
/* Niniejsza funkcja zachowuje fragment zawarto�ci ekranu */
/* u�ytkownika, kt�ry mo�e zosta� zamazany przez Turbo    */
/* Debugger                                               */
{
 asm {
        push es
        push ds
        push esi
        push edi
        mov ax,ds
        mov es,ax
        lea edi,[KopiaPamieciEkranu]
        mov ax,selB000
        mov ds,ax
        xor esi,esi
        cld
        mov ecx,1024  /* 4kB/4 */
        rep movsd
        pop edi
        pop esi
        pop ds
        pop es
        }
}

/*========================================================*/
/* Funkcje i zmienne s�u��ce do odczytania, zachowania    */
/* i odtworzenia stanu karty graficznej Hercules          */
/*========================================================*/

/* Numer widocznej strony graficznej                      */
unsigned char HGCStrona;
/* HGCTryb==0 gdy tryb tekstowy, 1 gdy graficzny          */
unsigned char HGCTryb;   

void OdczytajStanHerculesa(void)
{
/* Kopia rejestru rozszerzenia adresu pi�ra �wietlnego    */
 unsigned char LpExt; 
/* Numer znaku wy�wietlanego w momencie pocz�tku impulsu  */
/* synchronizacji pionowej                                */
unsigned short int NumerZnaku; 
 asm {
   mov dx,HGC_Status
   }
/* Przed detekcj� trybu pracy karty Hercules nale�y od-   */
/* czeka� jedn� pe�n� ramk� (czas wy�wietlania pe�nego    */
/* obrazu), w przeciwnym razie mo�e doj�� do b��dnego     */
/* rozpoznania trybu pracy karty. (Na przyk�ad w�wczas,   */
/* gdy w Turbo Debuggerze zostanie ustawiona pu�apka bli- */
/* sko po wywo�aniu funkcji "restorecrtmode" lub          */
/* closegraph".)                                          */ 
 a_czekaj_na_koniec_synchronizacji:
 asm {
   in al,dx
   and al,0x80
   je a_czekaj_na_koniec_synchronizacji
   /* Je�li impuls synchronizacji trwa, czekaj na jego    */
   /* koniec                                              */
   }
 a_czekaj_na_impuls_synchronizacji:
 asm {
   in al,dx
   and al,0x80
   jne a_czekaj_na_impuls_synchronizacji
   /* Czekaj na impuls synchronizacji pionowej            */
   }
 /* Koniec pierwszej ramki, mo�na bada� tryb pracy karty. */
 b_czekaj_na_koniec_synchronizacji:
 asm {
   in al,dx
   and al,0x80
   je b_czekaj_na_koniec_synchronizacji
   /* Je�li impuls synchronizacji trwa, czekaj na jego    */
   /* koniec                                              */
   }
 b_czekaj_na_impuls_synchronizacji:
 asm  {
   in al,dx
   and al,0x80
   jne b_czekaj_na_impuls_synchronizacji:
   /* Czekaj na pocz�tek impulsu synchronizacji pionowej  */
   mov dx,HGC_LightPenReset
   out dx,al
   /* Symuluj impuls pi�ra �wietlnego */
   mov dx,HGC_LightPenSet 
   out dx,al
   mov dx,HGC_LightPenExt 
   /* Odczytaj stan rejestru rozszerzenia adresu pi�ra    */ 
   /* �wietlnego */
   in al,dx
   mov LpExt,al
   mov dx,HGC_Index
   mov al,16
   out dx,al
   mov dx,HGC_Data
   in al,dx
   mov ah,al
   mov dx,HGC_Index
   mov al,17
   out dx,al
   mov dx,HGC_Data
   in al,dx
   mov NumerZnaku,ax  
   /* Zapami�taj numer znaku wy�wietlanego w momencie     */
   /* pocz�tku impulsu synchronizacji pionowej            */
   }
 /* Je�li numer znaku wy�wietlanego w momencie pocz�tku   */
 /* impulsu synchronizacji pionowej jest wi�kszy od 0xc00 */
 /* to karta pracuje w trybie graficznym, a je�li nie, to */
 /* w tekstowym.                                          */
  HGCTryb = (NumerZnaku >= 0xc00) ? 1 : 0;
 /* Numer aktywnej strony graficznej jest zapisany w 7    */
 /* bicie rejestru rozszerzenia adresu pi�ra �wietlnego   */
  HGCStrona = (LpExt & 0x80) ? 1 : 0;
}

void UstawTrybHerculesa(unsigned char TrybGraficzny,
                        unsigned char Strona)
/* Je�li TrybGraficzny != 0, niniejsza funkcja prze��cza   */
/* kart� Hercules w tryb graficzny i ustawia aktywn�      */ 
/* stron� graficzn� zale�nie od parametru Strona. Je�li   */
/* TrybGraficzny==0, funkcja prze��cza kart� Hercules     */
/* w tryb tekstowy.                                       */
{
        int i,tryb;
        unsigned char vmode;                                          
        static unsigned char CRTC[2][12] ={
          {0x61,0x50,0x52,0x0f,0x19,0x06,
           0x19,0x19,0x02,0x0d,0x0b,0x0c},
          {0x35,0x2d,0x2e,0x07,0x5b,0x02,
          0x57,0x57,0x02,0x03,0x00,0x00 }
          };
        if(TrybGraficzny) {
          tryb=1;
          outportb( HGC_Config, 3 );
          if(Strona==1) vmode=0x8a;
          else        vmode=0x0a;
          }
        else {
          tryb=0;
          outportb( HGC_Config, 0 );
          vmode=0x29;
          }
        outportb( HGC_Mode,   vmode );
        for ( i=0; i < 12; i++ ) {
          outportb( HGC_Index, i );
          outportb( HGC_Data, CRTC[tryb][i] );
          };
        UstawFlageBIOSa(vmode);
};

/*========================================================*/
/* Funkcje niezb�dne w bibliotece DLL                     */
/*========================================================*/

/*--------------------------------------------------------*/
#pragma argsused
int FAR PASCAL LibMain( HANDLE h, WORD wDataSegment,
                        WORD wHeapSize, LPSTR lpszCmdLine )
{
   return 1;   /* Zawsze sukces */
}
/*--------------------------------------------------------*/
#pragma argsused
int FAR PASCAL WEP ( int bSystemExit )
{

   return 1;  /* Zawsze sukces  */
}

/*========================================================*/
/* Funkcje niezb�dne w bibliotece TDVIDEO.DLL             */
/*========================================================*/

/*--------------------------------------------------------*/
WORD FAR PASCAL _export VideoInit (void)
/* Funkcja przygotowuj�ca bibliotek� do pracy             */
{
/* Zaalokuj selektory pozwalaj�ce odwo�ywa� si� do danych */
/* BIOS'a i pami�ci ekranu                                */
 asm {
         mov ax,2
         mov bx,0x0040
         int 0x31
         jc Error
         mov sel0040,ax
         mov ax,2
         mov bx,0xB000
         int 0x31
         jc Error
         mov selB000,ax
         }
  printf("TDVIDEO.DLL for HGC v1.2pl (c) 29.01.1995 " 
         "W.M. Zabo�otny\n");
  return 0; /* Sukces */
  Error:
/* B��d, nie mo�na by�o zaalokowa� niezb�dnych selektor�w */
  return 5;
}

/*--------------------------------------------------------*/
WORD FAR PASCAL _export VideoDone (void)
/* Funkcja ko�cz�ca prac� biblioteki                      */
{
  UstawTrybHerculesa(0,0);
  clrscr();
  return 1; /* Zawsze sukces */
}

/*--------------------------------------------------------*/
WORD FAR PASCAL _export VideoIsColor (void)
/* Funkcja informuj�ca o rodzaju monitora                 */
{
  return 0; /* Zawsze monitor monochromatyczny */
}

/*--------------------------------------------------------*/
#pragma argsused
WORD FAR PASCAL _export VideoGetTextSelector (int display)
/* Funkcja zwracaj�ca selektor pami�ci ekranu             */
{
  return selB000; /* Zawsze monitor monochromatyczny */
}

/*--------------------------------------------------------*/
void FAR PASCAL _export VideoSetCursor (WORD y, WORD x)
/* Funkcja ustawiaj�ca kursor w okre�lonym miejscu ekranu */
{
  asm {
    mov ah,2
    mov bh,0
    mov dh,byte ptr y
    mov dl,byte ptr x
    int 0x10
    }
}

/*--------------------------------------------------------*/
void FAR PASCAL _export VideoDebuggerScreen (void)
/* Funkcja zachowuj�ca ekran u�ytkownika i prze��czaj�ca  */
/* kart� Hercules w tryb tekstowy                         */
{
 OdczytajStanHerculesa(); 
 ZachowajPamiecEkranu();
 PrzechowajKursorBIOSa();
 UstawFlageBIOSa(0x29);
 UstawTrybHerculesa(0,0);
}

/*--------------------------------------------------------*/
void FAR PASCAL _export VideoWindowsScreen (void)
/* Funkcja odtwarzaj�ca ekran u�ytkownika                 */
{
 UstawTrybHerculesa(HGCTryb,HGCStrona);
 OdtworzPamiecEkranu();
 OdtworzKursorBIOSa();
}

/*--------------------------------------------------------*/
WORD FAR PASCAL _export VideoBigSize (void)
{
  /* Ekran zawiera zawsze 25 linii w trybie tekstowym     */
  return 25;
}

/*--------------------------------------------------------*/
#pragma argsused
WORD FAR PASCAL _export VideoSetUp (WORD xtra1, WORD xtra2)
{
 /* Funkcja nieu�ywana */
 return 0;
}

/*--------------------------------------------------------*/
#pragma argsused
void FAR PASCAL _export VideoSetSize (WORD bigflag)
{
/* Funkcja nieu�ywana, nie mo�na zmieni� wielko�ci ekranu */
}

/*--------------------------------------------------------*/
#pragma argsused
void FAR PASCAL _export VideoUpdateWindow (void)
{
/* Funkcja nieu�ywana */
}

/*--------------------------------------------------------*/
#pragma argsused
void FAR PASCAL _export VideoConfig (HWND hWnd, 
                    HINSTANCE hInst, char *HelpFile)
{
/* Funkcja nieu�ywana */
}

