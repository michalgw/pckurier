//-------------------------------------------------------
#pragma inline // assembler w kodzie
//-------------------------------------------------------

//-------------------------------------------------------
//oczekiwanie na pocz�tek powrotu pionowego
void czekaj(void)
{
// do dx - adres rejestru Input Status #1
asm mov dx,3dah;
//koniec powrotu pionowego ?
tu1:
// wywo�anie w jego trakcie
asm in al,dx;    // odczyt rejestru Input Status #1
asm and al,1;    // testowanie bitu
asm jnz tu1;     // czekaj
// pocz�tek kolejnego pionowego powrotu
tu2:
asm in al,dx;    // odczyt rejestru Input Status #1
asm and al,1;    // testowanie bitu
asm jz  tu2;     // czekaj
}
//-------------------------------------------------------

//-------------------------------------------------------
// testowanie bitu 3 rej. Input Status #1
void powrot(void)  
{
asm        mov dx,3dah
qw1:
asm        in al,dx
asm        test al,8
asm        jz qw1
}
//-------------------------------------------------------

//-------------------------------------------------------
void Set1Color(int Nr,int r,int g, int b)
{
asm  mov  dx, 3C8h //numer portu koloru
asm  mov  al, Nr   //jaki kolor zmienia�
asm  out  dx, al   //wy�lij do portu
asm  inc  dx       //zwi�ksz dx

asm push dx       // zachowaj warto�ci zmienianych
asm push ax	  // rejestr�w

asm mov dx,3dah    // tutaj ta sama funkcja co czekaj
czek1:             // wywo�ana bezpo�rednio, ze wzgledu
asm     in al,dx   // na to, �e wywo�anie funkcji:
asm     test al,1  // czekaj(); powoduje �nie�enie obrazu
asm     jnz czek1
czek2:
asm     in al,dx
asm     test al,1
asm     jz czek2

asm pop ax         // odtw�rz poprzednie warto�ci
asm pop dx         // rejestr�w

asm  mov  al, r    // �aduj sk�adow� red do al
asm  out  dx, al
asm  mov  al, g    // �aduj sk�adow� green do al
asm  out  dx, al
asm  mov  al, b    // �aduj sk�adow� blue do al
asm  out  dx, al
}
//-------------------------------------------------------

//-------------------------------------------------------
main()
{
int i,odbij,j,licz;
licz=0;odbij=1;

// wykonuj do momentu naci�ni�cia klawisza
while (!kbhit()) {
// pocz�tek ekranu
if (licz==0)  odbij=0;
// koniec ekranu
if (licz==255) odbij=1;
// zmiana kierunku ruchu
if (odbij==1)  licz--; else licz++;

powrot();

for (j=1;j<=licz;j++) czekaj();

// inny r�wnie ciekawy efekt przy za�o�eniu,�e
// litery s� wy�wietlane w kolorze 7 standardowy
// kolor komunikat�w w DOS 
// WPISZ : Set1Color(0,i,0,0); zamiast Set1Color(7,i,i,i);

for (i=0;i<=63;i++)
     Set1Color(7,i,i,i);
for (i=63;i>=0;i--)
     Set1Color(7,i,i,i);
}

// wpisz warto�ci pocz�tkowe sk�adowych dla koloru,
// kt�rego u�ywa�e� do rotacji
Set1Color(7,40,40,40);return 0;
}
//-------------------------------------------------------

