// setgr( int tr)
// tr - parametr typu int okre�laj�cy tryb, w jaki ma by�
//prze��czona karta grafiki

#include <dos.h>
#include "extend.api"

CLIPPER setgr()
{
        union REGS reg;

        reg.h.ah=0x00;
        reg.h.al=_parni(1);

        int86(0x010,&reg,&reg);

        _ret();
}

