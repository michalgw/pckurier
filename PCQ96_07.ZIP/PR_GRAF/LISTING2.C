// putpix(int x,int y,int c)
//Rysowanie piksela w punkcie (x,y) w kolorze c

#include <dos.h>
#include "extend.api"

CLIPPER putpix()
{
        union REGS reg;

        reg.h.ah=0x0C;
        reg.h.al=_parni(3);
        reg.h.bh=0;
        reg.x.cx=_parni(1);
        reg.x.dx=_parni(2);

        int86(0x010,&reg,&reg);

        _ret();
}
