//putznak(int znak, int c)
//Wypisanie znaku "znak" w pozycji kursora w kolorze

#include <dos.h>
#include "extend.api"

CLIPPER putznak()
{
        union REGS reg;

        reg.h.ah=0x0E;
        reg.h.al=_parni(1);
        reg.h.bh=0;
        reg.h.bl=_parni(2);

        int86(0x010,&reg,&reg);

        _ret();
}

