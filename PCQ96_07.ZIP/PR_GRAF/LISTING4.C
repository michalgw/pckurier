// movekurs(int x, int y)
//Przesuni�cie kursora do pozycji (x,y)

#include <dos.h>
#include "extend.api"

CLIPPER movekurs()
{
        union REGS reg;

        reg.h.ah=0x02;
        reg.h.bh=0;
        reg.h.dh=_parni(1);
        reg.h.dl=_parni(2);

        int86(0x010,&reg,&reg);

        _ret();
}

