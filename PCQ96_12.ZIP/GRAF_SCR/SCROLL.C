#pragma inline
#include <stdio.h>
#include <conio.h>

int ile,n;
char ch;

//--------------------------------------------------------
// Wczytanie pliku i bezpo�redni zapis do pami�ci ekranu
//--------------------------------------------------------
void czytaj()
{
int i;
FILE *plik;
char buf[80];
plik=fopen("PCK1.C","rt");
ile=0;
while(!feof(plik))
{
for (i=0;i<80;i++) buf[i]=' ';
fgets(buf,80,plik);
ile++;
for (i=0;i<80;i++)
if ((buf[i]!=10)&&(ile<205))
pokeb(0xb800,(i*2)+(ile*80*2),buf[i]+1792);
}
fclose(plik);
}
//--------------------------------------------------------

//--------------------------------------------------------
//            Oczekiwanie na synchronizacj�
//--------------------------------------------------------
void cnr(void)
{
asm mov dx,3dah
wai:
asm in al,dx
asm test al,8
asm je wai
wai0:
asm in al,dx
asm test al,8
asm jne wai0
}
//--------------------------------------------------------

//--------------------------------------------------------
//       Realizacja p�ynnego przesuwania ekranu
//--------------------------------------------------------
void scrolly(int y)
{
int sb,LICZBA,mb;
LICZBA=y/peek(0,1157)*peek(0,1098);//y/wys_znaku*szer_kol
sb=LICZBA/256;mb=LICZBA-(sb*256);
outport(peek(0,0x0463),0x0c);outport(peek(0,0x0463)+1,sb);
outport(peek(0,0x0463),0x0d);outport(peek(0,0x0463)+1,mb);
cnr();
outport(peek(0,0x0463),8);
outport(peek(0,0x0463)+1,y%peek(0,0x0485));

}
//--------------------------------------------------------

//--------------------------------------------------------
main()
{
n=0;
clrscr();
asm mov ah,1
asm mov ch,20h
asm int 10h
czytaj();
while (ch!=27) {
ch = getch();
if (ch==0) ch =getch();
if (ch==80) while (bioskey(1) == 0)
if (n<(ile-24)*16) {scrolly(n);n++;}
if (ch==72) while (bioskey(1) == 0) 
if (n>0) {scrolly(n);n--;}
}
asm mov ax,3
asm int 10h
return 0;
}
//--------------------------------------------------------

