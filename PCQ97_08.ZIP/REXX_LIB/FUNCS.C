/*

 * FUNCS.C
 * Definicje funkcji "u�ytkowych".

 */


#define INCL_REXXSAA

#include <os2.h>
#include <rexxsaa.h>
#include <stdio.h>


RexxFunctionHandler ExmpFunc1;
RexxFunctionHandler ExmpFunc2;


/* ExmpFunc1 - podaje informacje o parametrach */


ULONG ExmpFunc1(PUCHAR funcName,
                ULONG argc,
                PRXSTRING argv,
                PSZ queName,
                PRXSTRING retStr)
{

  int i;

  printf("Arguments passed to %s from REXX:\n", funcName);

  for (i = 0; i < argc; i++) {

    printf("%s\n", argv[i].strptr); }

  return 0;

}

/* ExmpFunc2 - nadaje zmiennej (patrametr 0)
 * warto�� parametru 1 */


ULONG ExmpFunc2(PUCHAR funcName,
                ULONG argc,
                PRXSTRING argv,
                PSZ queName,
                PRXSTRING retStr)
{

  SHVBLOCK shvblock;


  if (argc != 2) return 40;

  shvblock.shvnext = (PSHVBLOCK)NULL;

  MAKERXSTRING(shvblock.shvname, argv[0].strptr,
               argv[0].strlength);

  MAKERXSTRING(shvblock.shvvalue, argv[1].strptr,
               argv[1].strlength);

  shvblock.shvvaluelen = argv[1].strlength;

  shvblock.shvret = (UCHAR)0;
  shvblock.shvcode = RXSHV_SYSET;

  if(RexxVariablePool(&shvblock)) return 40;

  return 0;

}


