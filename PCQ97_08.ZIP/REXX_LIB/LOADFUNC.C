/*

 * LOADFUNC.C
 * Rejestracja/derejestracja funkcji dla REXX-a.

 */


#define INCL_REXXSAA
#include <rexxsaa.h>
#include <os2.h>


#ifndef DLL_NAME
#define DLL_NAME "EXAMPLE"
#endif


/* definicje funkcji */

RexxFunctionHandler ExmpLoadFuncs;
RexxFunctionHandler ExmpDropFuncs;

typedef struct {

  PSZ func_name;     /* nazwa funkcji */
  PSZ entry_point;   /* punkt wej�cia */

} ENTRY;


static ENTRY funcTable[] =
 {
   { "ExmpFunc1", "ExmpFunc1" },
   { "ExmpFunc2", "ExmpFunc2" }
 };


/* ExmpLoadFuncs - rejestracja */

ULONG ExmpLoadFuncs(PUCHAR funcName,
                    ULONG argc,
                    PRXSTRING argv,
                    PSZ queName,
                    PRXSTRING retStr)
{

   int i, numEntries;

   if (argc > 0) return 40;

   retStr->strlength = 0;

   numEntries = sizeof(funcTable) / sizeof(ENTRY);

   for (i = 0; i < numEntries; i++) {

       RexxRegisterFunctionDll(funcTable[i].func_name,
                               DLL_NAME,
                               funcTable[i].entry_point);
   }

   return 0;

}


/* ExmpDropFuncs - derejestracja */

ULONG ExmpDropFuncs(PUCHAR funcName,
                    ULONG argc,
                    PRXSTRING argv,
                    PSZ queName,
                    PRXSTRING retStr)
{

   int i, numEntries;

   if (argc > 0) return 40;

   retStr->strlength = 0;

   numEntries = sizeof(funcTable) / sizeof(ENTRY);

   for (i = 0; i < numEntries; i++) {

       RexxDeregisterFunction(funcTable[i].func_name);
   }

   return 0;

}



