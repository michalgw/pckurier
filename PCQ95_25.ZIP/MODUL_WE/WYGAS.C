#include <dos.h>
#include <mem.h>
#include <string.h>

#ifdef __cplusplus
    #define __CPPARGS ...
#else
    #define __CPPARGS void
#endif
#define INTR9 0x09
#define INTR10 0x10
#define INTR1C 0x1C

extern int _parclen(int, ...);
extern int _parni(int, ...);
extern long _parnl(int, ...);
extern char *_parc(int, ...);
extern int _parinfo(int);
extern int _parl(int, ...);

typedef struct {
   unsigned int bp,di,si,ds,es,dx,cx,bx,ax,ip,cs,flags;
   } WordReg;

long ekcount;
long ekdelayn;
int ekzapalony;
int eklicznik;
unsigned int ekcurtop;
unsigned int ekcurdown;
unsigned int ekcurx;
unsigned int ekcury;
int ekpageno;
int nrtrybtext;
int ekseg_scr;
int eklicz_do;
int ekdlunap;
int ekpozx;
int ekpozy;
int ekstpozx;
int ekstpozy;
int przesnap;
int ekstile;
int odswiez;

char ekstringj[161];
char ekbuf[80*25*2];
void *ekscreen;

void interrupt far ( *oldhand1C)(__CPPARGS);
void interrupt far ( *oldhand09)(__CPPARGS);
void interrupt far ( *oldhand10)(__CPPARGS);

void setscreen(unsigned int segm,unsigned int pocz,
        unsigned int ile)
{
asm{ push ax;
     pushf;
     push cx;
     push di;
     push es;
     cld;
     mov ax,0x0720;
     mov cx,ile;
     mov di,pocz;
     mov es,segm;
     rep stosw;
     pop es;
     pop di;
     pop cx;
     popf;
     pop ax;
     }
}

void zgas(void)
{
struct REGPACK regs;
   regs.r_ax=0x0f < 8; /* czytanie numeru trybu  */
   intr(INTR10,&regs);
   nrtrybtext=regs.r_ax & 0x00FF;
   regs.r_ax=0x0f <8;     /*czytaj nr strony*/
   intr(INTR10,&regs);
   ekpageno=regs.r_bx;
   regs.r_ax=0x03 <8;       /*czytaj kursor*/
   intr(INTR10,&regs);
   ekcurtop=(regs.r_cx & 0xFF00) >>8;
   ekcurdown=regs.r_cx & 0x00FF;
   ekcurx=regs.r_dx & 0x00FF;
   ekcury=(regs.r_dx & 0xFF00)>>8;
   regs.r_ax=0x01 <8;         /*wyga� kursor*/
   regs.r_cx=0x2000;
   intr(INTR10,&regs);
   movmem(ekscreen,ekbuf,4000);
   setscreen(ekseg_scr,0,2000);
   ekzapalony=0;
   eklicznik=0;
   ekpozx=0;
   ekpozy=25;
   ekstpozx=79;
   ekstpozy=0;
   ekstile=0;
   przesnap=ekdlunap;
}

void zapalekr(void)
{
struct REGPACK regs;
  ekcount=0;
  if (ekzapalony==0)
       {
 ekzapalony=1;
 if (odswiez==1) movmem(ekbuf,ekscreen,4000);
 if (odswiez==2) setscreen(ekseg_scr,0,2000);
 regs.r_ax=(0x0f < 8) + nrtrybtext;
 intr(0x10,&regs);       /* ustaw numeru trybu  */
 regs.r_ax=0x02 < 8;    /*ustaw pozycje kursora*/
 regs.r_bx=ekpageno;
 regs.r_dx=(ekcury < 8)+ekcurx;
 intr(0x10,&regs);
 regs.r_ax=0x01 < 8;    /*ustaw rozm. kursora*/
 regs.r_cx=((ekcurtop <8) & 0xFF00);
 regs.r_cx=regs.r_cx+ ekcurdown;
 intr(INTR10,&regs);
       }
}

void przesuw(void)
{
int ile;
eklicznik=eklicznik+1;
if (eklicznik>=eklicz_do)
   {eklicznik=0;
    ekpozx=ekpozx-1;
    if (ekpozx<0)
       {ekpozx=0;
       if (przesnap<ekdlunap) przesnap=przesnap+2;
   else
    {
     ekpozx=79;
     przesnap=0;
     ekpozy++;
     if (ekpozy>24) ekpozy=0;
    };
       };
    setscreen(ekseg_scr,ekstpozy*160+ekstpozx*2,ekstile/2);
    ile=ekdlunap;
    if (ekdlunap>(80-ekpozx)*2) ile=(80-ekpozx)*2;
    if (przesnap>0) ile=ekdlunap-przesnap;
    movmem(MK_FP(FP_SEG(ekstringj),
    FP_OFF(ekstringj)+przesnap),
    MK_FP(ekseg_scr,ekpozy*160+ekpozx*2),ile);
    ekstpozy=ekpozy;
    ekstpozx=ekpozx;
    ekstile=ile;
    }
}

void interrupt hand1C(__CPPARGS)
{
  if (ekzapalony==1)
    {
     ekcount++;
     if (ekcount>=ekdelayn)
       {
       ekcount=0;
       zgas();
       }
    }
    else
     przesuw();
  oldhand1C();
}

void interrupt hand09(__CPPARGS)
{
int kon;
int pomodsw;
 kon=peek(0x40,0x1c);
 oldhand09();
 ekcount=0;
 if (ekzapalony==0)
      {
      pomodsw=odswiez;
      odswiez=1;
      zapalekr();
      odswiez=pomodsw;
      poke(0x40,0x1c,kon);
      }
}

void interrupt hand10(WordReg reg)
{
   oldhand10();
   reg.di=_DI;
   reg.si=_SI;
   reg.es=_ES;
   reg.dx=_DX;
   reg.cx=_CX;
   reg.bx=_BX;
   reg.ax=_AX;
   ekcount=0;
   if (ekzapalony==0)
      {
      zapalekr();
      }
}

void inicekr(void)
{
unsigned int licz_par;
struct REGPACK interrupt regs;
   ekcount=0;
   regs.r_ax=0x0f < 8;       /* czytanie numeru trybu  */
   intr(0x10,&regs);
   ekseg_scr=0xB800;
   if ((regs.r_ax & 0x00FF)==0x07) ekseg_scr=0xB000;
   eklicz_do=10;
   ekdelayn=10*18;
   ekdlunap=2;
   licz_par=_parinfo(0);
   if (licz_par > 0)  ekdelayn=_parl(1)*18;
   if (licz_par > 1)
      { ekdlunap=_parclen(2);
 strcpy(ekstringj, _parc(2));}
   if (licz_par > 2) eklicz_do=_parni(3);
   ekzapalony=1;
   ekscreen = MK_FP(ekseg_scr, 0);
   oldhand1C = getvect(INTR1C);
   oldhand09 = getvect(INTR9);
   oldhand10 = getvect(INTR10);
   setvect(INTR9, hand09);
   setvect(INTR10, hand10);
   setvect(INTR1C, hand1C);
   odswiez=2;
}

void zakekr(void)
{
     ekcount=0;
     zapalekr();
     setvect(INTR1C, oldhand1C);
     setvect(INTR9, oldhand09);
     setvect(INTR10, oldhand10);
}

void usttrybod(void)
{
     if (_parinfo(0)==1) odswiez=_parni(1);
}

void zapalek(void)
{
int pamodsw;
     ekcount=0;
     pamodsw=odswiez;
     if (_parinfo(0)==1) odswiez=_parni(1);
     if (ekzapalony==0) zapalekr();
     odswiez=pamodsw;
}

