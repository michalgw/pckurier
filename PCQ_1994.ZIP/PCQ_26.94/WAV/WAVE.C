
/* Program do odczytywania informacji o pliku *.wav */

/*  GRZEGORZ STANICZEK 1994  */
/* program podaje parametry pliku *.wav */
/* podanego jako argument przy uruchomieniu */

#include<stdio.h>
#include<string.h>
#include"wave.h"

struct WAVEHEAD WAVE1;

main(int argc,char * argv[])
{
 FILE *plikw;
 char plikwej[15];

 if (argc!=2)
  {
   printf("\n Nalezy podac argument programu \n ");
  }
 else
  {
   strncpy(plikwej,argv[1],13);
   plikw=fopen(plikwej,"rb");
   fread(&WAVE1,sizeof(struct WAVEHEAD),1,plikw);
   printf("\n Dlugosc pliku %ld bajtow; ",WAVE1.DLPLIKU+8);
   printf("\n Cz. probkowania %ld Hz;",WAVE1.CZESTOTLIWOSC);
   printf("\n Przetwarzanie na %d bitach",WAVE1.SLOWO);
   printf("\n Ilosc kanalow %d",WAVE1.KANAL);
   fclose(plikw);
  }
 return (0);
}
