
/* Program do zamiany pliku z liczbami na plik *.wav */

/* Grzegorz Staniczek 1994 */
/* program do zamiany plikow z liczbami w zapisanymi */
/* w formacie ASCII na plik *.wav */

#include<stdio.h>
#include"wave.h"
#include<string.h>

int zrobhead(ulong dlpliku,ulong czestotliwosc,uint slowo);
struct WAVEHEAD WAVE1;

main(int argc,char * argv[])
{
 FILE *plikwe,*plikwy;
 char plikwej[13],plikwyj[13];
 unsigned int slowo;
 int a,q;
 unsigned long dlpliku,czestotliwosc;

 if (argc!=2)
  printf("\nNalezy podac nazwe pliku do przerobienia \n ");
 else
 {     /* Uwaga ! Plik musi miec rozszerzenie (dowolne). */
  strncpy(plikwej,argv[1],13);
  strncpy(plikwyj,plikwej,13);
  strcpy((strchr(plikwyj,'.')),".wav");
  plikwe=fopen(plikwej,"rb");
  plikwy=fopen(plikwyj,"wb");
  zrobhead(0,0,0);
 /* zarezerwowanie miejsca na naglowek w pliku wynikowym */
  fwrite(&WAVE1,sizeof(struct WAVEHEAD),1,plikwy);
  fscanf(plikwe,"%d",&a);
  slowo=16;  /* jakie probki 8 czy 16 bitow */
  do
  {
   fwrite(&a,slowo/8,1,plikwy);
   q=fscanf(plikwe,"%d",&a);
  }
  while(q==1);
 fseek(plikwy,0,SEEK_END);
 dlpliku=ftell(plikwy);
 czestotliwosc=10000;  /* czestotliwosc probkowania w Hz */
 zrobhead(dlpliku,czestotliwosc,slowo);
 rewind(plikwy);
 /* zapisanie uaktualnionego naglowka */
 fwrite(&WAVE1,sizeof(struct WAVEHEAD),1,plikwy);
 fclose(plikwe);
 fclose(plikwy);
 }
return 0;
}


int zrobhead(ulong dlpliku,ulong czestotliwosc,uint slowo)
{

 strcpy(WAVE1.RIFF,"RIFF");
 WAVE1.DLPLIKU=(dlpliku-8); /* 8 bajtow na RIFF i dlugosc */
 strcpy(WAVE1.WAVE,"WAVE");
 strcpy(WAVE1.fmt,"fmt ");
 WAVE1.DLBLOKU=16; /* blok opisujacy format standardowy */
 WAVE1.FORMAT=1;  /* standard */
 WAVE1.KANAL=1;   /* mono */
 WAVE1.CZESTOTLIWOSC=czestotliwosc;
 WAVE1.BUFOR=slowo*czestotliwosc/8;
 WAVE1.BLOK=slowo/8; /* ile bajtow */
 WAVE1.SLOWO=slowo;  /* ile bitow */
 strcpy(WAVE1.data,"data");
 WAVE1.DLDANYCH=dlpliku-44;/*44 bajty zamuje caly naglowek*/
 return 0;
}

