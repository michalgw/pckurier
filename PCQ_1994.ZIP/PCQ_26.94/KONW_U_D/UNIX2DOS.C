
/*********************************************************
 *                                                       *
 *    Konwersja plik�w tekstowych z Unixa do DOS         *
 *                                                       *
 *    Wywo�anie :                                        *
 *                                                       *
 *     unix2dos <plik �r�d�owy> <plik przeznaczenia>     *
 *                                                       *
 *    Autor :  Tomasz Marek Dmowski                      *
 *                                                       *
 *    E-mail: dmowski@gumbeers.elka.pg.gda.pl            *
 *                                                       *
 *********************************************************/

#include <stdio.h>
void main(int argc, char *argv[])
{ if (argc>=3)
  { FILE *in = fopen(argv[1],"rb");
    FILE *out = fopen(argv[2],"wb");

    if (!in) printf("Plik %s nie istnieje\n",argv[1]);
    else {
      printf("Przeksztalcanie pliku %s\n",argv[1]);
      char b=getc(in);
      while (b!=EOF) { if (b=='\xa') putc('\xd',out);
                       putc(b,out); b=getc(in); }
         }
    fclose(in); fclose(out); }
  else {
    printf("\nZa malo parametrow\nWywolanie :\n");
    printf("unix2dos <plik zrodlowy> <plik przeznaczenia>");
       }
}
