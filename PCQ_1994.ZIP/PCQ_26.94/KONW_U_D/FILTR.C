
/*********************************************************
 *                                                       *
 *    Filtr wycinaj�cy z pliku znaki o podanym kodzie    *
 *                                                       *
 *    Wywo�anie :                                        *
 *                                                       *
 *    filtr <plik �r�d�owy> <plik przeznaczenia> <kod>   *
 *                                                       *
 *    Autor :  Tomasz Marek Dmowski                      *
 *                                                       *
 *    E-mail: dmowski@gumbeers.elka.pg.gda.pl            *
 *                                                       *
 *********************************************************/

#include <stdio.h>
#include <stdlib.h>
void main(int argc, char *argv[])
{ if (argc>=4)
  { FILE *in = fopen(argv[1],"rb");
    FILE *out = fopen(argv[2],"wb");

    if (!in) printf("Zla nazwa pliku %s\n",argv[1]);
    else {
      printf("Przeksztalcanie pliku %s\n",argv[1]);
      char b=getc(in);
      unsigned b1=atoi(argv[3]);
      while (b!=EOF) { if (b!=b1) putc(b,out); b=getc(in); }
         }
    fclose(in); fclose(out); }
  else {
     printf("Za malo parametrow\nWywolanie :\n");
     printf("    filtr <plik_we> <plik_wy> ");
     printf("<kod znaku (dziesietnie)>\n");
       }
}
