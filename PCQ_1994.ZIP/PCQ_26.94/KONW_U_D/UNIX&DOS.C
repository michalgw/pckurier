
/*********************************************************
 *                                                       *
 *  Konwersja plik�w tekstowych mi�dzy DOS a Unixem      *
 *                                                       *
 *    Wywo�anie :                                        *
 *                                                       *
 *     unix&dos <plik �r�d�owy> <plik przeznaczenia>     *
 *                                                       *
 *    Autor :  Tomasz Marek Dmowski                      *
 *                                                       *
 *    E-mail: dmowski@gumbeers.elka.pg.gda.pl            *
 *                                                       *
 *********************************************************/

#include <string.h>
#include <fstream.h>
void main(int argc, char *argv[])
{ if (argc>=3)
  { ifstream in(argv[1]);
    ofstream out(argv[2]);

    if (!in) 
      cout < "\nPlik " < argv[1] < "nie istnieje\n";
    else {
      cout < "\nPrzeksztalcanie pliku " < argv[1] < '\n';
      char *linia=new char[1001];
      while (!in.eof()) { in.getline(linia,1000);
                          out < linia < '\n'; } }
  } else {
    cout < "\nZa malo parametrow\nWywolanie :\n"
         < "unix&dos <plik zrodlowy> <plik przeznaczenia>";
         }
}
