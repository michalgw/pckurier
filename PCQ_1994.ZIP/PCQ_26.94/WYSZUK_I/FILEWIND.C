
/* FILEWIND.C */

#include <windows.h>
#include "filewind.h"

#define MAXMASKLEN 12
#define ComboMsg(m,w,l) \
  SendDlgItemMessage(hDlg, ID_COMBO, m, w, l)
#define FileBoxMsg(m,w,l) \
  SendDlgItemMessage(hDlg, ID_FILEBOX, m, w, l)

BOOL CALLBACK _export DlgProc(HWND, UINT, WPARAM, LPARAM);
void InitDialog(HWND);
void DirBoxNotify(HWND, WORD);
void DefBtnPressed(HWND);
void FillDirBox(HWND, char *);
void ChangeDir(HWND);
void FindFiles(HWND);
void Scan(HWND, char *, char *);
int FillScanBox(HWND, WORD, char *, char *);
BOOL GetMask(HWND, char *);

BOOL bDirFocused = FALSE;
char szAllFiles[] = "*.*";

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrevInst,
                          LPSTR lpCmdLine, int nCmdShow)
{
 DLGPROC lpDlgProc =
   (DLGPROC)MakeProcInstance((FARPROC)DlgProc, hInst);
 DialogBox(hInst, MAKEINTRESOURCE(ID_DLG), NULL, lpDlgProc);
 FreeProcInstance(lpDlgProc);
 return 0;
}

BOOL CALLBACK _export DlgProc(HWND hDlg, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
  switch (message)
    {
      case WM_INITDIALOG:
        InitDialog(hDlg);
        return TRUE;
      case WM_SYSCOMMAND:
        if (wParam == SC_CLOSE)
          {
            EndDialog(hDlg, 0);
            return TRUE;
          }
        else break;
      case WM_COMMAND:
        switch (wParam)
          {
            case IDOK:
              DefBtnPressed(hDlg);
              return TRUE;
            case ID_DIRBOX:
              DirBoxNotify(hDlg, HIWORD(lParam));
              return TRUE;
          }
    }
  return FALSE;
}

void InitDialog(HWND hDlg)
{
  ComboMsg(CB_SETEXTENDEDUI, TRUE, 0);
  ComboMsg(CB_LIMITTEXT, MAXMASKLEN, 0);
  SetDlgItemText(hDlg, ID_COMBO, szAllFiles);
  FillDirBox(hDlg, "");
}

void FillDirBox(HWND hDlg, char *szDir)
{
  DlgDirList(hDlg, szDir, ID_DIRBOX, ID_INITDIR,
    DDL_DIRECTORY | DDL_DRIVES | DDL_EXCLUSIVE);
}

void ChangeDir(HWND hDlg)
{
  char szDir[128];
  DlgDirSelect(hDlg, szDir, ID_DIRBOX);
  FillDirBox(hDlg, szDir);
}

void DefBtnPressed(HWND hDlg)
{
  if (ComboMsg(CB_GETDROPPEDSTATE, 0, 0))
      ComboMsg(CB_SHOWDROPDOWN, FALSE, 0);
  else
    if (bDirFocused)
      ChangeDir(hDlg);
    else
      FindFiles(hDlg);
}

void DirBoxNotify(HWND hDlg, WORD wCode)
{
  switch (wCode)
    {
       case LBN_SETFOCUS:
         bDirFocused = TRUE;
         break;
       case LBN_KILLFOCUS:
         bDirFocused = FALSE;
         break;
       case LBN_DBLCLK:
         SendMessage(hDlg, WM_COMMAND, IDOK, 0);
    }
}

BOOL GetMask(HWND hDlg, char *szMask)
{
  if (!GetDlgItemText(hDlg, ID_COMBO,
         szMask, MAXMASKLEN + 1))
    {
      MessageBeep(MB_ICONEXCLAMATION);
      MessageBox(hDlg, "Invalid mask specified!",
        "FileWind", MB_OK | MB_ICONEXCLAMATION);
      SetFocus(GetDlgItem(hDlg, ID_COMBO));
      return FALSE;
    }
  return TRUE;
}

void FindFiles(HWND hDlg)
{
  char szMask[MAXMASKLEN + 1], szPath[128], *szLast;
  int nSel;
  if (!GetMask(hDlg, szMask)) return;
  nSel = ComboMsg(CB_FINDSTRINGEXACT, -1, (LPARAM)szMask);
  if (nSel != CB_ERR) ComboMsg(CB_DELETESTRING, nSel, 0);
  ComboMsg(CB_INSERTSTRING, 0, (LPARAM)szMask);
  FileBoxMsg(LB_RESETCONTENT, 0, 0);
  FileBoxMsg(WM_SETREDRAW, FALSE, 0);
  SetCursor(LoadCursor(NULL, IDC_WAIT));
  GetDlgItemText(hDlg, ID_INITDIR, szPath, sizeof(szPath));
  szLast = szPath + lstrlen(szPath) - 1;
  if (*szLast == '\\') *szLast = 0;
  Scan(hDlg, szMask, szPath);
  FileBoxMsg(WM_SETREDRAW, TRUE, 0);
  wsprintf(szPath, "%d file(s) found.",
    (int)FileBoxMsg(LB_GETCOUNT, 0, 0));
  SetDlgItemText(hDlg, ID_STATUS, szPath);
}

void Scan(HWND hDlg, char *szMask, char *szPath)
{
  static char szProgress[144];
  char szFile[16];
  int i, nFiles, nPathLen;
  HWND hwndScan = CreateWindow("listbox", "", WS_CHILD,
    0, 0, 0, 0, hDlg, -1,
    GetWindowWord(hDlg, GWW_HINSTANCE), NULL);
  wsprintf(szProgress, "Scanning %s", (LPSTR)szPath);
  SetDlgItemText(hDlg, ID_STATUS, szProgress);
  lstrcat(szPath, "\\");
  nPathLen = lstrlen(szPath);
  nFiles = FillScanBox(hwndScan,
    DDL_ARCHIVE | DDL_READONLY | DDL_SYSTEM | DDL_HIDDEN,
    szMask, szPath);
  for (i = 0; i < nFiles; i ++)
    {
      SendMessage(hwndScan, LB_GETTEXT, i, (LPARAM)szFile);
      szPath[nPathLen] = 0;
      lstrcat(szPath, szFile);
      FileBoxMsg(LB_ADDSTRING, 0, (LPARAM)szPath);
    }
  SendMessage(hwndScan, LB_RESETCONTENT, 0, 0);
  szPath[nPathLen] = 0;
  nFiles = FillScanBox(hwndScan,
    DDL_DIRECTORY | DDL_EXCLUSIVE,
    szAllFiles, szPath);
  for (i = 0; i < nFiles; i ++)
    {
      SendMessage(hwndScan, LB_GETTEXT, i, (LPARAM)szFile);
      if (szFile[1] != '.')
        {
          szPath[nPathLen] = 0;
          szFile[lstrlen(szFile) - 1] = 0;
          lstrcat(szPath, szFile + 1);
          Scan(hDlg, szMask, szPath);
        }
    }
  DestroyWindow(hwndScan);
}

int FillScanBox(HWND hwndScan, WORD wAttr,
               char *szMask, char *szPath)
{
  lstrcat(szPath, szMask);
  SendMessage(hwndScan, LB_DIR, wAttr, (LPARAM)szPath);
  return SendMessage(hwndScan, LB_GETCOUNT, 0, 0);
}

