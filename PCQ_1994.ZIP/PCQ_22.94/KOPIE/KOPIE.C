#include <fcntl.h>
#include <sys\stat.h>
#include <stdio.h>
#include <conio.h>
#include <bios.h>
#include <io.h>
#include <stdlib.h>
char *bufor1,*bufor2;
int *bledy;
int liczbl,rozmbl;
int deskr;
int naped,wybor;
int rozmsekt,ilstron,ilcyl,ilsekt,ilb;
int sciezka,glowica,sektor; 
int i,j;
int powt,ilerazy;

int biosdisk_(int operacja, int naped, int glowica,
       int sciezka, int sektor, int ile, void *bufor)
{
  int blad,bis=0;
  do
  {
    bis++;
    blad = biosdisk(operacja, naped, glowica,
      sciezka, sektor, ile,bufor);
  } while ( (blad) && (bis != 5) );
  if (blad) return 1; else return 0;
}

void koniec()
{
  close(deskr);
  remove("C:\\temp.dsk");
  free(bufor1);
  free(bufor2);
  free(bledy);
}

void error(int skad)
{
  switch(skad)
  {
    case 0: printf("Nie mog� przydzieli� pami�ci!"); break;
    case 1: if (wybor==1 || bledy[liczbl] !=0)
     {
       printf ("Problemy przy odczycie z dyskietki");
       break;
     }
     bledy[liczbl]=18*(2*sciezka + glowica) + sektor;
     for(i = 0; i < rozmsekt; i++)
         bufor1[(sektor - 1) * rozmsekt + i] = 0;
     liczbl++;
     return;
    case 2: printf("Problemy przy zapisie na dyskietk�");
     break;
    case 3: printf("Problemy przy odczycie z dysku tward.");
     break;
    case 4: printf("Problemy przy zapisie na dysk twardy.");
     break;
  }
  koniec();
  exit(1);
}

void main() {
  clrscr();
  printf("\n1.Tworzenie dyskietki z parzysto�ci� danych");
  printf("\n2.Odtwarzanie uszkodzonej dyskietki");
  printf("\nTw�j wyb�r? ");
  scanf("%d",&wybor);
  printf("\nKt�ra stacja dysk�w A-0 , B-1 ?");
  scanf("%d",&naped);
  printf("\nPodaj rodzaj dyskietki: 1-360, 2-720, 3-1.2");
  printf(", 4-1.44 ? ");
  scanf("%d",&i);
  switch(i)
  {
    case 1: ilstron = 2; ilcyl = 40; ilsekt = 9;  break;
    case 2: ilstron = 1; ilcyl = 80; ilsekt = 9;  break;
    case 3: ilstron = 2; ilcyl = 80; ilsekt = 15; break;
    case 4: ilstron = 2; ilcyl = 80; ilsekt = 18; break;
    default: printf("Nieprawid�owa odpowied�!!!"); exit(1);
  }
  printf("Ile dyskietek?");
  scanf("%d",&ilerazy);
  if (wybor==1) printf("\nW��� pierwsza dyskietk� do stacji\
 i naci�nij klawisz ENTER");
  else if (wybor==2) printf("W��� dyskietk�, kt�ra ma zosta\
� naprawiona i naci�nij klawisz ENTER");
  while((i=getch()) != '\r');;
  liczbl = 0;
  rozmsekt=512;
  ilb = ilsekt * rozmsekt; //ilb=ilo�� bajt�w na scie�k�
  rozmbl = ilstron * ilcyl * ilsekt;
  // przydzial pamieci dla buforow i tablicy bledow
  if ((bufor1 = malloc(ilb)) == NULL) error(0);
  if ((bufor2 = malloc(ilb)) == NULL) error(0);
  if ((bledy = malloc(rozmbl)) == NULL) error(0);
  for(i = 0; i < rozmbl; i++) bledy[i] = 0;
  if ((deskr = open("C:\\temp.dsk", O_WRONLY | O_CREAT |
   O_BINARY | O_TRUNC, S_IREAD | S_IWRITE)) == -1) error(4);
                // utworzenie pliku tymczasowego na HDD
  for (sciezka = 0; sciezka < ilcyl; sciezka++)
    for (glowica = 0; glowica < ilstron; glowica++)
    {
      for (sektor = 1; sektor <= ilsekt; sektor++)
        if ((biosdisk_(2,naped,glowica,sciezka,sektor,1,
         bufor1 + rozmsekt * (sektor - 1))) != 0) error(1);
                                // odczyt dyskietki
      if ((write(deskr,bufor1,ilb)) != ilb) error(4);
   // zapis do pliku tymczasowego
    }
  for (powt = 0; powt < ilerazy - 1; powt++)
  {
    printf("\nW��� %d dyskietk� do stacji i \
naci�nij klawisz ENTER.",powt+2);
    while((i=getch()) !='\r');;
    if (wybor == 1)
    {
      lseek(deskr,0,0); //ustawienie pozycji w pliku
    // tymczasowym
      for (sciezka = 0; sciezka < ilcyl; sciezka++)
 for (glowica = 0; glowica < ilstron; glowica++)
 {
   if ((biosdisk_(2,naped,glowica,sciezka,1,
     ilsekt,bufor1)) != 0) error(1);
  //odczyt dyskietki
   if ((read(deskr,bufor2,ilb)) != ilb) error(3);
                //odczyt z pliku tymczasowego
   for (i = 0; i < ilb; i++) bufor1[i] ^= bufor2[i];
                                  // operacja XOR (^)
   lseek(deskr,-ilb,1);//ustawienie pozycji w pliku
                                  // tymczasowym
   if ((write(deskr,bufor1,ilb)) != ilb) error(4);
                //zapis do pliku tymczasowego
 }
    }
    else if (wybor == 2)
    {
      for(i = 0; bledy[i] != 0; i++)
      {
 sektor = bledy[i] % 18;
 if (sektor == 0) sektor = 18;
 sciezka = (bledy[i] - sektor) / 36;
 glowica = ((bledy[i] - sektor) / 18) % 2;
 if ((biosdisk_(2,naped,glowica,sciezka,sektor,
       1,bufor1)) != 0) error(1);
                // odczyt z dyskietki
 lseek(deskr, (long) rozmsekt * (bledy[i] - 1),0);
                // ustawienie pozycji w pliku tymczasowym
 if ((read(deskr,bufor2,rozmsekt)) != rozmsekt)
      error(3); // odczyt z pliku tymczasowego
 for (j = 0; j < rozmsekt; j++) bufor1[j] ^= bufor2[j];
                                      // operacja XOR (^)
 lseek(deskr,-rozmsekt,1); // ustawienie pozycji w
      // pliku tymczasowym
 if ((write(deskr,bufor1,rozmsekt)) != rozmsekt)
        error(4); //zapis do pliku tymczasowego
      }
    }
  }
  if (wybor==1) printf("\nW��� dyskietk� na ktorej zostanie\
 nagrana parzysto�� danych i naci�nij klawisz ENTER");
  else if (wybor==2) printf("\nW��� dyskietk�e na kt�rej \
zostanie nagrana zawarto�� odzyskanej dyskietki i naci�nij \
klawisz ENTER");
  while((i=getch()) !='\r');;
  lseek(deskr,0,0); // ustawnienie poz.w pliku tymczasowym
  for (sciezka =0; sciezka < ilcyl; sciezka++)
    for (glowica =0; glowica < ilstron; glowica++)
    {
      if ((read(deskr,bufor1,ilb)) != ilb) error(3);
             // odczyt z pliku tymczasowego
      if ((biosdisk_(3,naped,glowica,sciezka,1,
      ilsekt,bufor1)) != 0) error(2);
             // zapis na dyskietke
    }
  koniec();
}

