/* INFORMER.C */

#include <windows.h>
#include <toolhelp.h>
#include <mem.h>
#define SC_REFRESH  0xEFFF
#define DIM(x) (sizeof(x) / sizeof(x[0]))
#define INIT(x) {memset(&x,0,sizeof(x));x.dwSize=sizeof(x);}

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void UpdateList(HWND, HWND);
char szAppName[] = "INFORMER";

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrevInst,
                       LPSTR lpszCmdLine,  int nCmdShow)
{
  WNDCLASS wc;
  HWND hwnd;
  MSG msg;
  if (!hPrevInst)
    {
      wc.style = CS_VREDRAW | CS_HREDRAW;
      wc.lpfnWndProc = WndProc;
      wc.cbClsExtra = wc.cbWndExtra = 0;
      wc.hInstance = hInst;
      wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
      wc.hCursor = LoadCursor(NULL, IDC_ARROW);
      wc.hbrBackground = COLOR_WINDOW + 1;
      wc.lpszMenuName = NULL;
      wc.lpszClassName = szAppName;
      RegisterClass(&wc);
    }
  hwnd = CreateWindow(szAppName, szAppName,
           WS_OVERLAPPEDWINDOW,
           CW_USEDEFAULT, 0, CW_USEDEFAULT, 0,
           NULL, NULL, hInst, NULL);
  ShowWindow(hwnd, nCmdShow);
  UpdateWindow(hwnd);
  SendMessage(hwnd, WM_SYSCOMMAND, SC_REFRESH, 0);
  while (GetMessage(&msg, NULL, 0, 0))
    {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
  return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message,
                    WPARAM wParam, LPARAM lParam)
{
  static char szHeader[] = "     HANDLE  LINEAR"
         "     SIZE    FLAGS TYPE         OWNER";
  static int yList;
  static HWND hwndList;
  HFONT hfont;
  HWND hwndStatic;
  HMENU hmenu;
  TEXTMETRIC tm;
  HDC hdc;
  switch (message)
    {
      case WM_CREATE:
        hfont = GetStockObject(OEM_FIXED_FONT);
        hdc = GetDC(hwnd);
        SelectObject(hdc, hfont);
        GetTextMetrics(hdc, &tm);
        yList = tm.tmHeight + 2;
        ReleaseDC(hwnd, hdc);
        hwndList = CreateWindow("listbox", NULL,
          WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_BORDER |
          LBS_NOINTEGRALHEIGHT, 0, 0, 0, 0, hwnd, 100,
          ((LPCREATESTRUCT)lParam)->hInstance, NULL);
        hwndStatic = CreateWindow("static", szHeader,
          WS_CHILD | WS_VISIBLE | SS_LEFT,
          0, 1, tm.tmAveCharWidth * lstrlen(szHeader),
          tm.tmHeight, hwnd, 101,
          ((LPCREATESTRUCT)lParam)->hInstance, NULL);
        SendMessage(hwndList, WM_SETFONT, hfont, 0);
        SendMessage(hwndStatic, WM_SETFONT, hfont, 0);
        hmenu = GetSystemMenu(hwnd, FALSE);
        AppendMenu(hmenu, MF_SEPARATOR, NULL, NULL);
        AppendMenu(hmenu, MF_STRING, SC_REFRESH, "Refresh");
        return 0;
      case WM_SIZE:
        MoveWindow(hwndList, 0, yList, LOWORD(lParam),
                        HIWORD(lParam) - yList, TRUE);
        return 0;
      case WM_SETFOCUS:
        SetFocus(hwndList);
        return 0;
     case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
      case WM_SYSCOMMAND:
        if (wParam == SC_REFRESH)
          {
            UpdateList(hwnd, hwndList);
            return 0;
          }
    }
  return DefWindowProc(hwnd, message, wParam, lParam);
}

void UpdateList(HWND hwndMain, HWND hwndList)
{
  static char *szGTX[] = { "UNKNOWN", "DGROUP", "DATA",
    "CODE", "TASK", "RESOURCE", "MODULE", "FREE",
    "INTERNAL", "SENTINEL", "BURGER", "???" };
  static char *szGDX[] = { "RES:USERDEF", "RES:CRSCOMP",
    "RES:BITMAP", "RES:ICNCOMP", "RES:MENU", "RES:DIALOG",
    "RES:STRING", "RES:FONTDIR", "RES:FONT", "RES:ACCEL",
    "RES:RCDATA", "RES:ERRTAB", "RES:CURSOR", "RES:13",
    "RES:ICON", "RES:NAMETAB", "RES:???" };
  char buf[256];
  int i = 0, j;
  HGLOBAL hGlb;
  GLOBALINFO gi;
  GLOBALENTRY ge, FAR *lpge1, FAR *lpge2;
  TASKENTRY te;
  MODULEENTRY me;
  INIT(gi);
  INIT(ge);
  INIT(te);
  INIT(me);
  SendMessage(hwndList, LB_RESETCONTENT, 0, 0);
  SetCursor(LoadCursor(NULL, IDC_WAIT));
  GlobalInfo(&gi);
  hGlb = GlobalAlloc(GMEM_MOVEABLE,
    (DWORD)sizeof(GLOBALENTRY) * gi.wcItems);
  lpge1 = lpge2 = GlobalLock(hGlb);
  GlobalFirst(&ge, GLOBAL_ALL);
  do {
    *lpge2 ++ = ge;
    i ++;
  } while (GlobalNext(&ge, GLOBAL_ALL));
  for (j = 1, lpge2 = lpge1; j <= i; j ++, lpge2 ++)
    {
      if (!ModuleFindHandle(&me,
        TaskFindHandle(&te, lpge2->hOwner) ?
        te.hModule : lpge2->hOwner))
      me.szModule[0] = 0;
      wsprintf((LPSTR)buf,
        "%04X  %04X  %08lX  %08lX  %04X  %-13s%s",
        j, (UINT)(lpge2->hBlock), lpge2->dwAddress,
        lpge2->dwBlockSize, lpge2->wFlags,
        (LPSTR)(lpge2->wType != GT_RESOURCE ?
          szGTX[min(DIM(szGTX) - 1, lpge2->wType)] :
          szGDX[min(DIM(szGDX) - 1, lpge2->wData)]),
        (LPSTR)me.szModule);
      SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)buf);
    }
  GlobalUnlock(hGlb);
  GlobalFree(hGlb);
  wsprintf(buf,
    "%s - Global objects, Total:%u  Free:%u  LRU:%u",
    (LPSTR)szAppName,
    gi.wcItems, gi.wcItemsFree, gi.wcItemsLRU);
  SetWindowText(hwndMain, buf);
}

Wydruk 1.
