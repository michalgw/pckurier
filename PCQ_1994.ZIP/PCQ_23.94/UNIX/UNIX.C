#define _POSIX_SOURCE

#include <curses.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <utmp.h>
#include <signal.h>
#include <unistd.h>

#define FIELDMAX    200
#define BORDMAX     189
#define BORDMIN      11
#define MAINFNAME   "/tmp/doa.main"
#define ACCESSFNAME "/tmp/doa.access"
#define REMOVEFNAME "/tmp/doa.remove"
#define PREFIXFNAME "/tmp/doa."
#define FULL        'O'
#define SHOT        '*'
#define EMPT        ' '
#define WALL        '.'
#define SHOTL       KEY_LEFT
#define SHOTR       KEY_RIGHT
#define SHOTU       KEY_UP
#define SHOTD       KEY_DOWN
#define MOVEL       '4'
#define MOVER       '6'
#define MOVEU       '8'
#define MOVED       '2'

char Field[FIELDMAX][FIELDMAX];
struct UserList
{
 char x,y;
 char ShotUx,ShotUy,ShotDx,ShotDy;
 char ShotRx,ShotRy,ShotLx,ShotLy;
 char ShotCount;
 char *line;
 char *name;
 char *env;
 SCREEN *scr;
 FILE *in,*out;
 struct UserList *prev,*next;
} *Base,*Last,*Me;

void DrawBox(struct UserList *p)
{
 int c;

 set_term(p->scr);
 for(c=1;c!=22;c++)
 {
  mvaddch(0,c,'-');
  mvaddch(22,c,'-');
 }
 for(c=1;c!=22;c++)
 {
  mvaddch(c,0,'|');
  mvaddch(c,22,'|');
 }
 refresh();
}

void ShowField(struct UserList *p)
{
 int x,y;

 set_term(p->scr);
 Field[p->x][p->y]=FULL;
 for(y=-10;y<=10;y++)
 {
  move(y+11,1);
  for(x=-10;x<=10;x++)
  {
   switch(Field[p->x+x][p->y+y])
   {
    case FULL:
     addch(FULL);
     break;
    case EMPT:
     addch(EMPT);
     break;
    case SHOT:
     addch(SHOT);
     break;
    case WALL:
     addch(WALL);
     break;
    default:
     break;
   }
  }
 }
 refresh();
}

void AddUser(char *name, char *line, char *env)
{
 struct UserList *p1,*p2;

 p1=malloc(sizeof(struct UserList));
 Last->next=p1;
 p2=Last;
 Last=p1;
 Last->prev=p2;
 Last->next=NULL;
 Last->x=rand()%(FIELDMAX-21)+11;
 Last->y=rand()%(FIELDMAX-21)+11;
 Field[Last->x][Last->y]=FULL;
 Last->ShotUx=
 Last->ShotUy=
 Last->ShotDx=
 Last->ShotDy=
 Last->ShotLx=
 Last->ShotLy=
 Last->ShotRx=
 Last->ShotRy=
 Last->ShotCount=0;
 Last->line=malloc(strlen(line));
 strcpy(Last->line,line);
 Last->name=malloc(strlen(name));
 strcpy(Last->name,name);
 Last->env=malloc(strlen(env));
 strcpy(Last->env,env);
 if((Last->in=fopen(line,"r"))==NULL)
  exit(1);
 if((Last->out=fopen(line,"w"))==NULL)
  exit(1);
 Last->scr=newterm(Last->env,Last->out,Last->in);
 set_term(Last->scr);
 noecho();
 cbreak();
 keypad(stdscr,TRUE);
 nodelay(stdscr,TRUE);
 clear();
 curs_set(0);
 DrawBox(Last); 
 ShowField(Last);
}

void RemoveUser(struct UserList *p1,char flag)
{
 struct UserList *p2,*p3;
 char linetmp[24];

 strcpy(linetmp,PREFIXFNAME);
 strcat(linetmp,p1->line+5);
 Field[p1->x][p1->y]=EMPT;
 p2=p1->next;
 p3=p1->prev;
 set_term(p1->scr);
 clear();
 standend();
 if(flag)
  printw("\n\rPrzegrany\n\r");
 else
  printw("\n\rPrzerwany\n\r");
 if(p1==Me)
  printw("\n\rCzekaj ...\n\r");
 refresh();
 endwin();
 if(p2==NULL)
  Last=p3;
 else
 if(p3==NULL)
  Base=p2;
 else
 {
  p2->prev=p3;
  p2->next=p2;
 }
 if(p1!=Me)
 {
  fclose(p1->out);
  fclose(p1->in);
  free(p1->env);
  free(p1->name);
  free(p1->line);
  free(p1);
  p1=NULL;
 }
 remove(linetmp);
}

void ReadKeyb(struct UserList *p)
{
 set_term(p->scr);
 switch(wgetch(stdscr))
 {
  case MOVEL:
   Field[p->x][p->y]=EMPT;
   if(--(p->x)<=BORDMIN)
    p->x=BORDMIN;
   Field[p->x][p->y]=FULL;
   break;
  case MOVER:
   Field[p->x][p->y]=EMPT;
   if(++(p->x)>=BORDMAX)
    p->x=BORDMAX;
   Field[p->x][p->y]=FULL;
   break;
  case MOVED:
   Field[p->x][p->y]=EMPT;
   if(++(p->y)<=BORDMAX)
    p->y=BORDMAX;
   Field[p->x][p->y]=FULL;
   break;
  case MOVEU:
   Field[p->x][p->y]=EMPT;
   if(--(p->y)<=BORDMIN)
    p->y=BORDMIN;
   Field[p->x][p->y]=FULL;
   break;
  case SHOTL:
   if(!p->ShotCount)
   {
    p->ShotLx=p->x;
    p->ShotLy=p->y;
   }
   break;    
  case SHOTR:
   if(!p->ShotCount)
   {
    p->ShotRx=p->x;
    p->ShotRy=p->y;
   }
   break;    
  case SHOTD:
   if(!p->ShotCount)
   {
    p->ShotDx=p->x;
    p->ShotDy=p->y;
   }
   break;    
  case SHOTU:
   if(!p->ShotCount)
   {
    p->ShotUx=p->x;
    p->ShotUy=p->y;
   }
   break;
  case 'q':
   if(p!=Me)
    RemoveUser(p,0);
   break;
  default:
   break;
 }
 while(wgetch(stdscr)!=ERR);
}

void Calculate(struct UserList *p)
{
 struct UserList *ps;

 if(p->ShotLx && p->ShotLy)
 {
  if(Field[p->ShotLx-1][p->ShotLy]==FULL)
  {
   Field[p->ShotLx][p->ShotLy]=EMPT;
   for(ps=Base;ps!=NULL;ps=ps->next)
    if(ps->x==p->ShotLx-1 && ps->y==p->ShotLy)
     RemoveUser(ps,1);
   p->ShotLx=1;
   p->ShotLy=p->ShotCount=0;
  }
  if(Field[p->ShotLx][p->ShotLy]!=FULL)
   Field[p->ShotLx][p->ShotLy]=EMPT;
  p->ShotLx--;
  if(p->ShotCount)
   Field[p->ShotLx][p->ShotLy]=SHOT;
  if(++(p->ShotCount)>=10)
  {
   Field[p->ShotLx][p->ShotLy]=EMPT;
   p->ShotLx=p->ShotLy=p->ShotCount=0;
  }
 }
 else
 if(p->ShotRx && p->ShotRy)
 {
  if(Field[p->ShotRx+1][p->ShotRy]==FULL)
  {
   Field[p->ShotRx][p->ShotRy]=EMPT;
   for(ps=Base;ps!=NULL;ps=ps->next)
    if(ps->x==p->ShotRx+1 && ps->y==p->ShotRy)
     RemoveUser(ps,1);
   p->ShotRx=-1;
   p->ShotRy=p->ShotCount=0;
  }
  if(Field[p->ShotRx][p->ShotRy]!=FULL)
   Field[p->ShotRx][p->ShotRy]=EMPT;
  p->ShotRx++;
  if(p->ShotCount)
   Field[p->ShotRx][p->ShotRy]=SHOT;
  if(++(p->ShotCount)>=10)
  {
   Field[p->ShotRx][p->ShotRy]=EMPT;
   p->ShotRx=p->ShotRy=p->ShotCount=0;
  }
 }
 else
 if(p->ShotUx && p->ShotUy)
 {
  if(Field[p->ShotUx][p->ShotUy-1]==FULL)
  {
   Field[p->ShotUx][p->ShotUy]=EMPT;
   for(ps=Base;ps!=NULL;ps=ps->next)
    if(ps->x==p->ShotUx && ps->y==p->ShotUy-1)
     RemoveUser(ps,1);
   p->ShotUy=1;
   p->ShotUx=p->ShotCount=0;
  }
  if(Field[p->ShotUx][p->ShotUy]!=FULL)
   Field[p->ShotUx][p->ShotUy]=EMPT;
  p->ShotUy--;
  if(p->ShotCount)
   Field[p->ShotUx][p->ShotUy]=SHOT;
  if(++(p->ShotCount)>=10)
  {
   Field[p->ShotUx][p->ShotUy]=EMPT;
   p->ShotUx=p->ShotUy=p->ShotCount=0;
  }
 }
 else
 if(p->ShotDx && p->ShotDy)
 {
  if(Field[p->ShotDx][p->ShotDy+1]==FULL)
  {
   Field[p->ShotDx][p->ShotDy]=EMPT;
   for(ps=Base;ps!=NULL;ps=ps->next)
    if(ps->x==p->ShotDx && ps->y==p->ShotDy+1)
     RemoveUser(ps,1);
   p->ShotDy=-1;
   p->ShotDx=p->ShotCount=0;
  }
  if(Field[p->ShotDx][p->ShotDy]!=FULL)
   Field[p->ShotDx][p->ShotDy]=EMPT;
  p->ShotDy++;
  if(p->ShotCount)
   Field[p->ShotDx][p->ShotDy]=SHOT;
  if(++(p->ShotCount)>=10)
  {
   Field[p->ShotDx][p->ShotDy]=EMPT;
   p->ShotDx=p->ShotDy=p->ShotCount=0;
  }
 }
}

static void Intr1()
{
 struct UserList *p;

 for(p=Base;p!=NULL;p=p->next)
  RemoveUser(p,0);
 set_term(Me->scr);
 standend();
 endwin();
 remove(MAINFNAME);
 remove(ACCESSFNAME);
 remove(REMOVEFNAME);
 exit(1);
}

static void Intr2()
{
 FILE *r;

 r=NULL;
 while(access(REMOVEFNAME,F_OK)!=-1);
 if((r=fopen(REMOVEFNAME,"w"))!=NULL)
 {
  fprintf(r,"%s\n",ttyname(0));
  fclose(r);
  chmod(REMOVEFNAME,0666);
 }
 sleep(3);
}

void main(void)
{
 int i,j;
 char name[12],line[12],env[12],linetmp[24];
 struct UserList *p;
 FILE *main,*tty,*acs,*acst;
 char First;

 strcpy(name,(char *)getlogin());
 strcpy(line,(char *)ttyname(0));
 strcpy(env,getenv("TERM"));
 chmod(line,0666);
 if((main=fopen(MAINFNAME,"r"))==NULL)
 {
  srand((int)time(NULL));
  for(i=0;i!=FIELDMAX;i++)
   for(j=0;j!=FIELDMAX;j++)
    Field[i][j]=WALL;
  signal(2,Intr1);
  signal(9,Intr1);
  signal(15,Intr1);
  if((main=fopen(MAINFNAME,"w"))==NULL)
   exit(1);
  fputc('\n',main);
  fclose(main);
  chmod(MAINFNAME,0666);
  strcpy(linetmp,PREFIXFNAME);
  strcat(linetmp,line+5);
  if((tty=fopen(linetmp,"w"))==NULL)
   exit(1);
  fprintf(tty,"%s\n%s\n%s\n",name,line,env);
  fclose(tty);
  chmod(linetmp,0666);
  Me=malloc(sizeof(struct UserList));
  Me->prev=NULL;
  Me->next=NULL;
  Last=Base=Me;
  Me->line=malloc(strlen(line));
  Me->name=malloc(strlen(name));
  Me->env=malloc(strlen(env));
  strcpy(Me->line,line);
  strcpy(Me->name,name);
  strcpy(Me->env,env);
  Me->x=rand()%(FIELDMAX-21)+11;
  Me->y=rand()%(FIELDMAX-21)+11;
  Field[Me->x][Me->y]=FULL;
  Me->in=stdin;
  Me->out=stdout;
  Me->ShotUx=
  Me->ShotUy=
  Me->ShotDx=
  Me->ShotDy=
  Me->ShotLx=
  Me->ShotLy=
  Me->ShotRx=
  Me->ShotRy=
  Me->ShotCount=0;
  Me->scr=newterm(Me->env,Me->out,Me->in);
  set_term(Me->scr);
  noecho();
  cbreak();
  keypad(stdscr,TRUE);
  nodelay(stdscr,TRUE);
  clear();
  curs_set(0);
  DrawBox(Me);
  ShowField(Me);
  First=1;
  do
  {
   do
   {
    if(access(ACCESSFNAME,R_OK)!=-1)
    {
     acs=fopen(ACCESSFNAME,"r");
     sleep(1);
     fscanf(acs,"%s",name);
     fscanf(acs,"%s",line);
     fscanf(acs,"%s",env);
     fclose(acs);
     strcpy(linetmp,PREFIXFNAME);
     strcat(linetmp,line+5);
     if((tty=fopen(linetmp,"w"))==NULL)
      exit(1);
     fprintf(tty,"%s\n%s\n%s\n",name,line,env);
     AddUser(name,line,env);
     fclose(tty);
     chmod(linetmp,0666);
     remove(ACCESSFNAME);
     First=0;
    }
   }while(First);
   if(access(REMOVEFNAME,R_OK)!=-1)
   {
    acs=fopen(REMOVEFNAME,"r");
    sleep(1);
    fscanf(acs,"%s",line);
    fclose(acs);
    strcpy(linetmp,PREFIXFNAME);
    strcat(linetmp,line+5);
    for(p=Base;p!=NULL;p=p->next)
     if(!strcmp(line,p->line))
      RemoveUser(p,0);
    remove(REMOVEFNAME);
   }
   for(p=Base;p!=NULL;p=p->next)
    Calculate(p);
   for(p=Base;p!=NULL;p=p->next)
    ReadKeyb(p);
   for(p=Base;p!=NULL;p=p->next)
    ShowField(p);
  }while(Last!=Base);
  set_term(Base->scr);
  clear();
  standend();
  printw("\n\rWygrany\n\r");
  refresh();
  endwin();
  strcpy(linetmp,PREFIXFNAME);
  strcat(linetmp,Base->line+5);
  if(Base!=Me)
  {
   free(Base->env);
   free(Base->name);
   free(Base->line);
   free(Base);
  }
  free(Me->env);
  free(Me->name);
  free(Me->line);
  free(Me);
  remove(linetmp);
  remove(MAINFNAME);
  remove(ACCESSFNAME);
  remove(REMOVEFNAME);
 }
 else
 {
  signal(2,Intr2);
  signal(9,Intr2);
  signal(15,Intr2);
  printf("\nPoczekaj moment ...\n");
  while(access(ACCESSFNAME,F_OK)!=-1);
  if((acs=fopen(ACCESSFNAME,"w"))==NULL)
   exit(1);
  fprintf(acs,"%s\n%s\n%s\n",name,line,env);
  fclose(acs);
  chmod(ACCESSFNAME,0666);
  sleep(3);
  strcpy(linetmp,PREFIXFNAME);
  strcat(linetmp,line+5);
  do
  {
   sleep(2);
  }while(access(linetmp,F_OK)!=-1);
 }
}
