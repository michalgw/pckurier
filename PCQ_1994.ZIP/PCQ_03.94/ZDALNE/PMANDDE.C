
/* PMANDDE.C */

#include <windows.h>
#include <ddeml.h>
#include "pmandde.h"
#define MAXLEN 128

BOOL CALLBACK _export DlgProc(HWND, UINT, WPARAM, LPARAM);

char szTitle[] = "Progman DDE Interface Test";
char *szCommands[] = {
  "[AddItem(CmdLine,*Name,*IconPath,*IconIndex,*x,*y,"
  "*DefDir,*HotKey,*fMinimize)]",
  "[DeleteItem(Name)]",
  "[ShowGroup(GroupName,ShowCmd)]",
  "[CreateGroup(GroupName,*GroupPath)]",
  "[DeleteGroup(GroupName)]" };
char szCmd[MAXLEN];
HCONV hConv;

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrevInst,
                   LPSTR lpCmdLine, int nCmdShow)
{
  DWORD dwInst = 0L;
  HSZ hszProgman;
  DLGPROC lpfnDlgProc;
  DdeInitialize(&dwInst, NULL, 0, 0L);
  hszProgman = DdeCreateStringHandle(dwInst,
                     "PROGMAN", CP_WINANSI);
  hConv = DdeConnect(dwInst, hszProgman, hszProgman, NULL);
  lpfnDlgProc = MakeProcInstance((FARPROC)DlgProc, hInst);
  DialogBox(hInst, MAKEINTRESOURCE(ID_DLG),
                        NULL, lpfnDlgProc);
  FreeProcInstance(lpfnDlgProc);
  DdeUninitialize(dwInst);
  return 0;
}

void DdeExecute(HWND hDlg)
{
  DWORD dwResult;
  char szBuf[64];
  SetWindowText(hDlg, "Executing ...");
  DdeClientTransaction(szCmd, (DWORD)(lstrlen(szCmd) + 1),
     hConv, NULL, CF_TEXT, XTYP_EXECUTE, 1000, &dwResult);
  lstrcat(lstrcpy(szBuf, szTitle),
    dwResult & DDE_FACK ? " (Success)" : " (Error)");
  SetWindowText(hDlg, szBuf);
}

BOOL CALLBACK _export DlgProc(HWND hDlg, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
  static HWND hEdit;
  switch (message)
    {
      case WM_INITDIALOG:
        SetWindowText(hDlg, szTitle);
        hEdit = GetDlgItem(hDlg, ID_EDIT);
        SendMessage(hEdit, EM_LIMITTEXT, MAXLEN, 0L);
        return TRUE;
      case WM_SYSCOMMAND:
        if (wParam == SC_CLOSE)
          {
            EndDialog(hDlg, 0);
            return TRUE;
          }
        else break;
      case WM_COMMAND:
        switch (wParam)
          {
            case ID_ADDITEM:
            case ID_DELETEITEM:
            case ID_SHOWGRP:
            case ID_CREATEGRP:
            case ID_DELETEGRP:
              SetWindowText(hEdit,
                szCommands[wParam - ID_ADDITEM]);
              return TRUE;
            case ID_EXEC:
              GetWindowText(hEdit, szCmd, MAXLEN);
              DdeExecute(hDlg);
              return TRUE;
          }
    }
  return FALSE;
}
