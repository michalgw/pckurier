
/* FRACBACK.C - background processing in Windows, TS'93 */

#include <windows.h>
#include <math.h>
#include "fracback.h"
#define XMAX   1.0
#define XMIN   -2.0
#define YMAX   1.5
#define YMIN   -1.5
#define INF    25
#define CYCMAX 100
#define CYCMIN 0
#define SIZE   240
#define STYLE  WS_OVERLAPPED  | WS_SYSMENU | \
               WS_MINIMIZEBOX | WS_CAPTION

HBITMAP hBmp=NULL;
char szAppName[]="FracBack";
int iCycles=50,igxp,igyp,igcnt;
double dx,dy,dx0,dy0;

void Background(HWND hwnd)
{ int cnt=iCycles,b;
  double dx1;
  COLORREF color;
  HDC hdc=GetDC(hwnd), hdcmem=CreateCompatibleDC(hdc);
  SelectObject(hdcmem,hBmp);
  while (cnt)
   { do { dx1=dx; dx=dx*dx-dy*dy+dx0; dy=2*dy*dx1+dy0;
          igcnt--; cnt--; b=(sqrt(dx*dx+dy*dy)<2.0);
     } while (b && igcnt && cnt);
     color=(igcnt & 1) ? RGB(255,255,255) : RGB(0,0,0);
     if (SetPixel(hdc,igxp,igyp,color)==-1)
       InvalidateRect(hwnd,NULL,FALSE);
     SetPixel(hdcmem,igxp,igyp,color);
     if (!igcnt || !b)
       { igcnt=INF;
         if (++igyp==SIZE)
           { igyp=0; if (++igxp==SIZE) igxp=iCycles=cnt=0; }
         dx0=dx=igxp*(XMAX-XMIN)/SIZE+XMIN;
         dy0=dy=igyp*(YMAX-YMIN)/SIZE+YMIN; }
   }
  ReleaseDC(hwnd,hdc);
  DeleteDC(hdcmem);
}

void ClearBitmap(HWND hwnd)
{ HDC hdc=GetDC(hwnd), hdcmem=CreateCompatibleDC(hdc);
  if (!hBmp) hBmp=CreateCompatibleBitmap(hdc,SIZE,SIZE);
  SelectObject(hdcmem,hBmp);
  PatBlt(hdcmem,0,0,SIZE,SIZE,WHITENESS);
  ReleaseDC(hwnd,hdc);
  DeleteDC(hdcmem);
  igxp=igyp=0; igcnt=INF; dx0=dx=XMIN; dy0=dy=YMIN;
}

void EnterIdle(HWND hwnd,WPARAM wParam)
{ MSG msg;
  while (!PeekMessage(&msg,NULL,0,0,PM_NOREMOVE))
    Background(hwnd);
  if (wParam==MSGF_MENU) PostMessage(hwnd,WM_NULL,0,0L);
}

BOOL CALLBACK _export DlgProc(HWND hDlg,UINT message,
                         WPARAM wParam,LPARAM lParam)
{ static HWND hScr;
  static int iScr;
  switch (message) {
    case WM_INITDIALOG:
      hScr=GetDlgItem(hDlg,IDSCROLL);
      SetScrollRange(hScr,SB_CTL,CYCMIN,CYCMAX,FALSE);
      SetScrollPos(hScr,SB_CTL,iScr=iCycles,FALSE);
      SetDlgItemInt(hDlg,IDSTATIC,iScr,FALSE);
      return TRUE;
    case WM_COMMAND:
      switch (wParam) {
        case IDOK:     iCycles=GetScrollPos(hScr,SB_CTL);
        case IDCANCEL: EndDialog(hDlg,wParam);
                       return TRUE;
      }
      break;
    case WM_ENTERIDLE:
      EnterIdle(GetWindow(hDlg,GW_OWNER),wParam);
      return TRUE;
    case WM_HSCROLL:
      switch (wParam) {
        case SB_TOP:       iScr=CYCMIN; break;
        case SB_PAGEUP:    iScr-=(CYCMAX-CYCMIN)/10; break;
        case SB_LINEUP:    iScr--; break;
        case SB_LINEDOWN:  iScr++; break;
        case SB_PAGEDOWN:  iScr+=(CYCMAX-CYCMIN)/10; break;
        case SB_BOTTOM:    iScr=CYCMAX; break;
        case SB_THUMBPOSITION:
        case SB_THUMBTRACK: iScr=LOWORD(lParam); break;
        default: return FALSE;
      }
      iScr=max(CYCMIN,min(CYCMAX,iScr));
      SetScrollPos(hScr,SB_CTL,iScr,TRUE);
      SetDlgItemInt(hDlg,IDSTATIC,iScr,TRUE);
      return TRUE;
  }
  return FALSE;
}

LRESULT CALLBACK _export WndProc(HWND hwnd,UINT message,
                            WPARAM wParam,LPARAM lParam)
{ PAINTSTRUCT ps;
  HDC hdc,hdcmem;
  static FARPROC lpfnDlgProc;
  static HANDLE hInst;
  switch (message) {
    case WM_CREATE:
      ClearBitmap(hwnd);
      hInst=((LPCREATESTRUCT)lParam)->hInstance;
      lpfnDlgProc=MakeProcInstance((FARPROC)DlgProc,hInst);
      return 0;
    case WM_ENTERIDLE:
      EnterIdle(hwnd,wParam);
      return 0;
    case WM_COMMAND:
      switch (wParam) {
        case IDM_PRIORITY:
          DialogBox(hInst,szAppName,hwnd,lpfnDlgProc);
          return 0;
        case IDM_RESTART:
          ClearBitmap(hwnd);
          InvalidateRect(hwnd,NULL,FALSE);
          return 0;
        case IDM_EXIT:
          SendMessage(hwnd,WM_CLOSE,0,0L);
          return 0;
      }
      break;
    case WM_PAINT:
      hdc=BeginPaint(hwnd,&ps);
      hdcmem=CreateCompatibleDC(hdc);
      SelectObject(hdcmem,hBmp);
      BitBlt(hdc,0,0,SIZE,SIZE,hdcmem,0,0,SRCCOPY);
      DeleteDC(hdcmem);
      EndPaint(hwnd,&ps);
      return 0;
    case WM_DESTROY:
      DeleteObject(hBmp);
      PostQuitMessage(0);
      return 0;
  }
  return DefWindowProc(hwnd,message,wParam,lParam);
}

int PASCAL WinMain(HINSTANCE hInstance,HINSTANCE hPrevInst,
                   LPSTR lpszCmdLine,int nCmdShow)
{ static RECT rc={0,0,SIZE,SIZE+1};
  MSG msg;
  WNDCLASS wc;
  HWND hwnd;
  if (!hPrevInst)
    { wc.style=CS_VREDRAW | CS_HREDRAW;
      wc.lpfnWndProc=WndProc;
      wc.cbClsExtra=wc.cbWndExtra=0;
      wc.hInstance=hInstance;
      wc.hIcon=LoadIcon(NULL,IDI_APPLICATION);
      wc.hCursor=LoadCursor(NULL,IDC_ARROW);
      wc.hbrBackground=GetStockObject(WHITE_BRUSH);
      wc.lpszClassName=wc.lpszMenuName=szAppName;
      RegisterClass(&wc); }
  AdjustWindowRect(&rc,STYLE,TRUE);
  hwnd=CreateWindow(szAppName,szAppName,STYLE,
    CW_USEDEFAULT,CW_USEDEFAULT,rc.right-rc.left,
    rc.bottom-rc.top,NULL,NULL,hInstance,NULL);
  ShowWindow(hwnd,nCmdShow);
  UpdateWindow(hwnd);
  while (TRUE)
    if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))
      { if (msg.message==WM_QUIT) return msg.wParam;
        TranslateMessage(&msg);
        DispatchMessage(&msg); }
    else Background(hwnd);
}
