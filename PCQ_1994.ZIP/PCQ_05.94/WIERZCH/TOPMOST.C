
/* TOPMOST.C */

#include <windows.h>
#define SC_TOPMOST  0x0001

LRESULT CALLBACK _export WndProc(HWND,UINT,WPARAM,LPARAM);

int PASCAL WinMain(HINSTANCE hInstance,HINSTANCE hPrevInst,
                            LPSTR lpszCmdLine,int nCmdShow)
{
   static char szClass[] = "TopmostWndClass";
   WNDCLASS wc;
   HWND hwnd;
   HMENU hmenu;
   MSG msg;
   if (!hPrevInst)
     {
        wc.style = CS_VREDRAW | CS_HREDRAW;
        wc.lpfnWndProc = WndProc;
        wc.cbClsExtra = wc.cbWndExtra = 0;
        wc.hInstance = hInstance;
        wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
        wc.hCursor = LoadCursor(NULL, IDC_ARROW);
        wc.hbrBackground = GetStockObject(WHITE_BRUSH);
        wc.lpszMenuName = NULL;
        wc.lpszClassName = szClass;
        RegisterClass(&wc);
     }
   hwnd = CreateWindow(szClass, "", WS_OVERLAPPEDWINDOW,
            CW_USEDEFAULT, CW_USEDEFAULT, 256, 128,
            NULL, NULL, hInstance, NULL);
   ShowWindow(hwnd, nCmdShow);
   UpdateWindow(hwnd);
   while (GetMessage(&msg, NULL, 0, 0))
     {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
     }
   return msg.wParam;
}

void MakeTopmost(HWND hwnd, BOOL bTop)
{
  SetWindowPos(hwnd, bTop ? HWND_TOPMOST : HWND_NOTOPMOST,
    NULL, NULL, NULL, NULL, SWP_NOMOVE | SWP_NOSIZE);
  SetWindowText(hwnd,
    bTop ? "Topmost Window" : "Non-topmost Window");
}

LRESULT CALLBACK _export WndProc(HWND hwnd, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
  PAINTSTRUCT ps;
  HDC hdc;
  BOOL bCheck;
  int iWidth;
  static HMENU hmenu;
  static int cx, cy;
  static char szTxt[] = " This is just a test...";
  switch (message)
    {
      case WM_CREATE:
        hmenu = GetSystemMenu(hwnd, FALSE);
        AppendMenu(hmenu, MF_SEPARATOR, NULL, NULL);
        AppendMenu(hmenu, MF_STRING | MF_CHECKED,
          SC_TOPMOST, "Always on &Top");
        MakeTopmost(hwnd, TRUE);
        return 0;
      case WM_SIZE:
        cx = LOWORD(lParam) / 2;
        cy = HIWORD(lParam) / 2;
        return 0;
      case WM_PAINT:
        hdc = BeginPaint(hwnd, &ps);
        iWidth = (LOWORD(GetTextExtent(hdc, szTxt,
          lstrlen(szTxt))) +
          GetSystemMetrics(SM_CXICON)) / 2;
        DrawIcon(hdc, cx - iWidth,
          cy - GetSystemMetrics(SM_CYICON)/ 2 - 8,
          GetClassWord(hwnd, GCW_HICON));
        SetTextAlign(hdc, TA_RIGHT | TA_BASELINE);
        TextOut(hdc, cx + iWidth, cy,
          szTxt, lstrlen(szTxt));
        EndPaint(hwnd, &ps);
        return 0;
      case WM_SYSCOMMAND:
        if (wParam == SC_TOPMOST)
          {
            bCheck = GetMenuState(hmenu, SC_TOPMOST,
                         MF_BYCOMMAND) & MF_CHECKED;
            CheckMenuItem(hmenu, SC_TOPMOST, MF_BYCOMMAND |
                     (bCheck ? MF_UNCHECKED : MF_CHECKED));
            MakeTopmost(hwnd, !bCheck);
            return 0;
          }
        break;
      case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
  return DefWindowProc(hwnd, message, wParam, lParam);
}
