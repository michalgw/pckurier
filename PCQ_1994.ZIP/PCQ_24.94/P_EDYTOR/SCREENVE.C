/* SCREENVE.C - edycja fontow rastrowych sterownika ekranu
 polskiej Ventury 3.0 dla wyzszych rozdzielczosci
 - np. karta Cirrus Logic CL-542X    */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <io.h>
#include <graph.h>

/* zmiana podzialki fontu w bitach; 8 - o 1 bajt    */
#define         INCR    8
#define         BELL    7
/* wspolrzedne glownego okna edycyjnego */
#define         LEFT    1
#define         TOP     2
#define         RIGHT   80
#define         BOT     18
/* kolory   */
#define         BLACK   0
#define         BLUE    1
#define         BLINK   0x17
#define         LTGRAY  7
/* drugi bajt kodow specjalnych (strzalki)  */
#define         UP_ARR      72
#define         DOWN_ARR    80
#define         LEFT_ARR    75
#define         RIGHT_ARR   77


void main (int argc, char *argv[ ]);
void display_font (int offset, int length,
  int leng_bits, int limit);
void what_bit (int offset, int length, int leng_bits);
void restore (void);
void set_bit (void);
void reset_bit (void);

/* zmienne globalne */
char contents [8000];
struct place
 {
 int column;
 int row;
 int no_byte;
 int no_bit;
 int val_bit;
 } cursor;

void main (int argc, char *argv[ ] )
{
 FILE *in;
 FILE *out;

 char file_inp [40], file_out [40], offset_buff[10];
 long filesize, no_of_bytes;
 int onechar, row, col, file_limit;
 int offset_start, length_bytes, leng_bits, screen_start;
 int keyhit;
 char message[40];
 char *token;


 if ((argc == 2)&&(!strcmp(argv[1],"?")) )
 {
  printf ("Uzycie: SCREENVE\n");
  printf ("       i dalej odpowiedzi na pytania\n");
  exit (9);
 }
 do
 {
  printf ("\nPlik przetwarzany? ... ");
  gets (file_inp);
  printf ("Przetwarzany plik to: %s\n", file_inp);
  printf ("Nacisnij Y lub y lub T lub t gdy O.K.");
  keyhit = getche();
  printf ("\n");
 } while ( (keyhit!='Y')&& (keyhit!='y')&&
  (keyhit!='T')&& (keyhit!='t') );

 /* otworz plik wejsciowy    */
 in = fopen (file_inp, "rb");
 if (in == NULL)
 {
  printf ("Nie ma takiego pliku!\n");
  exit (59);
 }
/* odczytaj dlugosc pliku   */
 if ( (filesize = filelength(fileno(in))) == -1L)
 {
  printf ("Blad odczytu dlugosci pliku!\n");
  exit (79);
 }
 file_limit = (int) filesize;
 for (no_of_bytes = 1L; no_of_bytes <= filesize;
       no_of_bytes++)
 {
  contents[ (int)no_of_bytes-1 ] = (char)fgetc (in);
 }
 fclose (in);
 printf ("Plik wejsciowy w pamieci RAM.\n");
 do
 {
  printf ("Podaj adres startowy (hex)? ... ");
  gets (offset_buff);
  sscanf (offset_buff, "%x", &offset_start);
  screen_start = offset_start;
  printf ("Podzialka fontu w bajtach (hex)? ... ");
  gets (offset_buff);
  sscanf (offset_buff, "%x", &length_bytes);
  printf ("Start = %x podzialka = %x\n",
     offset_start, length_bytes);
  printf ("Nacisnij Y lub y lub T lub t gdy O.K.");
  keyhit = getche();
  printf ("\n");
 } while ( (keyhit!='Y')&& (keyhit!='y')&&
  (keyhit!='T')&& (keyhit!='t') );
 leng_bits = 0;
 _wrapon (_GWRAPOFF);
 _clearscreen (_GCLEARSCREEN);
 _settextwindow (BOT+2, LEFT, BOT+4, LEFT+40);
 _settextposition (1, 2);
 _outtext ("Aktywne klawisze: Q, W, +, -, ->, <-");
 _settextposition (2, 2);
 sprintf (message, "Plik ma dlugosc %lx (hex) bajtow",
      filesize);
 _outtext (message);
 _settextposition (3, 2);
 sprintf (message, "Start = %x a podzialka = %x (hex)",
  offset_start, length_bytes);
 _outtext (message);

 _settextwindow (TOP, LEFT, BOT, RIGHT);
 _setbkcolor (BLUE);
 display_font (offset_start, length_bytes, leng_bits,
         file_limit);
 _displaycursor(_GCURSOROFF);
 cursor.row = 1;
 cursor.column = 1;
 what_bit (offset_start, length_bytes, leng_bits);
 do
 {
  keyhit = getch();
  /* test klawisza specjalnego    */
  if (keyhit == 0)
   keyhit = getch();

  switch (keyhit)
  {
   case 'W':
   case 'w':
    /* zapis pliku wyjsciowego  */
    strcpy (file_out, file_inp);
    token = strtok (file_out, ".\n\r");
    strcat (file_out, ".new");
    out = fopen (file_out, "wb");
    if (out == NULL)
    {
     printf
     ("Nie mozna otworzyc pliku wy!\n");
     exit (69);
    }
    for (no_of_bytes = 1L;
     no_of_bytes <= filesize;
      no_of_bytes++)
    {
        fputc ( contents[(int)no_of_bytes-1],
       out);
    }
    _settextwindow (BOT+2, LEFT+40, BOT+4,
        RIGHT);
    _settextposition (1, 2);
    sprintf (message, "Zapisano plik: %s",
       file_out);
    _outtext (message);
    _settextposition (2, 2);
    _outtext ("Nacisnij Q lub q by skonczyc!");
    /* powrot do glownego okna  */
    _settextwindow (TOP, LEFT, BOT, RIGHT);
    break;
   case '+':
    /* ustawianie biezacego bitu    */
    set_bit ();
    break;
   case '-':
    /* zerowanie biezacego bitu */
    reset_bit ();
    break;
   case 'I':
   case 'i':
    /* inkrementacja podzialki fontu    */
    leng_bits += INCR;
    if (leng_bits >= 8)
    {
     leng_bits -= 8;
     length_bytes++;
    }
    _settextcolor (LTGRAY);
    display_font (screen_start, length_bytes,
      leng_bits, file_limit);
    what_bit (screen_start, length_bytes,
      leng_bits);
    break;
   case 'D':
   case 'd':
    /* dekrementacja podzialki fontu    */
    if (length_bytes > 10)
    {
     leng_bits -= INCR;
     if (leng_bits < 0)
     {
      leng_bits += 8;
      length_bytes--;
     }
     _settextcolor (LTGRAY);
     display_font (screen_start,
      length_bytes, leng_bits,
      file_limit);
     what_bit (screen_start, length_bytes,
      leng_bits);
    }
    else
     putchar (BELL);
    break;
   case UP_ARR:
    /* do gory w polu edycyjnym */
    if (cursor.row > 1)
    {
     restore ();
     cursor.row--;
     what_bit (screen_start, length_bytes,
      leng_bits);
    }
    break;
   case DOWN_ARR:
    /* w dol w polu edycyjnym   */
    if (cursor.row < 16)
    {
     restore ();
     cursor.row++;
     what_bit (screen_start, length_bytes,
      leng_bits);
    }
    break;
   case RIGHT_ARR:
    /* w prawo w polu edycyjnym */
    if (cursor.column < 80)
    {
     restore ();
     cursor.column++;
     what_bit (screen_start, length_bytes,
      leng_bits);
    }
    else if (screen_start <
      (offset_start+length_bytes-10) )
    {
     screen_start++;
     _settextcolor (LTGRAY);
     display_font (screen_start,
      length_bytes, leng_bits,
      file_limit);
     cursor.column = 73;
     what_bit (screen_start, length_bytes,
      leng_bits);
    }
    else
     putchar (BELL);
    break;
   case LEFT_ARR:
    /* w lewo w polu edycyjnym  */
    if (cursor.column > 1)
    {
     restore ();
     cursor.column--;
     what_bit (screen_start, length_bytes,
      leng_bits);
    }
    else if (screen_start > offset_start )
    {
     screen_start--;
     _settextcolor (LTGRAY);
     display_font (screen_start,
      length_bytes, leng_bits,
      file_limit);
     cursor.column = 8;
     what_bit (screen_start, length_bytes,
      leng_bits);
    }
    else
     putchar (BELL);

    break;
   case 'Q':
   case 'q':
    /* opuszczenie edytora fontow   */
    _setbkcolor (BLACK);
    _settextcolor (LTGRAY);
    _clearscreen (_GCLEARSCREEN);
    _displaycursor(_GCURSORON);
    break;
   default :
    putchar (BELL);
  }
 } while ( (keyhit!='Q')&& (keyhit!='q') );

} /* ------------------- end of main -------------------*/

void display_font (int offset, int length, int leng_bits,
     int limit)
{
 /* pelne odswiezenie obrazu pola edycyjnego fontu
  rastrowego  */
 int upper, lower, byte_no;
 int row, col, bit_shift;
 unsigned char int_cont;
 char line [81], buff_line[100];
 static char patterns [16][5] = {
 { "    " }, { "   \xB2"}, { "  \xB2 "}, { "  \xB2\xB2"},
 { " \xB2  "}, { " \xB2 \xB2"}, { " \xB2\xB2 "},
        { " \xB2\xB2\xB2"},
 { "\xB2   "}, { "\xB2  \xB2"}, { "\xB2 \xB2 "},
        { "\xB2 \xB2\xB2"},
 { "\xB2\xB2  "}, { "\xB2\xB2 \xB2"}, { "\xB2\xB2\xB2 "},
        { "\xB2\xB2\xB2\xB2"}
 };

 for (row = 0; row < 16; row++)
 {
  byte_no = offset + row*length + (row*leng_bits)/8;
  if (byte_no < limit)
  {
   for (col = 0; col <= 10; col++)
   {
    int_cont = contents [byte_no + col];
    upper = int_cont / 16;
    lower = int_cont - 16*upper;
    strncpy ( &buff_line[col*8],
      patterns[upper], 4);
    strncpy ( &buff_line[col*8 + 4],
      patterns[lower], 4);
   }
   _settextposition(row+1, 1);
   bit_shift = (row*leng_bits) % 8;
   strncpy (line, &buff_line[bit_shift], 80);
   line [80] = 0;
   _outtext (line);
  }
 }
} /* --------------- end of display_font ------------- */

void what_bit (int offset, int length, int leng_bits)
{
 /* identyfikacja zawartiosci bitu wskazywanego przez
  kursor w polu edycyjnym */
 char message[33];
 unsigned char test_bit;
 unsigned char mask;
 unsigned char inside_contents;

 cursor.no_byte = offset + (cursor.row-1)*length
     + ((cursor.column-1) +
     ((cursor.row-1)*leng_bits) )/8;
 /* numeracja bitow od 7 - lewy, MSB; do 0 - prawy, LSB*/
 cursor.no_bit = 7 - ( (cursor.column-1)%8 )
     - ((cursor.row-1)*leng_bits) % 8;
 if (cursor.no_bit < 0)
  cursor.no_bit += 8;
 mask = 1;
 mask = mask < cursor.no_bit;
 inside_contents = contents[cursor.no_byte];
 test_bit = mask&inside_contents;
 _settextwindow (BOT+2, LEFT+40, BOT+4, RIGHT);
 _settextposition (1, 2);
 sprintf (message, "Bajt nr: %4x bit nr: %x",
     cursor.no_byte, cursor.no_bit);
 _outtext (message);
 _settextposition (2, 2);
 sprintf (message, "Zawartosc: %2x maska: %2x",
     inside_contents, mask);
 _outtext (message);
 /* powrot do glownego okna tekstowego - pole edycyjne */
 _settextwindow (TOP, LEFT, BOT, RIGHT);
 _setbkcolor (BLUE);
 _settextposition (cursor.row, cursor.column);
 if (test_bit == 0)
 {
  cursor.val_bit = 0;
  _displaycursor (_GCURSORON);
 }
 else
 {
  cursor.val_bit = 1;
  _settextcolor (BLINK);
  _outtext ("\xB2");
 }

}

void restore ()
{
 /* odtworzenie obrazu na danej pozycji w polu edycyjnym,
  po przesunieciu z niej kursora na nowe miejsce  */
 if (cursor.val_bit == 0)
 {
  _displaycursor (_GCURSOROFF);
  return ;
 }
 else
 {
  _settextposition (cursor.row, cursor.column);
  _settextcolor (LTGRAY);
  _outtext ("\xB2");
 }
} /* ------------------ end of restore ------------------ */

void set_bit ()
{
 /* ustawienie (wpis 1) na danej pozycji (bicie) w polu
  edycyjnym, zmiana obrazu kursora   */
 char mask;

 cursor.val_bit = 1;
 _displaycursor (_GCURSOROFF);
 _settextposition (cursor.row, cursor.column);
 _settextcolor (BLINK);
 _outtext ("\xB2");
 mask = 1;
 mask = mask < cursor.no_bit;
 contents[cursor.no_byte] =
     contents[cursor.no_byte] | mask;
} /* ------------------ end of set_bit ----------------- */

void reset_bit ()
{
 /* zerowanie (wpis 0) na danej pozycji (bicie) w polu
  edycyjnym, zmiana obrazu kursora   */
 char mask;

 cursor.val_bit = 0;
 _displaycursor (_GCURSORON);
 _settextposition (cursor.row, cursor.column);
 _settextcolor (LTGRAY);
 _outtext (" ");
 _settextposition (cursor.row, cursor.column);
 mask = 1;
 mask = mask < cursor.no_bit;
 mask = ~mask;
 contents[cursor.no_byte] =
     contents[cursor.no_byte] & mask;
} /* ----------------- end of reset_bit ---------------- */

