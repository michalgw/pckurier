/*********************************************************
 *                                                       *
 * Program pokazuje mo�liwo�ci klas zdefiowanych w pliku *
 * vwindows.h i ich niekt�rych funkcji oraz spos�b       *
 * korzystania z typu key i funkcji dbtow() z pliku      *
 * keys.h                                                *
 *                                                       *
 * Autor: Tomasz Marek Dmowski, Gdynia 1994.             *
 *                                                       *
 *********************************************************/

#include <keys.h>
#include <vwindows.h>

main()
{
  w_manager zarzadca;

  vwindow *okno_GL=zarzadca.open(1,1,80,25);
  okno_GL->gotoxy(2,1);
  *okno_GL < "�     Okno";
  byte old_attr=okno_GL->attrib();
  okno_GL->newattrib(BLACK*16+RED);
  okno_GL->write('1');
  okno_GL->newattrib(old_attr);
  *okno_GL < "      Okno";
  okno_GL->newattrib(BLACK*16+RED);
  okno_GL->write('2');

  for(int k=2;k<=25;)
  {
    for (int i=1;i<=80;okno_GL->gotoxy(i,k),okno_GL->write('�'),i++);
    k++;
  }

  okno_GL->newattrib(BLACK*16+RED);
  okno_GL->gotoxy(1,25);
  *okno_GL < "ALT-X";
  okno_GL->newattrib(old_attr);
  *okno_GL < " powr�t";

  vwindow okno_KOM(60,15,20,8);
  okno_KOM.border2();
  okno_KOM.gotoxy(2,2);
  okno_KOM < "Aktywne klawisze:";
  okno_KOM.gotoxy(5,3);
  okno_KOM < "ESC";
  okno_KOM.gotoxy(5,4);
  okno_KOM < "ALT-0";
  okno_KOM.gotoxy(5,5);
  okno_KOM < "ALT-1";
  okno_KOM.gotoxy(5,6);
  okno_KOM < "ALT-2";
  okno_KOM.gotoxy(5,7);
  okno_KOM < "ALT-X";


  vwindow okno_0(3,10,35,7);
  okno_0.border2();
  okno_0.gotoxy(2,2);
  okno_0 < "Przykladowy program dla";
  okno_0.gotoxy(2,3);
  okno_0.invers_attr();
  okno_0 < " KEYS.H";
  okno_0.gotoxy(2,4);
  okno_0 < " VWINDOWS.H";
  okno_0.invers_attr();
  okno_0.gotoxy(2,5);
  okno_0 < " ";
  okno_0.gotoxy(2,6);
  okno_0 < "Autor: Tomasz Marek Dmowski";

  vwindow okno_1(9,2,10,4);
  okno_1.border1();
  okno_1.gotoxy(2,2);
  okno_1.invers_attr();
  okno_1 < "To jest ";
  okno_1.gotoxy(2,3);
  okno_1.invers_attr();
  okno_1 < " OKNO 1 ";

  vwindow okno_2(19,2,10,4);
  okno_2.border1();
  okno_2.gotoxy(2,2);
  okno_2.invers_attr();
  okno_2 < "To jest ";
  okno_2.gotoxy(2,3);
  okno_2.invers_attr();
  okno_2 < " OKNO 2 ";

  zarzadca < okno_KOM < okno_0 < okno_1 < okno_2;

  zarzadca.move_up(okno_GL);
  zarzadca.move_up(&okno_KOM);
  zarzadca.refresh();

  word w;
  do
  {
    do w=dbtow(); while ( (w!=ESC) && (w!=ALT0)
		  && (w!=ALT1) && (w!=ALT2) && (w!=ALTX) );

    zarzadca.refresh(okno_GL);
    zarzadca.refresh(&okno_KOM);

    switch (w)
    {
      case ALT0 : zarzadca.refresh(&okno_0);break;
      case ALT1 : zarzadca.refresh(&okno_1);break;
      case ALT2 : zarzadca.refresh(&okno_2);break;
    }
  }
  while (w!=ALTX);
};

Wydruk 1.
