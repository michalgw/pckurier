#include "dbstruct.ch"
#include "box.ch"
#include "inkey.ch"
*---------------------------------------------------------* 
norton('d:','*.*')            && wywo�anie funkcji
*---------------------------------------------------------* 
STATIC FUNCTION norton(sciem,nazwam) 
  LOCAL nKursor := SetCursor(0) 
  LOCAL op:={"Powt�rz operacj�","Wyj�cie"}
  LOCAL aOpKol   := { {"Nazwa"  ,14},   ;
                      {"Rozmiar",10},   ;
                      {"Data"   ,8},    ;
                      {"Czas"   ,8}}
 WHILE .t. 
   aKat     := Directory(sciem+nazwam) 
   aKat     := ASort( aKat,,, { |x,y| x[3] > y[3]  } ) 
   IF LEN(aKat)=0 
      IF Alert('Brak plik�w '+sciem+nazwam,op)=1 
         loop 
      ELSE 
 RETURN 0 
      ENDIF 
   ELSE 
     exit 
   ENDIF 
 ENDDO 
 SetColor("n/bg");Scroll() ; SetPos(0,0)  
 DevPos( 23, 30 )  
 DevOut( chr(24)+' '+Chr(25)+" PgUp PgDn HOME END-zmiana") 
 DevPos( 24, 36 )  
 DevOut( "Esc - wyj�cie" ) 
        xa:=5              && wiersz 
        xb:=12             && kolumna 
        xc:=xa+15          && d�ugo�� kolumny 
        xd:=xb+60          && szeroko�� 
    DispBox(xa,xb,xc,xd,2) && ramka 
    oBrowser := TBrowseNew(xa+1,xb+1,xc-1,xd-1)  
 IniBrowse(oBrowser,aKat,aOpKol)   && Inicjalizacja kolumn  
 SterujPrzegl(oBrowser,aKat,sciem) && Przegl�d tablicy 
 SetCursor(nKursor) 
 RETURN nil 
*---------------------------------------------------------* 
PROCEDURE IniBrowse(oTB, aTab, aOpKol,sciem) 
   LOCAL nLicz, oNwKol,nDlTab := Len(aTab) 
   LOCAL nSzerTabl := 4         && ilo�� widzianych kolumn
   oTB:colSep    := " � "       && separator kolumn
   oTB:headSep   := "���"       && separator nag��wka
   oTB:footSep   := "���"       && separator stopki
   oTb:cargo     := 1           && pod zmienn� cargo
   oTB:colorSpec := SetColor()  && pami�tany b�dzie wiersz
   oTB:SkipBlock     := {|nOdl| Przesun(nOdl, oTB, aTab)} 
   oTB:goTopBlock    := {||oTB:cargo := 1} 
   oTB:GoBottomBlock := {||oTB:cargo := Len(aTab)} 
   oTB:AddColumn(TBColumnNew("Lp.",{||str(oTb:cargo,3)})) 
   oTB:GetColumn(1):width:=3 
   FOR nLicz := 1 TO nSzerTabl 
    oTB:AddColumn(KolumnaTab(aTab,nLicz,aOpKol[nLicz],oTb)) 
   NEXT 
 RETURN 
*---------------------------------------------------------* 
FUNCTION  KolumnaTab(aTab, nLicz, aOpKol, oTB) 
 LOCAL oNowa:=TBColumnNew(aOpKol[1],; 
              {||aTab[oTB:cargo][oNowa:cargo]}) 
 oNowa:cargo := nLicz 
 oNowa:width := aOpKol[2] 
 RETURN oNowa 
*---------------------------------------------------------* 
STATIC FUNCTION SterujPrzegl(oTB,aKat,sciem) 
   LOCAL nKlaw, lWyjdz := .F. 
   LOCAL nKursor := SetCursor(0) 
   oTB:AutoLite:=.F.     && kasuj pod�wietlanie kom�rki 
   DO WHILE .t. 
      WHILE !oTB:Stabilize() 
        IF Inkey() # 0;EXIT;  ENDIF 
      ENDDO 
  cLite:=SaveScreen(row(),xb+1,row(),xd-1) 
  RestScreen(row(),xb+1,row(),xd-1,; 
             transform(cLite,Repl("X"+chr(15),xd-1))) 
   nKlaw := Inkey(0)          
  RestScreen(row(),xb+1,row(),xd-1,cLite) 
         IF     nKlaw == K_UP 
            oTB:up() 
         ELSEIF nKlaw == K_DOWN 
            oTB:down() 
         ELSEIF nKlaw == K_PGDN 
            oTB:PageDown() 
         ELSEIF nKlaw == K_PGUP 
            oTB:PageUp() 
         ELSEIF nKlaw == K_HOME 
            oTB:goTop() 
         ELSEIF nKlaw == K_END  
            oTB:goBottom() 
         ELSEIF  nKlaw == K_ESC 
            exit 
         ELSE 
            Tone(3000, 2); Tone(3000,2) 
         ENDIF 
   ENDDO 
 RETURN nil 
*---------------------------------------------------------* 
FUNCTION Przesun(nOdl, oTB, aTab) 
   LOCAL nPozKon := oTB:cargo + nOdl, nKoniec 
   LOCAL nStrPoz := oTB:cargo 
   IF nPozKon > (nKoniec := Len(aTab)) 
      nPozKon := nKoniec 
   ELSEIF nPozKon < 1 
      nPozKon := 1 
   ENDIF 
   oTB:cargo := nPozKon 
 RETURN nPozKon - nStrPoz 
*---------------------------------------------------------* 
*** koniec *** 


