/* FMANEXT.C - File Manager Extension
   Tomasz Sowinski, Marzec 1994
   Aby rozszerzyc menu File Managera:
   1. stworz plik FMANEXT.DLL - jest to
      biblioteka dynamiczna, nie aplikacja
   2. do pliku WINFILE.INI w katalogu \WINDOWS
      dodaj (jesli jeszcze nie istnieje)
      sekcje [AddOns] przy pomocy dowolnego
      edytora (np. notepad, sysedit)
   3. w sekcji [AddOns] umiesc linie o postaci:
      fmanext=c:\path\fmanext.dll
      po prawej stronie znaku '='
      - pelna nazwa (wraz ze sciezka)
      pliku FMANEXT.DLL
*/

#include <windows.h>
#include <wfext.h>
#include "fmanext.h"
#define LPLOAD   ((LPFMS_LOAD)lParam)

void FileInfo(HWND);
void DriveInfo(HWND);
void RunNotepad(HWND);
void Uninstall(HWND);

HINSTANCE hInstance;
char szExtName[] = "FMANEXT";

int CALLBACK LibMain(HINSTANCE hInst, WORD wDataSeg,
                 WORD cbHeapSize, LPSTR lpszCmdLine)
{
  hInstance = hInst;
  return 1;
}

int CALLBACK WEP(int nExitType)
{
  return 1;
}

HMENU CALLBACK _export FMExtensionProc(HWND hwndFM,
                       WORD message, LPARAM lParam)
{
  WORD wCount, wDelta, wEnable;
  HMENU hMenu;
  switch (message)
   {
     case FMEVENT_LOAD:
       lstrcpy(LPLOAD->szMenuName, "&Extension");
       LPLOAD->dwSize = sizeof(FMS_LOAD);
       LPLOAD->hMenu =
         LoadMenu(hInstance, MAKEINTRESOURCE(ID_MENU));
       return LPLOAD->hMenu;
     case FMEVENT_INITMENU:
       wCount = SendMessage(hwndFM, FM_GETSELCOUNT, 0, 0);
       wDelta = LOWORD(lParam);
       hMenu = (HMENU)HIWORD(lParam);
       EnableMenuItem(hMenu, wDelta + IDC_FILES,
         wCount ? MF_BYCOMMAND | MF_ENABLED :
                  MF_BYCOMMAND | MF_GRAYED);
       EnableMenuItem(hMenu, wDelta + IDC_NOTEPAD,
         wCount == 1 ? MF_BYCOMMAND | MF_ENABLED :
                       MF_BYCOMMAND | MF_GRAYED);
       break;
     case IDC_FILES:
       FileInfo(hwndFM);
       break;
     case IDC_DRIVE:
       DriveInfo(hwndFM);
       break;
     case IDC_NOTEPAD:
       RunNotepad(hwndFM);
       break;
     case IDC_UNINSTALL:
       Uninstall(hwndFM);
   }
  return 0;
}

void RunNotepad(HWND hwndFM)
{
  FMS_GETFILESEL file;
  WORD wExecCode;
  char szBuf[300];
  SendMessage(hwndFM, FM_GETFILESEL, 0,
    (LPARAM)(LPFMS_GETFILESEL)&file);
  wsprintf(szBuf, "notepad %s", (LPSTR)file.szName);
  wExecCode = WinExec(szBuf, SW_SHOW);
  if (wExecCode < 32)
    {
      wsprintf(szBuf,
        "WinExec failed, error code: %d", wExecCode);
      MessageBeep(MB_ICONHAND);
      MessageBox(hwndFM, szBuf, szExtName,
        MB_ICONHAND | MB_OK);
    }
}

void FileInfo(HWND hwndFM)
{
  FMS_GETFILESEL file;
  WORD wMaxSel = SendMessage(hwndFM, FM_GETSELCOUNT, 0, 0),
       wCount;
  char szInfo[300], szCaption[64];
  for (wCount = 0; wCount < wMaxSel; wCount ++)
    {
      SendMessage(hwndFM, FM_GETFILESEL, wCount,
        (LPARAM)(LPFMS_GETFILESEL)&file);
      wsprintf(szCaption,
        "Processing files: file %d", wCount + 1);
      OemToAnsi(file.szName, file.szName);
      wsprintf(szInfo, "Name: %s\nSize: %ld",
        (LPSTR)file.szName, file.dwSize);
      if (MessageBox(hwndFM, szInfo, szCaption,
          MB_ICONINFORMATION | MB_OKCANCEL) == IDCANCEL)
        break;
    }
}

void DriveInfo(HWND hwndFM)
{
  FMS_GETDRIVEINFO drive;
  char szInfo[400], szCaption[32];
  SendMessage(hwndFM, FM_GETDRIVEINFO, 0,
    (LPARAM)(LPFMS_GETDRIVEINFO)&drive);
  if (!drive.szShare[0]) lstrcpy(drive.szShare, "(none)");
  OemToAnsi(drive.szPath, drive.szPath);
  OemToAnsi(drive.szVolume, drive.szVolume);
  OemToAnsi(drive.szShare, drive.szShare);
  wsprintf(szCaption, "Drive info - %c:", drive.szPath[0]);
  wsprintf(szInfo, "Volume: %s\nTotal space: %ld bytes\n"
    "Free space: %ld bytes\nCurrent directory: %s\n"
    "Sharepoint: %s", (LPSTR)drive.szVolume,
    drive.dwTotalSpace, drive.dwFreeSpace,
    (LPSTR)drive.szPath, (LPSTR)drive.szShare);
  MessageBox(hwndFM, szInfo, szCaption,
    MB_ICONINFORMATION | MB_OK);
}

void Uninstall(HWND hwndFM)
{
  if (IDYES == MessageBox(hwndFM, "Uninstall FMANEXT ?",
      szExtName, MB_ICONQUESTION | MB_YESNOCANCEL))
     {
       WritePrivateProfileString("AddOns", szExtName,
         NULL, "WINFILE.INI");
       PostMessage(hwndFM, FM_RELOAD_EXTENSIONS, 0, 0);
     }
}

Wydruk 1.
