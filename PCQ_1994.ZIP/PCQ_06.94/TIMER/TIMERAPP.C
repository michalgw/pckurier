
/* TIMERAPP.C */

#include <windows.h>
#include <time.h>

#define ID_TIMER  1

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LPSTR GetStatusText(void);

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrev,
                          LPSTR lpCmdLine, int nCmdShow)
{
  static char szAppName[] = "TimerApp";
  WNDCLASS wc;
  TEXTMETRIC tm;
  HDC hdc;
  HWND hwnd;
  MSG msg;
  if (!hPrev)
    {
       wc.style = CS_HREDRAW | CS_VREDRAW;
       wc.lpfnWndProc = WndProc;
       wc.cbClsExtra = wc.cbWndExtra = 0;
       wc.hInstance = hInstance;
       wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
       wc.hCursor = LoadCursor(NULL, IDC_ARROW);
       wc.hbrBackground = GetStockObject(WHITE_BRUSH);
       wc.lpszMenuName = NULL;
       wc.lpszClassName = szAppName;
       RegisterClass(&wc);
    }
  else
    {
       GetInstanceData(hPrev, (NPSTR)&hwnd, sizeof(hwnd));
       ShowWindow(hwnd, SW_RESTORE);
       return 0;
    }
  hdc = CreateIC("DISPLAY", NULL, NULL, NULL);
  GetTextMetrics(hdc, &tm);
  DeleteDC(hdc);
  hwnd = CreateWindowEx(WS_EX_TOPMOST,
    szAppName, szAppName,
    WS_OVERLAPPED | WS_SYSMENU | WS_MINIMIZEBOX,
    CW_USEDEFAULT, CW_USEDEFAULT,
    48 * tm.tmAveCharWidth,
    3 * tm.tmHeight + GetSystemMetrics(SM_CYCAPTION),
    NULL, NULL, hInstance, NULL);
  while (!SetTimer(hwnd, ID_TIMER, 1000, NULL))
    if (MessageBox(hwnd, "Timer resource not available!",
        szAppName,
        MB_RETRYCANCEL | MB_ICONEXCLAMATION) == IDCANCEL)
      return 0;
  ShowWindow(hwnd, nCmdShow);
  UpdateWindow(hwnd);
  while (GetMessage(&msg, NULL, 0, 0))
    {
       TranslateMessage(&msg);
       DispatchMessage(&msg);
    }
  return msg.wParam;
}

LPSTR GetStatusText(void)
{
  static char szBuffer[128];
  struct tm *datetime;
  time_t lTime;
  time(&lTime);
  datetime = localtime(&lTime);
  wsprintf(szBuffer, "Time: %02u:%02u:%02u\n"
    "Free memory:%8lu  Largest block:%8lu\n"
    "FSR:%02u%%  GDI:%02u%%  USER:%02u%%\n",
    datetime->tm_hour, datetime->tm_min, datetime->tm_sec,
    GetFreeSpace(0), GlobalCompact(0),
    GetFreeSystemResources(GFSR_SYSTEMRESOURCES),
    GetFreeSystemResources(GFSR_GDIRESOURCES),
    GetFreeSystemResources(GFSR_USERRESOURCES));
  return szBuffer;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message,
                    WPARAM wParam, LPARAM lParam)
{
  PAINTSTRUCT ps;
  RECT rc;
  HDC hdc;
  switch (message)
    {
      case WM_PAINT:
        GetClientRect(hwnd, &rc);
        hdc = BeginPaint(hwnd, &ps);
        DrawText(hdc, GetStatusText(), -1, &rc, DT_CENTER);
        EndPaint(hwnd, &ps);
        return 0;
      case WM_TIMER:
        if (!IsIconic(hwnd))
          InvalidateRect(hwnd, NULL, FALSE);
        return 0;
      case WM_DESTROY:
        KillTimer(hwnd, ID_TIMER);
        PostQuitMessage(0);
        return 0;
    }
  return DefWindowProc(hwnd, message, wParam, lParam);
}
