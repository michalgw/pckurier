#include <stdio.h>

int main()
{
    double x,y,z;

    x = 4195835.0;
    y = 3145727.0;
    z = x - (x / y) * y;
    printf("%f\n",z);
    return 0;
}
/* wynik dla Pentium,"256.000000";
   wynik dla 486 "0.000000". */
