#pragma inline
#include <stdio.h>
#include <dos.h>

struct FindData {
 unsigned long attributes;
 unsigned long creation_time[2];
 unsigned long last_access_time[2];
 unsigned long last_modification_time[2];
 unsigned long file_size_high;
 unsigned long file_size_low;
 unsigned char reserved[8];
 unsigned char full_filename[260];
 unsigned char short_filename[14];
};

int w95_findfirst(const char *, struct FindData *,
 unsigned short , unsigned short *);
int w95_findnext(struct FindData *, unsigned short);
int w95_findclose(unsigned short);

void printfFindData(struct FindData *);

void main(void)
{
 struct FindData findData;
 int done;
 unsigned short handle;

 printf("DOSBOX DIR for Windows95\n\n");

 done = w95_findfirst("*",&findData, FA_DIREC, &handle);
 while (!done)
 {
  printfFindData(&findData);
  done = w95_findnext(&findData, handle);
 }
}

int w95_findfirst(const char *filespec,
 struct FindData *findData, unsigned short attrib,
 unsigned short *handle)
{
 asm push ds

 asm mov ax, 0x714E
 asm mov si, 0x0000
 asm mov cx, attrib
 asm lds dx, filespec
 asm les di, findData

 asm int 0x21

 asm les di, handle
 asm mov [es:di], ax

 asm pop ds
 asm jc findfirstFailed

 return 0;

findfirstFailed:
 return 1;
}

int w95_findnext(struct FindData *findData,
 unsigned short handle)
{
 asm mov ax, 0x714F
 asm mov si, 0x0000
 asm mov bx, handle
 asm les di, findData

 asm int 0x21
 asm jc findnextFailed

 return 0;

findnextFailed:
 return 1;
}

int w95_findclose(unsigned short handle)
{
 asm mov ax, 0x71A1
 asm mov bx, handle
 asm int 0x21
 asm jc findcloseFailed

 return 0;

findcloseFailed:
 return 1;
}

void printfFindData(struct FindData *findData)
{
 if( findData->short_filename[0] == 0)
  printf("%14s ", findData->full_filename);
 else
  printf("%14s ", findData->short_filename);

 if(findData->attributes & (1<4))
  printf("   <DIR>");
 else
 {
  printf("%8li", findData->file_size_low);
 }

 if( findData->short_filename[0] != 0)
  printf("   %s ", findData->full_filename);

 printf("\n");
}

// Dodatkowe funkcje do Windows95

int w95_mkdir(const char *path)
{
 asm push ds
 asm mov ax, 0x7139
 asm lds dx, path
 asm int 0x21

 asm pop ds
 asm jc Failed
 return 0;
Failed:
 return 1; // AX = error code
}

int w95_rmdir(const char *path)
{
 asm push ds
 asm mov ax, 0x713A
 asm lds dx, path
 asm int 0x21

 asm pop ds
 asm jc Failed
 return 0;
Failed:
 return 1; // AX = error code
}

int w95_chdir(const char *path)
{
 asm push ds
 asm mov ax, 0x713B
 asm lds dx, path
 asm int 0x21

 asm pop ds
 asm jc Failed
 return 0;
Failed:
 return 1; // AX = error code
}

int w95_getcwd(char *buf)
{
 asm push ds
 asm mov ax, 0x7147
 asm mov dl, 0
 asm lds si, buf
 asm int 0x21

 asm pop ds
 asm jc Failed
 return 0;
Failed:
 return 1; // AX = error code
}

int w95_rename(const char *oldname,
 const char *newname)
{
 asm push ds
 asm mov ax, 0x7156
 asm lds dx, oldname
 asm les di, newname
 // cl = ??
 asm int 0x21

 asm pop ds
 asm jc Failed
 return 0;
Failed:
 return 1; // AX = error code
}

