#include <stdio.h>
#include <time.h>
#include <dos.h>
#include <conio.h>

extern void initGraf32();
extern void putPixel(short,short,char);
extern void clearScreen (char);
extern void setAPage (char);
extern void setupFont (void *);
extern void putStr (char *, short,short,char);


#define ILE 900000L

void main ()
{
   union REGS r;
   clock_t st,en;
   int j;
   float cza;
   r.x.ax = 0x13;
   int86 (0x10, &r, &r);
   initGraf32();
   st = clock();
   for (j=0; j<ILE; j++)
     putPixel (160,100,15);
   en = clock();
   getch();
   r.x.ax = 0x3;
   int86 (0x10, &r, &r);
   cza = (float)(en-st)/CLOCKS_PER_SEC;
   printf ("%f", cza);

}

