/* Program STOPER �ukasz Odziewa (c) Grudzie� 1997 */
#include 
#include 
#include 
#include 

class Stoper
{
 private:
  static double correction; // in seconds
  double counter;           // in seconds
  unsigned long BIOScounter;// 18.2065 Hz
  unsigned CEcounter;       // 1.193180 MHz
  int running;              // 1 - True
  void calculate_correction();
 public:
  Stoper();
  void start();
  void stop();
  void restart();
  void zero();
  double time();
};

double Stoper::correction=999.0;

unsigned long BIOSTimer()
{
 unsigned long l;

 asm{
     push es;
     mov ax,0x40;
     push ax;
     pop es;
     mov ax,WORD PTR es:[0x6C];
     mov bx,WORD PTR es:[0x6E];
     mov word ptr [l],ax;
     mov word ptr [l+2],bx;
     pop es;
    }
 return l;
}

unsigned CETimer()
{
 unsigned a;

 asm{
     mov al,0x0;
     out 0x43,al;
     in al,0x40;
     mov ah,al;
     in al,0x40;
     xchg ah,al;
     mov a,ax;
    }
 return a;
}

void Stoper::calculate_correction()
{
 int i;

 counter=0.0;
 correction=0.0;
 for(i=0;i<2000;i++)
 {
  start();
  stop();
 }
 correction=(counter/i);
 counter=0.0;
}

Stoper::Stoper()
{
 running=0;
 if (correction==999.0) calculate_correction();
 counter=0.0;
}

void Stoper::start()
{
 if (!running)
 {
  BIOScounter=BIOSTimer();
  CEcounter=CETimer();
  running=1;
 }
}

void Stoper::stop()
{
 if (running)
 {
  counter=time();
  running=0;
 }
}

void Stoper::restart()
{
 stop();
 counter=0;
 start();
}

void Stoper::zero()
{
 stop();
 counter=0.0;
}

double Stoper::time()
{
 double r=0.0;
 unsigned u;
 long l;

 if (running)
 {
  u=CETimer();     // aby wynik by�
  l=BIOSTimer();   // najdok�adniejszy
  r+=CEcounter-u;
  r/=65536.0;
  r+=l-BIOScounter;
  r/=18.2065;
 }
 return r+counter-correction;
}

void main(int argc,char **argv)
{
 int result;

 if (argc<2) exit(1);
 Stoper S;
 S.start();
 result=spawnl(P_WAIT,argv[1],NULL);
 S.stop();
 if (result==-1) cout << "Error from spawnl\n";
 cout << setprecision(10) << S.time() << "\n";
}

