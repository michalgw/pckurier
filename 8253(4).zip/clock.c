/* Program CLOCK   �ukasz Odziewa (c) Grudzie� 1997 */
#include 
#include 
#include 

void setcounter(double s)
{
 unsigned CR=65535.0/s;
 asm{
     mov al,0x34;
     out 0x43,al;
     mov ax,CR;
     out 0x40,al;
     mov al,ah;
     out 0x40,al;
    }
}

void main(int argc,char **argv)
{
 char *p;
 double sec;

 if (argc<2)
 {
  cout << "Parametry : ON,OFF,sekundy\n";
  return;
 }
 if (!strcmpi(argv[1],"ON")) setcounter(1);
  else
   if (!strcmpi(argv[1],"OFF"))
    asm{
        mov al,0x34;
        out 0x43,al;
       }
       else
       {
        sec=strtod(argv[1],&p);
        if ((*p==0)&&(sec>=1)) setcounter(sec);
        else
        {
         cout << "Parametry : ON,OFF,(sekundy>1)\n";
         return;
        }
       }
}

