#include <conio.h>
#include <dos.h>
#include <iostream.h>

void interrupt (*TWP_ADR_09h) (...), (*TWP_ADR_08h) (...);

void interrupt OBSLUGA_08h(...)
{
  static timer;
  asm sti;
  if (++timer == 2) for (int i = 20; i < 79; i++, delay(10), timer = 0)
    pokeb (0xb800, 160 * 10 + 2 * i, '|');
  for (int j = 20; j < 79; j++) pokeb (0xb800, 160 * 10 + 2 * j, '-');
  TWP_ADR_08h ();
}

void interrupt OBSLUGA_09h(...)
{
  TWP_ADR_09h();
  static keyb;
  if (++keyb == 2) for (int i = 20; i < 79; i++, delay(10), keyb = 0)
      pokeb (0xb800, 160 * 9 + 2 * i, '|');
  for (int j = 20; j < 79; j++) pokeb (0xb800, 160 * 9 + 2 * j, '-');
}


void main()
{
  _setcursortype (_NOCURSOR);
  clrscr ();
  TWP_ADR_09h = getvect(0x9);
  TWP_ADR_08h = getvect(0x08);
  asm cli;
  setvect (0x09, OBSLUGA_09h);
  setvect (0x08, OBSLUGA_08h);
  asm sti;

  gotoxy (30, 15); cout < "SPACE - zamiana priorytetow  ";
  gotoxy (30, 16); cout < "ESC - wyjscie  ";


  gotoxy (8, 10); cout < "Klawiatura  ";
  gotoxy (6, 11); cout < "> Zegar     ";

  for (int j = 20; j < 79; j++)
  {
    pokeb (0xb800, 160 * 9 + 2 * j, '-');
    pokeb (0xb800, 160 * 10 + 2 * j, '-');
  }

  int k = 1;
  char key;

  while (key != 27)
  {
    key = getch();
    if (key == 0x20)
      if (k == 1)
      {
 gotoxy (6, 10); cout < ">"; gotoxy (6, 11); cout < " ";
 asm cli
 asm mov dx, 32
 asm mov al, 192
 asm out dx, al
 asm sti
 k = 0;
      }
      else
      {
 gotoxy (6, 11); cout < ">"; gotoxy (6, 10); cout < " ";
 asm cli
 asm mov dx, 32
 asm mov al, 199
 asm out dx, al
 asm sti
 k = 1;
      }
  }

  asm cli
  asm mov dx, 32
  asm mov al, 199
  asm out dx, al
  asm sti
  setvect (0x09, TWP_ADR_09h);
  setvect (0x08, TWP_ADR_08h);
  _setcursortype (_NORMALCURSOR);
}

