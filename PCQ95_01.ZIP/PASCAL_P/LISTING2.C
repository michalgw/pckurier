<SPIS_DZ>Wydruk 2.

uses WinTypes, WinProcs;

function ProceduraOkna(hOkno: HWnd; wKomunikat, wParametr: Word;
                       lParametr: Longint): Longint; export;
begin
  ProceduraOkna := 0;
  case wKomunikat of
    wm_Destroy:
      begin
        PostQuitMessage(0);
        Exit;
      end;
  end;
  ProceduraOkna := DefWindowProc(hOkno, wKomunikat,
                                 wParametr, lParametr);
end;

procedure WinMain;
var
  wndKlasaOkna : TWndClass;
  msgKomunikat : TMsg;
  hOkno : HWnd;

begin
  if HPrevInst = 0 then
    begin
      wndKlasaOkna.style         := cs_HRedraw or cs_VRedraw;
      wndKlasaOkna.lpfnWndProc   := @ProceduraOkna;
      wndKlasaOkna.cbClsExtra    := 0;
      wndKlasaOkna.cbWndExtra    := 0;
      wndKlasaOkna.hInstance     := HInstance;
      wndKlasaOkna.hIcon         := LoadIcon(0, idi_Application);
      wndKlasaOkna.hCursor       := LoadCursor(0, idc_Arrow);
      wndKlasaOkna.hbrBackground := GetStockObject(white_Brush);
      wndKlasaOkna.lpszMenuName  := nil;
      wndKlasaOkna.lpszClassName := 'Klasa';
      if not RegisterClass(wndKlasaOkna) then
        Halt(255);
      hOkno := CreateWindow('Klasa', 'Aplikacja', ws_OverlappedWindow,
               cw_UseDefault, cw_UseDefault, cw_UseDefault, cw_UseDefault,
               0, 0, HInstance, nil);
      ShowWindow(hOkno, CmdShow);
      UpdateWindow(hOkno);
      while GetMessage(msgKomunikat, 0, 0, 0) do
        begin
          TranslateMessage(msgKomunikat);
          DispatchMessage(msgKomunikat);
        end;
    end
  else
    SetActiveWindow(FindWindow('Klasa', 'Aplikacja'));
end;

begin
  WinMain;
end.
