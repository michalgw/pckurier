
#include <windows.h>

#pragma argsused
long FAR PASCAL _export ProceduraOkna(HWND hOkno,
         WORD wKomunikat, WORD wParametr, LONG lParametr)
  {
  switch(wKomunikat)
    {
    case WM_DESTROY:
      PostQuitMessage(0);
      break;
    default:
      return DefWindowProc(hOkno, wKomunikat,
                           wParametr, lParametr);
    }
  return 0L;
  }

#pragma argsused
int PASCAL _export WinMain(HINSTANCE hOznacznikInstancji,
                           HINSTANCE hPoprzedniOznacznik,
                           LPSTR lpszLiniaPolecenia, int nStanOkna)
  {
  WNDCLASS wndKlasaOkna;
  MSG msgKomunikat;
  HWND hOkno;

  if(!hPoprzedniOznacznik)
    {
    wndKlasaOkna.style	       = CS_HREDRAW | CS_VREDRAW;
    wndKlasaOkna.lpfnWndProc   = ProceduraOkna;
    wndKlasaOkna.cbClsExtra    = 0;
    wndKlasaOkna.cbWndExtra    = 0;
    wndKlasaOkna.hInstance     = hOznacznikInstancji;
    wndKlasaOkna.hIcon	       = LoadIcon(NULL, IDI_APPLICATION);
    wndKlasaOkna.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wndKlasaOkna.hbrBackground = GetStockObject(WHITE_BRUSH);
    wndKlasaOkna.lpszMenuName  = NULL;
    wndKlasaOkna.lpszClassName = "Klasa";
    if(!RegisterClass(&wndKlasaOkna))
      return FALSE;
    hOkno = CreateWindow("Klasa", "Aplikacja", WS_OVERLAPPEDWINDOW,
            CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
            NULL, NULL, hOznacznikInstancji, NULL);
    ShowWindow(hOkno, nStanOkna);
    UpdateWindow(hOkno);
    while(GetMessage(&msgKomunikat, NULL, 0, 0))
      {
      TranslateMessage(&msgKomunikat);
      DispatchMessage(&msgKomunikat);
      }
    }
  else
    SetActiveWindow(FindWindow("Klasa", "Aplikacja"));
  return 0;
  }
