#include <dos.h>
#include <stdio.h>
#include <conio.h>

#define TRB 0
#define IER 1
#define IIR 2
#define FCR 2
#define MCR 4
#define LSR 5
#define MSR 6
#define SCR 7
#define PIC 0x20
#define IMR 0x21
#define UART_8250     1
#define UART_16450    2
#define UART_16550    3
#define UART_16550A   4
#define UART_NIEZNANY 0

unsigned i, adres;
volatile unsigned ISR;

unsigned JestUART(unsigned adres)
  {
  if((inp(adres+IER) & 0xf0))
    return 0;
  if((inp(adres+IIR) & 0x30))
    return 0;
  if((inp(adres+MCR) & 0xe0))
    return 0;
  inp(adres+LSR);
  inp(adres+TRB);
  if((inp(adres+LSR) & 0x9f))
    return 0;
  inp(adres+MSR);
  if((inp(adres+MSR) & 0x0f))
    return 0;
  return 1;
  }

unsigned JakiUART(unsigned adres)
  {
  outp(adres+SCR, 0xff);
  if(inp(adres+SCR) != 0xff)
    return UART_8250;
  outp(adres+FCR, 0x01);
  i = inp(adres+IIR);
  outp(adres+FCR, 0x00);
  i &= 0xc0;
  switch(i)
    {
    case 0x00:
      return UART_16450;
    case 0x80:
      return UART_16550;
    case 0xc0:
      return UART_16550A;
    }
  return UART_NIEZNANY;
  }

void _interrupt _far ObslugaIRQ(void)
  {
  outp(PIC, 0x0b); // 00001011
  ISR = inp(PIC);
  inp(adres+IIR);
  outp(PIC, 0x20); // 00100000
  }

int PrzerwanieUART(unsigned adres)
  {
  int IRQ = -1;
  unsigned staryIMR, staryMCR, staryIER;
  void (_interrupt _far *wektory[4])(void);

  ISR = 0;
  ::adres = adres;
  staryIMR = inp(IMR);
  outp(IMR, 0xb8); // 10111000
  for(i = 3; i < 8; i++)
    if(i != 6)
      {
      wektory[i-3] = _dos_getvect(i+8);
      _dos_setvect(i+8, ObslugaIRQ);
      }
  staryMCR = inp(adres+MCR);
  staryIER = inp(adres+IER);
  outp(adres+MCR, 0x08);
  outp(IMR, 0x00);
  outp(adres+IER, 0x02);
  while(!ISR)
    ;
  outp(IMR, 0xb8); // 10111000
  outp(adres+MCR, staryMCR);
  outp(adres+IER, staryIER);
  for(i = 3; i < 8; i++)
    if(i != 6)
      _dos_setvect(i+8, wektory[i-3]);
  outp(IMR, staryIMR);
  while(ISR)
    {
    ISR >>= 1;
    IRQ++;
    }
  return IRQ;
  }

void main(void)
  {
  int IRQ;
  unsigned adres;
  char NazwyUART[5][9] = { "nieznany", "8250",
                           "16450", "16550",
                           "16550A" };

  clrscr();
  puts("Wykryte uklady:");
  for(adres = 0x100; adres < 0x400; adres += 0x08)
    if(JestUART(adres))
      {
      printf("UART %s, adres %x, przerwanie ",
             NazwyUART[JakiUART(adres)], adres);
      if((IRQ = PrzerwanieUART(adres)) != -1)
	printf("%d\n", IRQ);
      else
	puts("nieznane");
      }
  }
